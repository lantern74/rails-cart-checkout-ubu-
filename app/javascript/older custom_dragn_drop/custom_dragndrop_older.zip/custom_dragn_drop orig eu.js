function CustomDragAndDrop() {
  this.draggables = undefined;
  this.containers = undefined;
  this.placeholder = undefined;
  this.elementToInsert = undefined;
  this.afterElement = undefined;
  this.sectionCount = 0;
  this.mainContainer = undefined;
  this.popupContainer = undefined;
  this.existingElement = undefined;

  this.loadSections = function () {
    allContainers = document.querySelectorAll(".editor-container");

    if (allContainers.length > 0) {
      allContainers.forEach((container) => {
        this.addEventListenersForContainer(container);
      });
      this.updateContainers();
    } else {
      // Handle the case when no elements with the class .editor-container are found.
      // You can choose to display an error message or take appropriate action here.
    }
  };

  this.addSection = function () {
    // Create a new section container
    let container = document.createElement("div");
    container.classList.add("editor-container", "new-section"); //p-3

    // Set the minimum height to 250px
    container.style.minHeight = "250px";

    // Set the background color to light gray
    // container.style.backgroundColor = '#fafafa';
    container.style.backgroundColor = "#ffffff";

    let section = document.createElement("div");

    // section.innerHTML = `Section ${this.sectionCount++}`;
    // section.innerHTML = `<div class="containerInner ui-sortable">
    // <div class="dropZoneForRows ui-droppable" style="display: none;">
    // <div class="dropIconr"><i class="fa fa-plus fs-3"></i></div></div>
    // <div class="de-add-new-row-empty elFont_helvectica">
    // <a href="#" class="btn" id="de-show-rows-empty">
    // </a></div></div>`;

    // this should show the plus button inside of this HTML

    container.appendChild(section);
    console.log("this main container", this.mainContainer);
    console.log("this popup container", this.popupContainer);

    if (isPopupOpen()) {
      this.popupContainer.appendChild(container);
      console.log("The popup is open.");
    } else {
      this.mainContainer.appendChild(container);
      console.log("The popup is not open.");
    }

    this.addEventListenersForContainer(container);
    this.updateContainers();
  };

  this.updateContainers = function () {
    this.containers = document.querySelectorAll(".editor-container");
  };
  this.updateDraggables = function () {
    this.draggables = document.querySelectorAll(".draggable");
  };
  this.addEventListeners = function (name) {
    // console.log("adding event listeners", this.containers, this.draggables);
    if (name === "containers" && this.containers) {
      this.containers.forEach((container) => {
        container.addEventListener("dragover", (e) =>
          this.onDragHover(e, container, false)
        );
        container.addEventListener("drop", (e) => this.onDragDrop(e), false);
        container.addEventListener(
          "dragleave",
          (e) => this.onDragLeave(e),
          false
        );
        container.addEventListener(
          "dragenter",
          (e) => this.onDragEnter(e),
          false
        );
      });
    } else if ("draggables" && this.draggables) {
      this.draggables.forEach((draggable) => {
        draggable.addEventListener(
          "dragstart",
          (e) => this.onDragStart(e, draggable),
          false
        );
        draggable.addEventListener(
          "dragend",
          (e) => this.onDragEnd(e, draggable),
          false
        );
      });
    } else if (this.draggables && this.containers) {
      this.containers.forEach((container) => {
        container.addEventListener(
          "dragover",
          (e) => this.onDragHover(e, container),
          false
        );
        container.addEventListener("drop", (e) => this.onDragDrop(e), false);
        container.addEventListener(
          "dragleave",
          (e) => this.onDragLeave(e),
          false
        );
        container.addEventListener(
          "dragenter",
          (e) => this.onDragEnter(e),
          false
        );
      });
      this.draggables.forEach((draggable) => {
        draggable.addEventListener(
          "dragstart",
          (e) => this.onDragStart(e),
          false
        );
        draggable.addEventListener("dragend", (e) => this.onDragEnd(e), false);
      });
    }

    // console.log("draggables", this.draggables);
    // console.log("this.containers", this.containers);
  };
  this.removeEventListeners = function (name) {
    if (name === "editor-container" && this.containers) {
      this.containers.forEach((container) => {
        container.removeEventListener(
          "dragover",
          (e) => this.onDragHover(e, container),
          false
        );
        container.removeEventListener("drop", (e) => this.onDragDrop(e), false);
        container.removeEventListener(
          "dragleave",
          (e) => this.onDragLeave(e),
          false
        );
        container.removeEventListener(
          "dragenter",
          (e) => this.onDragEnter(e),
          false
        );
      });
    } else if (name === "draggables" && this.draggables) {
      this.draggables.forEach((draggable) => {
        draggable.removeEventListener(
          "dragstart",
          (e) => this.onDragStart(e, draggable),
          false
        );
        draggable.removeEventListener(
          "dragend",
          (e) => this.onDragEnd(e, draggable),
          false
        );
      });
    } else if (this.draggables && this.containers) {
      this.containers.forEach((container) => {
        container.removeEventListener(
          "dragover",
          (e) => this.onDragHover(e, container),
          false
        );
        container.removeEventListener("drop", (e) => this.onDragDrop(e), false);
        container.removeEventListener(
          "dragleave",
          (e) => this.onDragLeave(e),
          false
        );
        container.removeEventListener(
          "dragenter",
          (e) => this.onDragEnter(e),
          false
        );
      });
      this.draggables.forEach((draggable) => {
        draggable.removeEventListener(
          "dragstart",
          (e) => this.onDragStart(e),
          false
        );
        draggable.removeEventListener(
          "dragend",
          (e) => this.onDragEnd(e),
          false
        );
      });
    }
  };
  this.createPlaceHolder = function () {
    let placeholder = document.createElement("div");
    placeholder.style.height = "50px";
    placeholder.style.borderRadius = "5px";
    placeholder.style.backgroundColor = "#eee";
    placeholder.style.margin = "10px 0";
    this.placeholder = placeholder;
  };
  this.getDragAfterElement = function (container, y) {
    const draggableElements = [
      ...container.querySelectorAll(".draggable:not(.dragging)"),
    ];
    return draggableElements.reduce(
      (closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        if (offset < 0 && offset > closest.offset) {
          return {
            offset: offset,
            element: child,
          };
        } else {
          return closest;
        }
      },
      {
        offset: Number.NEGATIVE_INFINITY,
      }
    ).element;
  };

  this.onDragStart = function (e, draggable) {
    e.stopPropagation();
    let elementToInsert;
    console.log("drag start", draggable);
    // e.dataTransfer.setData('elementid',e.target.id);
    if (draggable && draggable.getAttribute("name")) {
      let element = draggable.getAttribute("name");

      // Create rollover tools div
      var rolloverTools = document.createElement("div");
      rolloverTools.classList.add(
        "de-rollover-tools",
        "smallWidthElementHover"
      );
      rolloverTools.setAttribute("data-current-id", "nill");
      rolloverTools.setAttribute("data-current-type", "type");
      rolloverTools.style.display = "none";

      // Add move, advance, clone, and remove buttons to rollover tools
      var moveButton = document.createElement("div");
      moveButton.classList.add("de-rollover-move");
      moveButton.innerHTML = '<i class="fa fa-arrows"></i>';

      var advanceButton = document.createElement("div");
      advanceButton.classList.add("de-rollover-advance");
      advanceButton.innerHTML = '<i class="fa fa-cog"></i>';

      var cloneButton = document.createElement("div");
      cloneButton.classList.add("de-rollover-clone");
      cloneButton.innerHTML = '<i class="fa fa-copy"></i>';

      var removeButton = document.createElement("div");
      removeButton.classList.add("de-rollover-remove");
      removeButton.innerHTML = '<i class="fa fa-trash-o"></i>';

      // Append the buttons to the rollover tools
      rolloverTools.appendChild(moveButton);
      rolloverTools.appendChild(advanceButton);
      rolloverTools.appendChild(cloneButton);
      rolloverTools.appendChild(removeButton);

      switch (element) {
        case "headline-field": // * HEADLINE *****************************************
          const wrapper = document.createElement("div");
          wrapper.classList.add(
            "draggable",
            "de",
            "elHeadlineWrapper",
            "ui-droppable",
            "de-editable"
          );
          wrapper.setAttribute("id", `headline-${Date.now()}`);
          wrapper.setAttribute("data-de-type", "headline");
          wrapper.setAttribute("data-de-editing", "false");
          wrapper.setAttribute("data-title", "headline");
          wrapper.setAttribute("data-ce", "true");
          wrapper.setAttribute("data-trigger", "none");
          wrapper.setAttribute("data-animate", "fade");
          wrapper.setAttribute("data-delay", "500");
          // wrapper.style.marginTop = '15px';
          wrapper.style.outline = "none";
          wrapper.style.cursor = "pointer";
          wrapper.setAttribute("aria-disabled", "false");
          wrapper.setAttribute("draggable", true);

          elementToInsert = document.createElement("h1");
          elementToInsert.classList.add(
            "ne",
            "elHeadline",
            "fs-1",
            "lh4",
            "elMargin0",
            "elBGStyle0",
            "hsTextShadow0",
            "display-5",
            "font-weight-normal"
          );
          elementToInsert.style.textAlign = "center";
          elementToInsert.style.fontSize = "32px";
          elementToInsert.dataset.bold = "inherit";
          elementToInsert.dataset.gramm = "false";
          elementToInsert.style.marginTop = "10px";
          elementToInsert.style.marginBottom = "10px";
          // elementToInsert.setAttribute('contenteditable', 'false');
          elementToInsert.setAttribute("contenteditable", "true");

          const bElement = document.createElement("b");
          bElement.textContent = "How To [GOOD] Without [BAD]";

          elementToInsert.appendChild(bElement);
          elementToInsert.setAttribute("id", `field-${Date.now()}`);

          elementToInsert.setAttribute("placeholder", "Text");

          var rolloverTools = document.createElement("div");
          rolloverTools.classList.add(
            "de-rollover-tools",
            "smallWidthElementHover",
            "d-flex",
            "flex-column"
          );

          rolloverTools.setAttribute("data-current-id", "nill");
          rolloverTools.setAttribute("data-current-type", "type");
          rolloverTools.style.display = "none";

          // TODO: PROGRAM THE ROLLOVER TOOLS FOR THE ELEMENT
          // Add move, advance, clone, and remove buttons to rollover tools
          var moveButton = document.createElement("div");
          moveButton.classList.add("de-rollover-move");
          moveButton.innerHTML = '<i class="fa fa-arrows"></i>';

          // var advanceButton = document.createElement("div");
          // advanceButton.classList.add("de-rollover-advance");
          // advanceButton.innerHTML = '<i class="fa fa-cog"></i>';

          // var cloneButton = document.createElement("div");
          // cloneButton.classList.add("de-rollover-clone");
          // cloneButton.innerHTML = '<i class="fa fa-copy"></i>';

          // var removeButton = document.createElement("div");
          // removeButton.classList.add("de-rollover-remove");
          // removeButton.innerHTML = '<i class="fa fa-trash-o"></i>';

          // var arrowUpButton = document.createElement("div");
          // arrowUpButton.classList.add("de-rollover-arrow-up");
          // arrowUpButton.innerHTML = '<i class="fa fa-arrow-up"></i>';

          // var arrowDownButton = document.createElement("div");
          // arrowDownButton.classList.add("de-rollover-arrow-down");
          // arrowDownButton.innerHTML = '<i class="fa fa-arrow-down"></i>';

          // var settingsButton = document.createElement("div");
          // settingsButton.classList.add("de-rollover-settings");
          // settingsButton.innerHTML = '<i class="fa fa-cogs"></i>';

          // var headlineText = document.createElement("div");
          // headlineText.classList.add("de-rollover-headline");
          // headlineText.textContent = "HEADLINE";

          // var plusCircle = document.createElement("div");
          // plusCircle.classList.add("de-rollover-plus-circle");
          // plusCircle.innerHTML = '<i class="fa fa-plus"></i>';

          // You can create and append those elements similar to the code above
          // Append the buttons and icons to rollover tools
          rolloverTools.appendChild(moveButton);
          // rolloverTools.appendChild(advanceButton);
          // rolloverTools.appendChild(cloneButton);
          // rolloverTools.appendChild(removeButton);
          // rolloverTools.appendChild(arrowUpButton);
          // rolloverTools.appendChild(arrowDownButton);
          // rolloverTools.appendChild(settingsButton);
          // rolloverTools.appendChild(headlineText);
          // rolloverTools.appendChild(plusCircle);

          // Append all the elements to the wrapper
          wrapper.appendChild(elementToInsert);
          wrapper.appendChild(rolloverTools);

          // Add event listeners to show/hide rollover tools

          // Add event listeners to show/hide rollover tools and change border color on mouseover
          wrapper.addEventListener("mouseenter", () => {
            rolloverTools.style.display = "block";
            moveButton.style.display = "block";
            wrapper.style.borderColor = "orange"; // Change border color on mouseover
            wrapper.style.borderWidth = "3px";
          });

          wrapper.addEventListener("mouseleave", () => {
            rolloverTools.style.display = "none";
            moveButton.style.display = "none";
            wrapper.style.borderColor = ""; // Reset border color on mouseout
            wrapper.style.borderWidth = "";
          });

          this.elementToInsert = wrapper;
          this.existingElement = false;

          break;

        case "subhead-field":
          const subheadWrapper = document.createElement("div");
          subheadWrapper.classList.add(
            "draggable",
            "de",
            "elSubHeadlineWrapper",
            "ui-droppable",
            "de-editable"
          );
          subheadWrapper.setAttribute("id", `subhead-${Date.now()}`);
          subheadWrapper.setAttribute("data-de-type", "subhead");
          subheadWrapper.setAttribute("data-de-editing", "false");
          subheadWrapper.setAttribute("data-title", "subhead");
          subheadWrapper.setAttribute("data-ce", "true");
          subheadWrapper.setAttribute("data-trigger", "none");
          subheadWrapper.setAttribute("data-animate", "fade");
          subheadWrapper.setAttribute("data-delay", "500");
          // subheadWrapper.style.marginTop = '15px';
          subheadWrapper.style.outline = "none";
          subheadWrapper.style.cursor = "pointer";
          subheadWrapper.setAttribute("aria-disabled", "false");
          subheadWrapper.setAttribute("draggable", true);

          const subheadElement = document.createElement("h3");
          subheadElement.classList.add(
            "ne",
            "elSubHeadline",
            "hsSize3",
            "lh4",
            "elMargin0",
            "elBGStyle0",
            "hsTextShadow0"
          );
          subheadElement.style.textAlign = "center";
          subheadElement.style.fontSize = "28px";
          subheadElement.dataset.bold = "inherit";
          subheadElement.dataset.gramm = "false";
          //subheadElement.setAttribute('contenteditable', 'false');

          const subheadBElement = document.createElement("p");
          subheadBElement.textContent =
            "FREE: Brand New On-Demand Class Reveals ...";

          subheadElement.appendChild(subheadBElement);
          subheadElement.setAttribute("id", `field-${Date.now()}`);
          subheadElement.setAttribute("placeholder", "Subhead Text");

          // Add any additional styling or attributes for the subhead as needed

          subheadWrapper.appendChild(subheadElement);

          this.elementToInsert = subheadWrapper;
          this.existingElement = false;
          break;

        case "paragraph-field":
          const paragraphWrapper = document.createElement("div");
          paragraphWrapper.classList.add(
            "draggable",
            "de",
            "elparagraphWrapper",
            "ui-droppable",
            "de-editable"
          );
          paragraphWrapper.setAttribute("id", `text-${Date.now()}`);
          paragraphWrapper.setAttribute("data-de-type", "text");
          paragraphWrapper.setAttribute("data-de-editing", "false");
          paragraphWrapper.setAttribute("data-title", "text");
          paragraphWrapper.setAttribute("data-ce", "true");
          paragraphWrapper.setAttribute("data-trigger", "none");
          paragraphWrapper.setAttribute("data-animate", "fade");
          paragraphWrapper.setAttribute("data-delay", "500");
          // paragraphWrapper.style.marginTop = '15px';
          paragraphWrapper.style.outline = "none";
          paragraphWrapper.style.cursor = "pointer";
          paragraphWrapper.setAttribute("aria-disabled", "false");
          paragraphWrapper.setAttribute("draggable", true);

          const textElement = document.createElement("p");
          textElement.classList.add(
            "ne",
            "elText",
            "hsSize3",
            "lh4",
            "elMargin0",
            "elBGStyle0",
            "hsTextShadow0"
          );
          // textElement.style.textAlign = 'center';
          textElement.style.fontSize = "20px";
          textElement.dataset.bold = "inherit";
          textElement.dataset.gramm = "false";
          // textElement.setAttribute('contenteditable', 'false');

          // const textPElement = document.createElement('p');
          textElement.textContent =
            "This Class Is Available Instantly ...No Waiting.";

          // textElement.appendChild(textPElement);
          textElement.setAttribute("id", `field-${Date.now()}`);
          textElement.setAttribute("placeholder", "Text");

          // Add any additional styling or attributes for the text element as needed

          paragraphWrapper.appendChild(textElement);

          this.elementToInsert = paragraphWrapper;
          this.existingElement = false;
          break;

        case "button-field":
          // Create the outer container
          const buttonContainer = document.createElement("div");
          buttonContainer.classList.add(
            "draggable",
            "de",
            "elBTN",
            "de-editable",
            "elAlign_center",
            "elMargin0"
          );
          buttonContainer.id = `tmp_button-${Date.now()}`;
          buttonContainer.dataset.deType = "button";
          buttonContainer.dataset.deEditing = "false";
          buttonContainer.dataset.title = "button";
          buttonContainer.dataset.ce = "false";
          buttonContainer.dataset.trigger = "none";
          buttonContainer.dataset.animate = "fade";
          buttonContainer.dataset.delay = "500";
          buttonContainer.style.marginTop = "40px";
          buttonContainer.style.marginBottom = "40px";
          buttonContainer.style.outline = "none";
          buttonContainer.style.textAlign = "center";
          // buttonContainer.style.margin = '20px 30px';

          // Create the <a> element
          const linkElement = document.createElement("a");
          linkElement.href = "#submit-form";
          linkElement.id = `the_button-${Date.now()}`;
          linkElement.classList.add(
            "elSettings",
            "elButton",
            "elButtonSize1",
            "elButtonColor1",
            "elButtonRounded",
            "elButtonPadding2",
            "elBtnVP_10",
            "elButtonCorner3",
            "elButtonFluid",
            "elBtnHP_25",
            "elBTN_b_1",
            "elButtonShadowN1",
            "elButtonTxtColor1"
          );
          linkElement.style.color = "rgb(255, 255, 255)";
          linkElement.style.fontWeight = "600";
          linkElement.style.backgroundColor = "#ff0000";
          linkElement.style.fontSize = "20px";
          linkElement.rel = "noopener noreferrer";

          // Create the main and sub spans
          const mainSpan = document.createElement("span");
          mainSpan.classList.add("elButtonMain");
          mainSpan.textContent = "Let Me In!";

          const subSpan = document.createElement("span");
          subSpan.classList.add("elButtonSub");

          // Append the main and sub spans to the <a> element
          linkElement.appendChild(mainSpan);
          linkElement.appendChild(subSpan);

          // Append the <a> element to the button container
          buttonContainer.appendChild(linkElement);

          // Add rollover tools for the button (you should complete this part)

          // Set the draggable attribute
          elementToInsert = buttonContainer;
          elementToInsert.setAttribute("draggable", true);

          this.elementToInsert = elementToInsert;
          this.existingElement = false;
          break;

        case "countdown-field":
          const currentDate = new Date();
          const futureDate = new Date();

          futureDate.setDate(currentDate.getDate() + 1); // Add 1 day
          futureDate.setHours(currentDate.getHours() + 12); // Add 11 hours

          // Construct the targetDateStr with the desired format, including hours, minutes, and seconds
          const targetDateStr = `${futureDate.getFullYear()}-${(
            futureDate.getMonth() + 1
          )
            .toString()
            .padStart(2, "0")}-${futureDate
            .getDate()
            .toString()
            .padStart(2, "0")}T${futureDate
            .getHours()
            .toString()
            .padStart(2, "0")}:${futureDate
            .getMinutes()
            .toString()
            .padStart(2, "0")}:${futureDate
            .getSeconds()
            .toString()
            .padStart(2, "0")}`;

          const targetDate = new Date(targetDateStr);
          const targetStamp = targetDate.getTime();

          const containercountdownWrapper = document.createElement("div");
          containercountdownWrapper.classList.add(
            "container-fluid",
            "draggable",
            "de",
            "elCountdownWrapper",
            "ui-droppable",
            "de-editable"
          );

          const countdownWrapper = document.createElement("div");
          countdownWrapper.classList.add("row", "no-gutters");
          // countdownWrapper.style.margin = 0;
          countdownWrapper.style.backgroundColor = "red";
          countdownWrapper.style.color = "yellow";
          countdownWrapper.style.display = "flex"; // Enable Flexbox
          countdownWrapper.style.alignItems = "center"; // Center content vertically

          const leftColumn = document.createElement("div");
          // leftColumn.classList.add('col-md-9');
          leftColumn.classList.add("col-md-8", "d-none", "d-md-block"); // Hide on iPhones, show on medium and larger screens

          const textLeft = document.createElement("div");
          textLeft.classList.add("text-left");

          function getFormattedDate(date) {
            const options = {
              weekday: "long",
              hour: "numeric",
              minute: "numeric",
              timeZoneName: "short",
              timeZone: "America/New_York",
              // timeZone: 'Europe/Vienna'
            };
            return date.toLocaleString("en-US", options);
          }

          const heading = document.createElement("div");
          // heading.style.fontSize = '24px'; // Set font size
          heading.style.fontSize = "1.6vw"; // 3% of the viewport width

          heading.style.fontWeight = "600"; // Set font weight
          heading.style.letterSpacing = "letter-spacing: -0.5px;"; // Set letter spacing
          heading.style.fontFamily = "Nunito Sans, sans-serif"; // Set font family
          heading.style.paddingLeft = "20px";
          const formattedTargetDateMessage = `Hurry! This special offer is available until ${getFormattedDate(
            currentDate
          )}`;
          heading.textContent = formattedTargetDateMessage;

          textLeft.appendChild(heading);
          // textLeft.appendChild(paragraph);
          leftColumn.appendChild(textLeft);

          const rightColumn = document.createElement("div");
          // rightColumn.classList.add('col-md-3');
          rightColumn.classList.add("col-12", "col-md-4"); // Span full width on small screens, and col-3 on medium and larger screens

          const countdownDiv = document.createElement("div");
          countdownDiv.classList.add(
            "de",
            "elCountdown",
            "de-editable",
            "elAlign_center",
            "elMargin0"
          );
          countdownDiv.setAttribute("id", `countdown-${Date.now()}`);
          countdownDiv.setAttribute("data-de-type", "countdown");
          countdownDiv.setAttribute("data-de-editing", "false");
          countdownDiv.setAttribute("data-title", "Date Countdown 2.0");
          countdownDiv.setAttribute("data-ce", "false");
          countdownDiv.setAttribute("data-trigger", "none");
          countdownDiv.setAttribute("data-animate", "fade");
          countdownDiv.setAttribute("data-delay", "500");
          countdownDiv.style.outline = "none";
          countdownDiv.style.backgroundColor = "red";
          countdownDiv.style.color = "yellow";
          countdownDiv.style.border = "0px none";

          const countdownElement = document.createElement("div");
          countdownElement.classList.add(
            "realcountdown",
            "wideCountdownSize2",
            "cdBlack",
            "cdStyleTextOnly",
            "clearfix",
            "hide"
          );

          countdownElement.setAttribute("data-date", targetDateStr);
          countdownElement.setAttribute("data-time", targetStamp);
          countdownElement.setAttribute("data-tz", "America/New_York");
          // countdownElement.setAttribute('data-tz', 'Europe/Vienna');
          countdownElement.setAttribute("data-url", "#");
          countdownElement.setAttribute("data-lang", "eng");
          countdownElement.textContent = "";

          const countdownDemo = document.createElement("div");
          countdownDemo.classList.add(
            "wideCountdown",
            "wideCountdownSize2",
            "cdBlack",
            "cdStyleTextOnly",
            "wideCountdown-demo",
            "is-countdown",
            "clearfix"
          );

          const timerDiv = document.createElement("div");
          timerDiv.classList.add("timer");

          const timerElements = [
            {
              number: "03",
              word: "days",
            },
            {
              number: "04",
              word: "hrs",
            },
            {
              number: "12",
              word: "min",
            },
            {
              number: "03",
              word: "sec",
            },
          ];

          timerElements.forEach((element) => {
            const timerItem = document.createElement("div");
            timerItem.style.display = "inline-block";
            timerItem.style.marginRight = "10px";

            const timerNumber = document.createElement("div");
            timerNumber.classList.add("timer-number");
            timerNumber.textContent = element.number;

            const timerWord = document.createElement("div");
            timerWord.classList.add("timer-word");
            timerWord.textContent = element.word;

            timerItem.appendChild(timerNumber);
            timerItem.appendChild(timerWord);
            timerDiv.appendChild(timerItem);
          });

          countdownElement.appendChild(timerDiv); // Nest the timer inside .realcountdown

          //  countdownDemo.appendChild(countdownRow);

          // const rolloverTools = document.createElement('div');
          // rolloverTools.classList.add('de-rollover-tools', 'smallWidthElementHover');
          // rolloverTools.setAttribute('data-current-id', 'nill');
          // rolloverTools.setAttribute('data-current-type', 'type');
          // rolloverTools.style.display = 'none';

          // const rolloverMove = document.createElement('div');
          // rolloverMove.classList.add('de-rollover-move');
          // rolloverMove.innerHTML = '<i class="fa fa-arrows"></i>';

          // const rolloverAdvance = document.createElement('div');
          // rolloverAdvance.classList.add('de-rollover-advance');
          // rolloverAdvance.innerHTML = '<i class="fa fa-cog"></i>';

          // const rolloverClone = document.createElement('div');
          // rolloverClone.classList.add('de-rollover-clone');
          // rolloverClone.innerHTML = '<i class="fa fa-copy"></i>';

          // const rolloverRemove = document.createElement('div');
          // rolloverRemove.classList.add('de-rollover-remove');
          // rolloverRemove.innerHTML = '<i class="fa fa-trash-o"></i>';

          // rolloverTools.appendChild(rolloverMove);
          // rolloverTools.appendChild(rolloverAdvance);
          // rolloverTools.appendChild(rolloverClone);
          // rolloverTools.appendChild(rolloverRemove);

          // Append elements to the countdown div
          countdownDiv.appendChild(countdownElement);
          countdownDiv.appendChild(countdownDemo);

          // Append columns to the countdown wrapper
          containercountdownWrapper.appendChild(countdownWrapper);

          countdownWrapper.appendChild(leftColumn);
          countdownWrapper.appendChild(rightColumn);

          rightColumn.appendChild(countdownDiv);

          // countdownWrapper.appendChild(rolloverTools);

          countdownWrapper.setAttribute("draggable", true);
          this.elementToInsert = containercountdownWrapper;
          this.existingElement = false;

          break;

        case "input-field":
          const inputWrapper = document.createElement("div");
          inputWrapper.classList.add(
            "draggable",
            "de",
            "elInputWrapper",
            "de-editable",
            "de-input-block",
            "elAlign_center",
            "elMargin0"
          );
          inputWrapper.setAttribute("id", `tmp_input-${Date.now()}`);
          inputWrapper.setAttribute("data-de-type", "input");
          inputWrapper.setAttribute("data-de-editing", "false");
          inputWrapper.setAttribute("data-title", "input");
          inputWrapper.setAttribute("data-ce", "false");
          inputWrapper.setAttribute("data-trigger", "none");
          inputWrapper.setAttribute("data-animate", "fade");
          inputWrapper.setAttribute("data-delay", "500");
          inputWrapper.style.marginTop = "30px";
          inputWrapper.style.outline = "none";

          const inputElement = document.createElement("input");
          inputElement.type = "text";

          inputElement.placeholder = "Your Name Here...";
          inputElement.name = "name"; //not-set
          inputElement.classList.add(
            "elInput",
            "elInput100",
            "elAlign_left",
            "elInputMid",
            "elInputStyl0",
            "elInputBG1",
            "elInputBR5",
            "elInputI0",
            "elInputIBlack",
            "elInputIRight",
            "required0",
            "ceoinput"
          );
          inputElement.dataset.type = "extra";
          inputElement.style.width = "100%"; // This sets the input field to full width

          // Create rollover tools div
          // const rolloverTools = document.createElement('div');
          // rolloverTools.classList.add('de-rollover-tools', 'smallWidthElementHover');
          // rolloverTools.setAttribute('data-current-id', 'nill');
          // rolloverTools.setAttribute('data-current-type', 'type');
          // rolloverTools.style.display = 'none';

          // Add move, advance, clone, and remove buttons to rollover tools
          moveButton = document.createElement("div");
          moveButton.classList.add("de-rollover-move");
          moveButton.innerHTML = '<i class="fa fa-arrows"></i>';

          advanceButton = document.createElement("div");
          advanceButton.classList.add("de-rollover-advance");
          advanceButton.innerHTML = '<i class="fa fa-cog"></i>';

          cloneButton = document.createElement("div");
          cloneButton.classList.add("de-rollover-clone");
          cloneButton.innerHTML = '<i class="fa fa-copy"></i>';

          removeButton = document.createElement("div");
          removeButton.classList.add("de-rollover-remove");
          removeButton.innerHTML = '<i class="fa fa-trash-o"></i>';

          // Append input and rollover tools to the wrapper
          inputWrapper.appendChild(inputElement);
          // inputWrapper.appendChild(rolloverTools);

          // Create addElementFlyoutDOM
          addElementFlyoutDOM = document.createElement("div");
          addElementFlyoutDOM.classList.add("addElementFlyoutDOM");
          addElementFlyoutDOM.style.display = "none";
          addElementFlyoutDOM.style.left = "325px";
          addElementFlyoutDOM.innerHTML = '<i class="fa fa-plus"></i>';

          inputWrapper.appendChild(addElementFlyoutDOM);

          // Set the draggable attribute
          inputWrapper.setAttribute("draggable", true);

          this.elementToInsert = inputWrapper;
          this.existingElement = false;
          break;

        case "email-field":
          const emailWrapper = document.createElement("div");
          emailWrapper.classList.add(
            "draggable",
            "de",
            "elemailWrapper",
            "de-editable",
            "de-input-block",
            "elAlign_center",
            "elMargin0"
          );
          emailWrapper.setAttribute("id", `tmp_input-${Date.now()}`);
          emailWrapper.setAttribute("data-de-type", "input");
          emailWrapper.setAttribute("data-de-editing", "false");
          emailWrapper.setAttribute("data-title", "input");
          emailWrapper.setAttribute("data-ce", "false");
          emailWrapper.setAttribute("data-trigger", "none");
          emailWrapper.setAttribute("data-animate", "fade");
          emailWrapper.setAttribute("data-delay", "500");
          emailWrapper.style.marginTop = "30px";
          emailWrapper.style.outline = "none";

          const emailElement = document.createElement("input");
          emailElement.type = "text";
          emailElement.placeholder = "Your Email Address Here...";
          emailElement.name = "email";
          emailElement.classList.add(
            "elInput",
            "elInput100",
            "elAlign_left",
            "elInputMid",
            "elInputStyl0",
            "elInputBG1",
            "elInputBR5",
            "elInputI0",
            "elInputIBlack",
            "elInputIRight",
            "required0",
            "ceoinput"
          );
          emailElement.dataset.type = "extra";
          emailElement.style.width = "100%"; // This sets the input field to full width

          // Create rollover tools div
          // const rolloverTools = document.createElement('div');
          // rolloverTools.classList.add('de-rollover-tools', 'smallWidthElementHover');
          // rolloverTools.setAttribute('data-current-id', 'nill');
          // rolloverTools.setAttribute('data-current-type', 'type');
          // rolloverTools.style.display = 'none';

          // Add move, advance, clone, and remove buttons to rollover tools
          moveButton = document.createElement("div");
          moveButton.classList.add("de-rollover-move");
          moveButton.innerHTML = '<i class="fa fa-arrows"></i>';

          advanceButton = document.createElement("div");
          advanceButton.classList.add("de-rollover-advance");
          advanceButton.innerHTML = '<i class="fa fa-cog"></i>';

          cloneButton = document.createElement("div");
          cloneButton.classList.add("de-rollover-clone");
          cloneButton.innerHTML = '<i class="fa fa-copy"></i>';

          removeButton = document.createElement("div");
          removeButton.classList.add("de-rollover-remove");
          removeButton.innerHTML = '<i class="fa fa-trash-o"></i>';

          // Append input and rollover tools to the wrapper
          emailWrapper.appendChild(emailElement);
          // emailWrapper.appendChild(rolloverTools);

          // Create addElementFlyoutDOM
          addElementFlyoutDOM = document.createElement("div");
          addElementFlyoutDOM.classList.add("addElementFlyoutDOM");
          addElementFlyoutDOM.style.display = "none";
          addElementFlyoutDOM.style.left = "325px";
          addElementFlyoutDOM.innerHTML = '<i class="fa fa-plus"></i>';

          emailWrapper.appendChild(addElementFlyoutDOM);

          // Set the draggable attribute
          emailWrapper.setAttribute("draggable", true);

          this.elementToInsert = emailWrapper;
          this.existingElement = false;
          break;

        // case 'text-field':
        //   elementToInsert = document.createElement('input');
        //   elementToInsert.classList.add('draggable');
        //   elementToInsert.setAttribute('draggable', true);
        //   elementToInsert.setAttribute('placeholder', 'Text');
        //   elementToInsert.setAttribute('disabled', true);
        //   elementToInsert.setAttribute('id', `field-${Date.now()}`);
        //   this.elementToInsert = elementToInsert;
        //   this.existingElement = false;
        //   break;

        // case 'email-field':
        //   elementToInsert = document.createElement('input');
        //   elementToInsert.classList.add('draggable');
        //   elementToInsert.setAttribute('draggable', true);
        //   elementToInsert.setAttribute('placeholder', 'Email');
        //   elementToInsert.setAttribute('disabled', true);
        //   elementToInsert.setAttribute('id', `field-${Date.now()}`);
        //   this.elementToInsert = elementToInsert;
        //   this.existingElement = false;
        //   break;

        case "phone-field":
          elementToInsert = document.createElement("input");

          elementToInsert.classList.add("draggable");
          elementToInsert.setAttribute("draggable", true);
          elementToInsert.setAttribute("placeholder", "Phone");
          elementToInsert.setAttribute("disabled", true);
          elementToInsert.setAttribute("id", `field-${Date.now()}`);
          this.elementToInsert = elementToInsert;
          this.existingElement = false;
          break;
        default:
          this.elementToInsert = draggable;
          this.existingElement = true;
          break;
      }
    } else {
      this.existingElement = true;
      this.elementToInsert = draggable;
    }
    this.placeholder.setAttribute("id", `placeholder-${Date.now()}`);
    draggable.classList.add("dragging");
  };

  this.onDragEnd = function (e, draggable) {
    //update the main conatiner and popup container so it can be saved
    draggable.classList.remove("dragging");
    updateTextareaFromContainer(
      "da-main-container",
      "step[large_html_blob_content]"
    );
    updateTextareaFromContainer(
      "da-popup-container",
      "step[popup_html_blob_content]"
    );

    console.log("drag end", this.elementToInsert);

    // Add a click event listener for settings sidebar

    console.log("adding elSettings");
    var settingsSidebar = document.getElementById("settingsSidebar");
    var anchor = this.elementToInsert.querySelector("a.elSettings"); // Find the anchor element within 'this'

    if (anchor) {
      anchor.addEventListener("click", function (event) {
        event.preventDefault(); // Prevent the default behavior

        if (settingsSidebar.style.left === "0px") {
          closeSidebar();
          // console.log('closing inside');
        } else {
          openSidebar(this);
          // console.log('opening inside');
        }
      });
    }

    if (!this.existingElement) {
      this.addEventListenerForDraggableItem(this.elementToInsert);
      this.updateDraggables("draggables");
    } else {
      console.log("existing ele", this.elementToInsert);
      this.elementToInsert.classList.remove("dragging");
    }
  };

  this.addEventListenerForDraggableItem = function (element) {
    console.log("ele", element);
    element.addEventListener("dragstart", (e) => this.onDragStart(e, element));
    element.addEventListener("dragend", (e) => this.onDragEnd(e, element));

    const elHeadlineElements = element.querySelectorAll(
      ".elHeadline, .elText, .elSubHeadline"
    ); // Select .elHeadline elements inside the div

    // Add click event listener for content editing to each .elHeadline element
    elHeadlineElements.forEach((elHeadlineElement) => {
      elHeadlineElement.addEventListener("mousedown", function () {
        console.log("clicked to edit");
        elHeadlineElement.setAttribute("contenteditable", "true");
        elHeadlineElement.style.cursor = "text";
      });
    });
  };

  this.addEventListenersForContainer = function (container) {
    container.addEventListener("dragover", (e) =>
      this.onDragHover(e, container, false)
    );
    container.addEventListener("drop", (e) => this.onDragDrop(e), false);
    container.addEventListener("dragleave", (e) => this.onDragLeave(e), false);
    container.addEventListener("dragenter", (e) => this.onDragEnter(e), false);
  };

  this.onDragHover = function (e, container) {
    e.preventDefault();
    this.afterElement = this.getDragAfterElement(container, e.clientY);
    if (this.afterElement == null) {
      container.appendChild(this.placeholder);
    } else {
      container.insertBefore(this.placeholder, this.afterElement);
    }
  };
  this.onDragEnter = function (e) {
    e.preventDefault();
  };
  this.onDragLeave = function (e) {
    e.preventDefault();
  };

  this.onDragDrop = function (e) {
    e.preventDefault();
    // let data = e.dataTransfer.getData("elementid");
    this.placeholder.replaceWith(this.elementToInsert);
  };

  this.init = function () {
    try {
      this.mainContainer = document.getElementById("da-main-container");
      this.popupContainer = document.getElementById("da-popup-container");
      this.updateContainers();
      this.updateDraggables();
      this.addEventListeners();
      this.createPlaceHolder();
    } catch (e) {
      console.log(e);
    }
  };
}

function updateTextareaFromContainer(containerId, textareaName) {
  const mainContainer = document.getElementById(containerId);
  const textarea = document.querySelector(`textarea[name="${textareaName}"]`);
  if (mainContainer && textarea) {
    textarea.value = mainContainer.innerHTML;
  } else {
    console.error("Container or textarea not found");
  }
}

function isPopupOpen() {
  var popup = document.querySelector(".popup-container");
  return popup.classList.contains("open"); // Or check the display style
}

// document.addEventListener('turbolinks:load', () => {
//   const customDragnDrop = new CustomDragAndDrop();
//   customDragnDrop.init();
//   customDragnDrop.loadSections();
// });

// $(document).ready(function () { // This one seems to work when it just loads the page 1st time but the rest of the times it works when loads under in $(document).off().on('ready turbolinks:load'
//   let customDragnDrop = new CustomDragAndDrop();
//   customDragnDrop.init();
//   customDragnDrop.loadSections(); // this one should load again
// });

// * MAIN CODE SECTION ------------------------------------------------------------------

var customDragnDropInitialized = false;

// document.addEventListener('turbolinks:load', () => {
document.addEventListener("DOMContentLoaded", function (e) {
  if (!customDragnDropInitialized) {
    const customDragnDrop = new CustomDragAndDrop();
    customDragnDrop.init();
    console.log("customDragnDropInitialized=true");
    customDragnDrop.loadSections();
    console.log("we loaded the Sections");
    customDragnDropInitialized = true;
    // Add a click event listener to the button
    const addSectionButton = document.getElementById("add-section-button");
    if (addSectionButton) {
      addSectionButton.addEventListener("click", () => {
        customDragnDrop.addSection();
      });
    }
  } else {
  }
});

//here we will add the listener to save the HTML before they submit the form
document.addEventListener("DOMContentLoaded", function () {
  const formWrapper = document.getElementById("editorFormWrapper");
  const form = formWrapper.querySelector("form");

  if (form) {
    form.addEventListener("submit", function (e) {
      // Prevent the form from submitting immediately.
      e.preventDefault();

      // Call the updateTextareaFromContainer function.
      updateTextareaFromContainer(
        "da-main-container",
        "step[large_html_blob_content]"
      );
      updateTextareaFromContainer(
        "da-popup-container",
        "step[popup_html_blob_content]"
      );
      console.log("save it");
      // Now, you can choose to submit the form manually.
      form.submit();
    });
  }
});

// The popup START
const openPopupButton = document.getElementById("open-popup");
const closePopupButton = document.getElementById("close-popup");
const popupContainer = document.querySelector(".popup-container");
const thebody = document.querySelector("body");
const damaincontainer = document.getElementById("da-main-container");

openPopupButton.addEventListener("click", function (event) {
  event.preventDefault();

  // Display the popup
  popupContainer.classList.add("open");

  popupContainer.style.display = "block";
  thebody.style.backgroundColor = "rgba(100, 100, 100, 0.1)"; // Red with 50% opacity
  // damaincontainer.style.opacity = 0.5;
  damaincontainer.style.display = "none"; // Set the background color to red
});

closePopupButton.addEventListener("click", function (event) {
  event.preventDefault();
  popupContainer.classList.remove("open");
  popupContainer.style.display = "none";
  damaincontainer.style.display = "block"; // Set the background color to red
});
// The popup END

//------------------------------------------------------------------
//settingsSidebar

let selectedElSettings = null; // Global variable to store the selected .elSettings element

// Select all anchor elements within elements with class "elSettings"
var elSettingsAnchors = document.querySelectorAll("a.elSettings ");
var settingsSidebar = document.getElementById("settingsSidebar");

function openSidebar(element) {
  selectedElSettings = element.id; // Store the clicked element's ID
  settingsSidebar.style.left = "0";
  loadPresetSettings(element);
}

function closeSidebar() {
  selectedElSettings = null;
  settingsSidebar.style.left = "-100%";
}

// Attach the click event to each anchor element within "elSettings" buttons
elSettingsAnchors.forEach(function (anchor) {
  anchor.addEventListener("click", function (event) {
    event.preventDefault(); // Prevent the default behavior
    if (settingsSidebar.style.left === "0px") {
      closeSidebar();
      // console.log('closing outside');
    } else {
      // console.log('opening outside');
      openSidebar(this);
    }
  });
});

// hide the url input -- this is only when the page is already loaded -- it looks like the code  in the loadPresetSettings, but we need this too

const urlInputContainers = document.querySelectorAll(".url-input-container");
const actionSelect = document.getElementById("action-select");

actionSelect.addEventListener("change", () => {
  const selectedValue = actionSelect.value;
  urlInputContainers.forEach((container) => {
    if (selectedValue === "#") {
      container.style.display = "flex";
      const urlInput = document.getElementById("url-input");
      if (urlInput.value.trim() === "") {
        urlInput.value = "#";
      }
    } else {
      container.style.display = "none";
    }
  });
});

function loadPresetSettings(element) {
  // Action select dropdown -----------------------------------------
  const urlInputContainers = document.querySelectorAll(".url-input-container");
  const actionSelect = document.getElementById("action-select");
  const actionText = document.getElementById(selectedElSettings);
  const urlInput = document.getElementById("url-input");

  // Initialize the dropdown with the current value of the href attribute
  readHref = actionText.getAttribute("href");
  if (
    readHref === "#open-popup" ||
    readHref === "#submit-form" ||
    readHref === "#"
  ) {
    actionSelect.value = readHref;
  } else {
    actionSelect.value = "#";
    urlInput.value = readHref;
  }

  urlInputContainers.forEach((container) => {
    //if doesn't equal those vals the show the field
    if (!(readHref === "#open-popup" || readHref === "#submit-form")) {
      container.style.display = "flex";
      if (urlInput.value.trim() === "") {
        urlInput.value = "#";
      }
    } else {
      container.style.display = "none";
    }
  });

  // Listen for changes in the dropdown value----------------
  actionSelect.addEventListener("change", function () {
    if (selectedElSettings) {
      const targetElement = document.getElementById(selectedElSettings);
      // Update the href attribute with the selected value from the dropdown
      targetElement.setAttribute("href", actionSelect.value);
    }
  });

  // Listen for changes in the url value---------------------
  urlInput.addEventListener("input", function () {
    if (selectedElSettings) {
      const targetElement = document.getElementById(selectedElSettings);
      // Update the href attribute with the selected value from the dropdown
      targetElement.setAttribute("href", urlInput.value);
      // console.log(urlInput.value);
    }
  });
  // buttonTextInput -----------------------------------------
  // const buttonTextInput = document.getElementById('button-text-input');
  // const buttonText = document.getElementById(selectedElSettings);
  // buttonTextInput.value = buttonText.textContent;

  // fontSizeSlider -----------------------------------------
  const fontSizeSlider = document.getElementById("font-size-slider");
  // Get the initial font size from the selected element
  const initialFontSize = window.getComputedStyle(element).fontSize;
  // Set the slider value to the initial font size
  fontSizeSlider.value = parseFloat(initialFontSize);
  // Listen for changes in the slider value
  fontSizeSlider.addEventListener("input", function () {
    if (selectedElSettings) {
      // Apply the font size to the selected .elSettings element
      const targetElement = document.getElementById(selectedElSettings);
      const fontSize = this.value;
      targetElement.style.fontSize = fontSize + "px";
    }
  });

  // buttonTextInput -----------------------------------------
  const buttonTextInput = document.getElementById("button-text-input");
  const buttonText = document.getElementById(selectedElSettings);
  buttonTextInput.value = buttonText.textContent;
  // Listen for changes in buttonTextInput
  buttonTextInput.addEventListener("input", function () {
    if (selectedElSettings) {
      const targetElement = document.getElementById(selectedElSettings);
      targetElement.innerHTML = this.value;
    }
  });

  // font family dropdown -----------------------------------------
  const fontFamilySelect = document.getElementById("font-family-select");
  const selectText = document.getElementById(selectedElSettings); // Get the element by its ID
  fontFamilySelect.value = selectText.style.fontFamily.replace(/['"]/g, "");

  // Listen for changes for font-----------------------------
  fontFamilySelect.addEventListener("change", function () {
    if (selectedElSettings) {
      const targetElement = document.getElementById(selectedElSettings);

      targetElement.style.fontFamily = fontFamilySelect.value;
    }
  });
}
