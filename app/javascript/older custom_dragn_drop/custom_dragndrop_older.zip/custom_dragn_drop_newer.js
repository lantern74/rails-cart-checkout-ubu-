var setSectionWidthPopup = document.getElementById("setSectionWidthPopup");
var setColumnNumberPopup = document.getElementById("setColumnNumberPopup");
var setTwoStepOrderPopup = document.getElementById("setTwoStepOrderPopup");
var setSectionPopup = document.getElementById("setSectionPopup");
var setColumnPopup = document.getElementById("setColumnPopup");
var setImagePopup = document.getElementById("setImagePopup");
var setVideoPopup = document.getElementById("setVideoPopup");
var marginPaddingPopup = document.getElementById("marginPaddingPopup");
var setHeadlinePopup = document.getElementById("setHeadlinePopup");
var settingsSidebar = document.getElementById("settingsSidebar");
var leftSlidingPopup = document.getElementById("leftSlidingPopup");
var openElementsPanel = document.getElementById("add-element-button");
var basicContainerSection = document.getElementById("basic-container");
var mainContainerSection = document.getElementById("da-main-container");
var popupContainerSection = document.getElementById("da-popup-container");
var settingFullWidth = document.getElementById("setting-full-width");
var settingWide = document.getElementById("setting-wide");
var settingMedium = document.getElementById("setting-medium");
var settingSmall = document.getElementById("setting-small");
var settingRow1 = document.getElementById("setting-row1");
var settingRow2 = document.getElementById("setting-row2");
var settingRow3 = document.getElementById("setting-row3");
var settingRow4 = document.getElementById("setting-row4");
var settingRow5 = document.getElementById("setting-row5");
var settingRow6 = document.getElementById("setting-row6");
var setValueWithNumber = document.getElementById("setValueWithNumber");
var setValueWithRange = document.getElementById("setValueWithRange");
var setUnit = document.getElementById("select-unit");
var setGreenMarginTop = document.getElementById("setGreenMarginTop");
var setGreenMarginBottom = document.getElementById("setGreenMarginBottom");
var setGreenPaddingTop = document.getElementById("setGreenPaddingTop");
var setGreenPaddingLeft = document.getElementById("setGreenPaddingLeft");
var setGreenPaddingRight = document.getElementById("setGreenPaddingRight");
var setGreenPaddingBottom = document.getElementById("setGreenPaddingBottom");
var setBlueMarginTop = document.getElementById("setBlueMarginTop");
var setBlueMarginBottom = document.getElementById("setBlueMarginBottom");
var setBluePaddingTop = document.getElementById("setBluePaddingTop");
var setBluePaddingLeft = document.getElementById("setBluePaddingLeft");
var setBluePaddingRight = document.getElementById("setBluePaddingRight");
var setBluePaddingBottom = document.getElementById("setBluePaddingBottom");
var setOrangeMarginTop = document.getElementById("setOrangeMarginTop");
var setOrangeMarginBottom = document.getElementById("setOrangeMarginBottom");
var setOrangePaddingTop = document.getElementById("setOrangePaddingTop");
var setOrangePaddingLeft = document.getElementById("setOrangePaddingLeft");
var setOrangePaddingRight = document.getElementById("setOrangePaddingRight");
var setOrangePaddingBottom = document.getElementById("setOrangePaddingBottom");
var setCombMarginTop = document.getElementById("setCombMarginTop");
var setCombMarginBottom = document.getElementById("setCombMarginBottom");
var setCombPaddingTop = document.getElementById("setCombPaddingTop");
var setCombPaddingLeft = document.getElementById("setCombPaddingLeft");
var setCombPaddingRight = document.getElementById("setCombPaddingRight");
var setCombPaddingBottom = document.getElementById("setCombPaddingBottom");
var setButtonMarginTop = document.getElementById("setButtonMarginTop");
var setButtonMarginBottom = document.getElementById("setButtonMarginBottom");
var setButtonPaddingTop = document.getElementById("setButtonPaddingTop");
var setButtonPaddingLeft = document.getElementById("setButtonPaddingLeft");
var setButtonPaddingRight = document.getElementById("setButtonPaddingRight");
var setButtonPaddingBottom = document.getElementById("setButtonPaddingBottom");
var setImageMarginTop = document.getElementById("setImageMarginTop");
var setImageMarginBottom = document.getElementById("setImageMarginBottom");
var setImagePaddingTop = document.getElementById("setImagePaddingTop");
var setImagePaddingLeft = document.getElementById("setImagePaddingLeft");
var setImagePaddingRight = document.getElementById("setImagePaddingRight");
var setImagePaddingBottom = document.getElementById("setImagePaddingBottom");
var setVideoMarginTop = document.getElementById("setVideoMarginTop");
var setVideoMarginBottom = document.getElementById("setVideoMarginBottom");
var setVideoPaddingTop = document.getElementById("setVideoPaddingTop");
var setVideoPaddingLeft = document.getElementById("setVideoPaddingLeft");
var setVideoPaddingRight = document.getElementById("setVideoPaddingRight");
var setVideoPaddingBottom = document.getElementById("setVideoPaddingBottom");
var settingGreenMarginPaddingValue = document.getElementsByClassName(
  "settingMarginPaddingValue"
)[0];
var settingBlueMarginPaddingValue = document.getElementsByClassName(
  "settingMarginPaddingValue"
)[1];
var settingOrangeMarginPaddingValue = document.getElementsByClassName(
  "settingMarginPaddingValue"
)[2];
var settingCombMarginPaddingValue = document.getElementsByClassName(
  "settingMarginPaddingValue"
)[3];
var settingImageMarginPaddingValue = document.getElementsByClassName(
  "settingMarginPaddingValue"
)[4];
var settingVideoMarginPaddingValue = document.getElementsByClassName(
  "settingMarginPaddingValue"
)[5];
var settingButtonMarginPaddingValue = document.getElementsByClassName(
  "settingMarginPaddingValue"
)[6];
var id = undefined;
var draggables = undefined;
var containers = undefined;
var placeholder = undefined;
var elementToInsert = "";
var afterElement = undefined;
var sectionCount = 0;
var mainContainer = undefined;
var popupContainer = undefined;
var existingElement = undefined;
var settingMarginPadding;
var buttonContainerId;

settingFullWidth.addEventListener("click", function () {
  createContainer("100%");
});
settingWide.addEventListener("click", function () {
  createContainer("80%");
});
settingMedium.addEventListener("click", function () {
  createContainer("60%");
});
settingSmall.addEventListener("click", function () {
  createContainer("50%");
});

function createContainer(width) {
  var container = document.createElement("div");
  var key = new Date().getTime();
  container.setAttribute("id", key);
  container.classList.add("editor-container", "new-section", "new-container");
  container.style.width = width;
  setSectionWidthPopup.style.right = "-350px";

  if (isPopupOpen()) {
    popupContainerSection.appendChild(container);
  } else {
    mainContainerSection.appendChild(container);
  }

  var greenRolloverTools = document.createElement("div");
  greenRolloverTools.classList.add(
    "de-rollover-tools",
    "smallWidthElementHover",
    "d-flex",
    "flex-column"
  );
  greenRolloverTools.style.display = "none";

  var greenArrowRolloverTools = document.createElement("div");
  greenArrowRolloverTools.classList.add(
    "arrow-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex",
    "flex-column"
  );
  greenArrowRolloverTools.style.display = "none";

  var greenPlusRolloverTools = document.createElement("div");
  greenPlusRolloverTools.classList.add(
    "plus-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex",
    "flex-column"
  );
  var greenAddRowRolloverTools = document.createElement("div");
  greenAddRowRolloverTools.classList.add(
    "add-row-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex"
  );
  var greenAddRowPlusRolloverTools = document.createElement("div");
  greenAddRowPlusRolloverTools.style.position = "relative";

  greenPlusRolloverTools.style.display = "none";

  var greenMoveButton = document.createElement("div");
  greenMoveButton.classList.add("de-rollover-move");
  greenMoveButton.style.backgroundColor = "#37ca37";
  greenMoveButton.style.display = "none";
  greenMoveButton.setAttribute("type", "button");
  greenMoveButton.innerHTML = '<i class="fa fa-arrows"></i>';
  greenMoveButton.style.cursor = "move";

  var greenAdvanceButton = document.createElement("div");
  greenAdvanceButton.classList.add("de-rollover-advance");
  greenAdvanceButton.style.backgroundColor = "#37ca37";
  greenAdvanceButton.style.display = "none";
  greenAdvanceButton.setAttribute("type", "button");
  greenAdvanceButton.setAttribute("id", `green_advanced-${Date.now()}`);
  greenAdvanceButton.innerHTML = '<i class="fa fa-cog"></i>';
  greenAdvanceButton.setAttribute(
    "onclick",
    "greenGearElement(parentElement.parentElement.id)"
  );

  var greenCloneButton = document.createElement("div");
  greenCloneButton.classList.add("de-rollover-clone");
  greenCloneButton.style.backgroundColor = "#37ca37";
  greenCloneButton.style.display = "none";
  greenCloneButton.setAttribute("type", "button");
  greenCloneButton.innerHTML = '<i class="fa fa-copy"></i>';

  var greenRemoveButton = document.createElement("div");
  greenRemoveButton.classList.add("de-rollover-remove");
  greenRemoveButton.style.backgroundColor = "#37ca37";
  greenRemoveButton.style.display = "none";
  greenRemoveButton.setAttribute("type", "button");
  greenRemoveButton.innerHTML = '<i class="fa fa-trash"></i>';
  greenRemoveButton.setAttribute(
    "onclick",
    "removeElement(parentElement.parentElement)"
  );

  var greenArrowUpButton = document.createElement("div");
  greenArrowUpButton.classList.add("de-rollover-arrow-up");
  greenArrowUpButton.style.backgroundColor = "#37ca37";
  greenArrowUpButton.style.display = "none";
  greenArrowUpButton.setAttribute("type", "button");
  greenArrowUpButton.innerHTML = '<i class="fa fa-arrow-up"></i>';
  greenArrowUpButton.setAttribute(
    "onclick",
    "moveUp(parentElement.parentElement)"
  );

  var greenArrowDownButton = document.createElement("div");
  greenArrowDownButton.classList.add("de-rollover-arrow-down");
  greenArrowDownButton.style.backgroundColor = "#37ca37";
  greenArrowDownButton.style.display = "none";
  greenArrowDownButton.setAttribute("type", "button");
  greenArrowDownButton.innerHTML = '<i class="fa fa-arrow-down"></i>';
  greenArrowDownButton.setAttribute(
    "onclick",
    "moveDown(parentElement.parentElement)"
  );

  var greenPlusCircle = document.createElement("div");
  greenPlusCircle.classList.add("de-rollover-plus-circle");
  greenPlusCircle.style.backgroundColor = "#37ca37";
  greenPlusCircle.style.display = "none";
  greenPlusCircle.style.position = "relative";
  greenPlusCircle.style.left = "-50%";
  greenPlusCircle.setAttribute("type", "button");
  greenPlusCircle.innerHTML = '<i class="fa fa-plus"></i>';

  var greenAddRowPlusButton = document.createElement("div");
  greenAddRowPlusButton.innerHTML = '<i class="fa fa-plus"></i>';
  greenAddRowPlusButton.classList.add("add-row-plus-de-rollover-tools");

  var greenAddRowButton = document.createElement("div");
  greenAddRowButton.innerHTML = '<button class="add-row"> + Add Row</button>';
  greenAddRowButton.style.backgroundColor = "#37ca37";
  greenAddRowButton.style.borderRadius = "3px";
  greenAddRowButton.style.display = "none";

  greenRolloverTools.appendChild(greenMoveButton);
  greenRolloverTools.appendChild(greenCloneButton);
  greenRolloverTools.appendChild(greenRemoveButton);
  greenArrowRolloverTools.appendChild(greenArrowUpButton);
  greenArrowRolloverTools.appendChild(greenArrowDownButton);
  greenArrowRolloverTools.appendChild(greenAdvanceButton);
  greenPlusRolloverTools.appendChild(greenPlusCircle);
  greenAddRowRolloverTools.appendChild(greenAddRowButton);
  greenAddRowPlusRolloverTools.appendChild(greenAddRowPlusButton);

  container.appendChild(greenRolloverTools);
  container.appendChild(greenArrowRolloverTools);
  container.appendChild(greenPlusRolloverTools);
  container.appendChild(greenAddRowRolloverTools);
  container.appendChild(greenAddRowPlusRolloverTools);
  
  sectionControl(container);
}
function sectionControl(container) {
  var greenRolloverTools = container.childNodes[0];
  var greenArrowRolloverTools = container.childNodes[1];
  var greenPlusRolloverTools = container.childNodes[2];
  var greenAddRowRolloverTools = container.childNodes[3];
  var greenAddRowPlusRolloverTools = container.childNodes[4];
  var greenMoveButton = greenRolloverTools.childNodes[0];
  var greenCloneButton = greenRolloverTools.childNodes[1];
  var greenRemoveButton = greenRolloverTools.childNodes[2];
  var greenArrowUpButton = greenArrowRolloverTools.childNodes[0];
  var greenArrowDownButton = greenArrowRolloverTools.childNodes[1];
  var greenAdvanceButton = greenArrowRolloverTools.childNodes[2];
  var greenPlusCircle = greenPlusRolloverTools.childNodes[0];
  var greenAddRowButton = greenAddRowRolloverTools.childNodes[0];
  var greenAddRowPlusButton = greenAddRowPlusRolloverTools.childNodes[0];


  document.addEventListener("click", function(event) {
    const isSetSectionPopup = event.target === container && container.contains(event.target);
    if (isSetSectionPopup) {
      greenAdvanceButton.click();
    }
  })
  container.addEventListener("mouseenter", (e) => {
    greenRolloverTools.style.display = "block";
    greenArrowRolloverTools.style.display = "block";
    greenPlusRolloverTools.style.display = "block";
    greenAddRowRolloverTools.style.display = "block";
    greenMoveButton.style.display = "block";
    greenAdvanceButton.style.display = "block";
    greenCloneButton.style.display = "block";
    greenRemoveButton.style.display = "block";
    greenArrowUpButton.style.display = "block";
    greenArrowDownButton.style.display = "block";
    greenPlusCircle.style.display = "block";
    greenAddRowButton.style.display = "block";
    greenAddRowPlusButton.style.display = "none";
    if (container.childNodes[5]) {
      greenAddRowRolloverTools.style.display = "none";
      greenAddRowButton.style.display = "none";
    } else {
      greenAddRowRolloverTools.style.display = "block";
      greenAddRowButton.style.display = "block";
    }
    container.style.border = "1px solid #37ca37";
    container.style.position = "relative";
  });
  container.addEventListener("mouseleave", (e) => {
    greenRolloverTools.style.display = "none";
    greenArrowRolloverTools.style.display = "none";
    greenPlusRolloverTools.style.display = "none";
    greenAddRowRolloverTools.style.display = "none";
    greenMoveButton.style.display = "none";
    greenAdvanceButton.style.display = "none";
    greenCloneButton.style.display = "none";
    greenRemoveButton.style.display = "none";
    greenArrowUpButton.style.display = "none";
    greenArrowDownButton.style.display = "none";
    greenPlusCircle.style.display = "none";
    greenAddRowButton.style.display = "none";
    greenAddRowPlusButton.style.display = "block";
    if (container.childNodes[5]) {
      greenAddRowPlusButton.style.display = "none";
    } else {
      greenAddRowPlusButton.style.display = "block";
    }
    container.style.border = "none";
    container.style.position = "unset";
  });

  greenPlusCircle.addEventListener("click", function () {
    if (setSectionWidthPopup.style.right === "0px") {
      setSectionWidthPopup.style.right = "-350px"; // Slide out the popup
    } else {
      setSectionWidthPopup.style.right = "0px"; // Slide in the popup
    }
  });

  greenAddRowButton.addEventListener("click", function (e) {
    var target = e.target;
    let parentNode = target.parentNode.parentNode.parentNode;

    if (parentNode.classList.contains("new-container")) {
      id = parentNode.getAttribute("id");
    }

    if (setColumnNumberPopup.style.right === "0px") {
      setColumnNumberPopup.style.right = "-350px"; // Slide out the popup
    } else {
      setColumnNumberPopup.style.right = "0px"; // Slide in the popup
    }
  });

  greenCloneButton.addEventListener("click", function () {
    greenClone(this);
  });
}

function createRowSection() {
  var rowSection = document.createElement("div");
  var key = new Date().getTime();
  rowSection.setAttribute("id", "row-" + key);
  rowSection.classList.add("row-section");
  rowSection.style.margin = "auto";

  var blueRolloverTools = document.createElement("div");
  blueRolloverTools.classList.add(
    "de-rollover-tools",
    "smallWidthElementHover",
    "d-flex",
    "flex-column"
  );

  blueRolloverTools.style.display = "none";

  var blueArrowRolloverTools = document.createElement("div");
  blueArrowRolloverTools.classList.add(
    "arrow-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex",
    "flex-column"
  );
  blueArrowRolloverTools.style.display = "none";

  var bluePlusRolloverTools = document.createElement("div");
  bluePlusRolloverTools.classList.add(
    "plus-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex",
    "flex-column"
  );
  bluePlusRolloverTools.style.display = "none";

  var blueMoveButton = document.createElement("div");
  blueMoveButton.classList.add("de-rollover-move");
  blueMoveButton.style.backgroundColor = "#3a85ff";
  blueMoveButton.style.display = "none";
  blueMoveButton.style.zIndex = "10";
  blueMoveButton.innerHTML = '<i class="fa fa-arrows"></i>';
  blueMoveButton.style.cursor = "move";

  var blueRemoveButton = document.createElement("div");
  blueRemoveButton.classList.add("de-rollover-remove");
  blueRemoveButton.style.backgroundColor = "#3a85ff";
  blueRemoveButton.style.display = "none";
  blueRemoveButton.style.zIndex = "10";
  blueRemoveButton.innerHTML = '<i class="fa fa-trash"></i>';
  blueRemoveButton.setAttribute("type", "button");
  blueRemoveButton.setAttribute(
    "onclick",
    "removeElement(parentElement.parentElement)"
  );

  var blueArrowUpButton = document.createElement("div");
  blueArrowUpButton.classList.add("de-rollover-arrow-up");
  blueArrowUpButton.style.backgroundColor = "#3a85ff";
  blueArrowUpButton.style.display = "none";
  blueArrowUpButton.style.zIndex = "10";
  blueArrowUpButton.innerHTML = '<i class="fa fa-arrow-up"></i>';
  blueArrowUpButton.setAttribute("type", "button");
  blueArrowUpButton.setAttribute(
    "onclick",
    "rowMoveUp(parentElement.parentElement.parentElement)"
  );

  var blueArrowDownButton = document.createElement("div");
  blueArrowDownButton.classList.add("de-rollover-arrow-down");
  blueArrowDownButton.style.backgroundColor = "#3a85ff";
  blueArrowDownButton.style.display = "none";
  blueArrowDownButton.style.zIndex = "10";
  blueArrowDownButton.innerHTML = '<i class="fa fa-arrow-down"></i>';
  blueArrowDownButton.setAttribute("type", "button");
  blueArrowDownButton.setAttribute(
    "onclick",
    "rowMoveDown(parentElement.parentElement.parentElement)"
  );

  var blueCloneButton = document.createElement("div");
  blueCloneButton.classList.add("de-rollover-clone");
  blueCloneButton.style.backgroundColor = "#3a85ff";
  blueCloneButton.style.zIndex = "10";
  blueCloneButton.style.display = "none";
  blueCloneButton.innerHTML = '<i class="fa fa-copy"></i>';
  blueCloneButton.setAttribute("type", "button");
  blueCloneButton.setAttribute('onclick', "blueClone(this)");

  var blueGearButton = document.createElement("div");
  blueGearButton.classList.add("de-rollover-settings");
  blueGearButton.style.backgroundColor = "#3a85ff";
  blueGearButton.style.zIndex = "10";
  blueGearButton.style.display = "none";
  blueGearButton.innerHTML = '<i class="fa fa-cog"></i>';
  blueGearButton.setAttribute("type", "button");
  blueGearButton.setAttribute("id", `blue_gear-${Date.now()}`);
  blueGearButton.setAttribute(
    "onclick",
    "blueGearElement(parentElement.parentElement.id)"
  );

  var bluePlusCircle = document.createElement("div");
  bluePlusCircle.classList.add("de-rollover-plus-circle");
  bluePlusCircle.style.backgroundColor = "#3a85ff";
  bluePlusCircle.style.display = "none";
  bluePlusCircle.setAttribute("type", "button");
  bluePlusCircle.style.zIndex = "10";
  bluePlusCircle.style.position = "relative";
  bluePlusCircle.style.left = "-50%";
  bluePlusCircle.innerHTML = '<i class="fa fa-plus"></i>';
  bluePlusCircle.setAttribute("type", "button");

  rowSection.appendChild(blueRolloverTools);
  rowSection.appendChild(blueArrowRolloverTools);
  rowSection.appendChild(bluePlusRolloverTools);

  blueRolloverTools.appendChild(blueMoveButton);
  blueRolloverTools.appendChild(blueCloneButton);
  blueRolloverTools.appendChild(blueRemoveButton);
  blueArrowRolloverTools.appendChild(blueArrowUpButton);
  blueArrowRolloverTools.appendChild(blueArrowDownButton);
  blueArrowRolloverTools.appendChild(blueGearButton);
  bluePlusRolloverTools.appendChild(bluePlusCircle);

  rowControl(rowSection);
  return rowSection;
}


function rowControl(rowSection) {
  var blueRolloverTools = rowSection.childNodes[0];
  var blueArrowRolloverTools = rowSection.childNodes[1];
  var bluePlusRolloverTools = rowSection.childNodes[2];
  var blueMoveButton = blueRolloverTools.childNodes[0];
  var blueCloneButton = blueRolloverTools.childNodes[1];
  var blueRemoveButton = blueRolloverTools.childNodes[2];
  var blueArrowUpButton = blueArrowRolloverTools.childNodes[0];
  var blueArrowDownButton = blueArrowRolloverTools.childNodes[1];
  var blueGearButton = blueArrowRolloverTools.childNodes[2];
  var bluePlusCircle = bluePlusRolloverTools.childNodes[0];
  
  document.addEventListener("click", function(event) {
    const isSetRowPopup = event.target.parentNode === rowSection && rowSection.contains(event.target);
    if (isSetRowPopup) {
      blueGearButton.click();
    }
  })
  rowSection.addEventListener("mouseenter", (e) => {
    for (let i = 0; i < 3; i++) {
      rowSection.parentNode.childNodes[0].childNodes[i].style.display = "none";
    }
    for (let i = 0; i < 3; i++) {
      rowSection.parentNode.childNodes[1].childNodes[i].style.display = "none";
    }
    rowSection.parentNode.childNodes[2].childNodes[0].style.display = "none";
    blueRolloverTools.style.display = "block";
    blueArrowRolloverTools.style.display = "block";
    bluePlusRolloverTools.style.display = "block";
    blueMoveButton.style.display = "block";
    blueCloneButton.style.display = "block";
    blueRemoveButton.style.display = "block";
    blueArrowUpButton.style.display = "block";
    blueArrowDownButton.style.display = "block";
    blueGearButton.style.display = "block";
    bluePlusCircle.style.display = "block";
    rowSection.parentNode.style.border = "none";
    rowSection.style.border = "1px solid #3a85ff";
  });

  rowSection.addEventListener("mouseleave", (e) => {
    for (let i = 0; i < 3; i++) {
      rowSection.parentNode.childNodes[0].childNodes[i].style.display = "block";
    }
    for (let i = 0; i < 3; i++) {
      rowSection.parentNode.childNodes[1].childNodes[i].style.display = "block";
    }
    rowSection.parentNode.childNodes[2].childNodes[0].style.display = "block";
    blueRolloverTools.style.display = "none";
    blueArrowRolloverTools.style.display = "none";
    bluePlusRolloverTools.style.display = "none";
    blueMoveButton.style.display = "none";
    blueCloneButton.style.display = "none";
    blueRemoveButton.style.display = "none";
    blueArrowUpButton.style.display = "none";
    blueArrowDownButton.style.display = "none";
    blueGearButton.style.display = "none";
    bluePlusCircle.style.display = "none";
    rowSection.parentNode.style.border = "1px solid #37ca37";
    rowSection.style.border = "none";
  });
  bluePlusCircle.addEventListener("click", function () {
    if (setColumnNumberPopup.style.right === "0px") {
      setColumnNumberPopup.style.right = "-350px"; // Slide out the popup
    } else {
      setColumnNumberPopup.style.right = "0px"; // Slide in the popup
    }
  });
  // blueCloneButton.addEventListener("click", function () {
  //   var colDivNumber = rowSection.children.length - 3;
  //   if (colDivNumber == 1) {
  //     settingRow1.click();
  //   } else if (colDivNumber == 2) {
  //     settingRow2.click();
  //   } else if (colDivNumber == 3) {
  //     settingRow3.click();
  //   } else if (colDivNumber == 4) {
  //     settingRow4.click();
  //   } else if (colDivNumber == 5) {
  //     settingRow5.click();
  //   } else if (colDivNumber == 6) {
  //     settingRow6.click();
  //   }
  // });
}

function createDivCol1() {
  var divCol1 = document.createElement("div");
  divCol1.classList.add("col-div", "blue-container");
  divCol1.style.width = "100%";
  divCol1.style.borderRight = "none";
  return divCol1;
}
function createDivCol2() {
  var divCol2 = document.createElement("div");
  divCol2.classList.add("col-div");
  divCol2.style.width = "50%";
  return divCol2;
}
function createDivCol3() {
  var divCol3 = document.createElement("div");
  divCol3.style.width = "33.3%";
  divCol3.classList.add("col-div");
  return divCol3;
}
function createDivCol4() {
  var divCol4 = document.createElement("div");
  divCol4.style.width = "25%";
  divCol4.classList.add("col-div");
  return divCol4;
}
function createDivCol5() {
  var divCol5 = document.createElement("div");
  divCol5.style.width = "20%";
  divCol5.classList.add("col-div");
  return divCol5;
}
function createDivCol6() {
  var divCol6 = document.createElement("div");
  divCol6.style.width = "16.6%";
  divCol6.classList.add("col-div");
  return divCol6;
}

function addElement() {
  var blueAddElementRolloverTools = document.createElement("div");
  blueAddElementRolloverTools.classList.add(
    "add-row-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex"
  );
  var key = new Date().getTime();
  blueAddElementRolloverTools.setAttribute("id", "add-element-" + key);

  blueAddElementRolloverTools.style.display = "none";

  var blueAddElementButton = document.createElement("div");
  blueAddElementButton.innerHTML =
    '<button class="add-element"> + Add Element</button>';
  blueAddElementButton.style.display = "none";
  blueAddElementButton.setAttribute("id", `blue_add-${Date.now()}`);
  blueAddElementButton.setAttribute('onclick', 'openAddElementPopup(this)');

  blueAddElementRolloverTools.appendChild(blueAddElementButton);

  
  return blueAddElementRolloverTools;
}
let inputedField = '';
function openAddElementPopup(button) {
  if (leftSlidingPopup.classList.contains("hidden")) {
    leftSlidingPopup.classList.remove("hidden");
    basicContainerSection.style.maxWidth = "calc(100vw - 350px)";
    basicContainerSection.style.marginLeft = "350px";
  } else {
    closeElementsPanel();
  }

  const buttonIdKey = button.id.replace(/\d+/g, '');

  if (buttonIdKey === "blue_add-") {
    inputedField = button.parentNode.parentNode;
  } else if (buttonIdKey === "orange_add-") {
    inputedField = button.parentNode.parentNode.parentNode;
  } else if (buttonIdKey === "add-element-button") {
    const nodes = mainContainer.querySelectorAll("div.draggable");
    const lastChild = nodes[nodes.length - 1];
    inputedField = lastChild.parentNode;
  }
}

draggables = document.querySelectorAll('div.draggable[id]:not([id*="-"])');
if (draggables) {
  draggables.forEach((draggable) => {
    draggable.addEventListener(
      "click",
      (e) => addElementWithClickInput(e, draggable, inputedField),
      false
    );
  });
}


//Add Row Setting
settingRow1.addEventListener("click", function (e) {
  e.preventDefault();
  var rowSection = createRowSection();
  container = document.getElementById(id);

  container.appendChild(rowSection);
  var divCol1 = createDivCol1();
  rowSection.appendChild(divCol1);
  setColumnNumberPopup.style.right = "-350px";
  blueAddElementRolloverTools = addElement();
  divCol1.appendChild(blueAddElementRolloverTools);

  divCol1.addEventListener("mouseenter", (e) => {
    if (!divCol1.childNodes[1]) {
      divCol1.childNodes[0].style.display = "block";
      divCol1.childNodes[0].childNodes[0].style.display = "block";
    }
  });
  divCol1.addEventListener("mouseleave", (e) => {
    divCol1.childNodes[0].style.display = "none";
    divCol1.childNodes[0].childNodes[0].style.display = "none";
  });
  loadSections();
});
settingRow2.addEventListener("click", function (e) {
  e.preventDefault();
  var rowSection = createRowSection();
  container = document.getElementById(id);
  container.appendChild(rowSection);
  var divCol2 = createDivCol2();
  var divCol2_1 = createDivCol2();
  rowSection.appendChild(divCol2);
  rowSection.appendChild(divCol2_1);

  blueAddElementRolloverTools = addElement();
  blueAddElementRolloverTools1 = addElement();
  divCol2.appendChild(blueAddElementRolloverTools);
  divCol2_1.appendChild(blueAddElementRolloverTools1);

  setColumnNumberPopup.style.right = "-350px";
  rowSection.addEventListener("mouseenter", (e) => {
    divCol2.style.borderRight = "1px dotted #3a85ff";
    divCol2Boundary.style.display = "block";
    if (!divCol2.childNodes[2]) {
      divCol2.childNodes[0].style.display = "block";
      divCol2.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol2_1.childNodes[1]) {
      divCol2_1.childNodes[0].style.display = "block";
      divCol2_1.childNodes[0].childNodes[0].style.display = "block";
    }
  });
  rowSection.addEventListener("mouseleave", (e) => {
    divCol2.style.borderRight = "none";
    divCol2Boundary.style.display = "none";
    divCol2.childNodes[0].style.display = "none";
    divCol2_1.childNodes[0].style.display = "none";
    divCol2.childNodes[0].childNodes[0].style.display = "none";
    divCol2_1.childNodes[0].childNodes[0].style.display = "none";
  });

  // setting resize
  var divCol2Boundary = document.createElement("div");
  divCol2Boundary.classList.add("div-boundary");
  divCol2.appendChild(divCol2Boundary);

  var isResizing = false;
  var lastX;
  var resizingBoundary;
  var columnSize = rowSection.offsetWidth / 12;
  var columnNumber1;
  var columnNumber2;

  divCol2Boundary.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol2Boundary";
  });
  document.addEventListener("mousemove", function (e) {
    if (isResizing) {
      var offset = e.clientX - lastX;
      if (resizingBoundary === "divCol2Boundary") {
        var newWidth1 = divCol2.offsetWidth + offset;
        var newWidth2 = divCol2_1.offsetWidth - offset;
        divCol2.style.width = newWidth1 + "px";
        divCol2_1.style.width = newWidth2 + "px";
        columnNumber1 = Math.round(newWidth1 / columnSize);
        columnNumber2 = Math.round(newWidth2 / columnSize);
      }
      lastX = e.clientX;
    }
  });
  document.addEventListener("mouseup", function () {
    isResizing = false;
    divCol2.style.width = columnNumber1 * columnSize + "px";
    divCol2_1.style.width = columnNumber2 * columnSize + "px";
  });
  // configDragDrop();
  loadSections();
});
settingRow3.addEventListener("click", function (e) {
  e.preventDefault();
  var rowSection = createRowSection();
  container = document.getElementById(id);
  container.appendChild(rowSection);
  var divCol3 = createDivCol3();
  var divCol3_1 = createDivCol3();
  var divCol3_2 = createDivCol3();
  rowSection.appendChild(divCol3);
  rowSection.appendChild(divCol3_1);
  rowSection.appendChild(divCol3_2);
  setColumnNumberPopup.style.right = "-350px";

  blueAddElementRolloverTools = addElement();
  blueAddElementRolloverTools1 = addElement();
  blueAddElementRolloverTools2 = addElement();

  divCol3.appendChild(blueAddElementRolloverTools);
  divCol3_1.appendChild(blueAddElementRolloverTools1);
  divCol3_2.appendChild(blueAddElementRolloverTools2);

  rowSection.addEventListener("mouseenter", (e) => {
    divCol3.style.borderRight = "1px dotted #3a85ff";
    divCol3_1.style.borderRight = "1px dotted #3a85ff";
    divCol3Boundary1.style.display = "block";
    divCol3Boundary2.style.display = "block";
    if (!divCol3.childNodes[2]) {
      divCol3.childNodes[0].style.display = "block";
      divCol3.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol3_1.childNodes[2]) {
      divCol3_1.childNodes[0].style.display = "block";
      divCol3_1.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol3_2.childNodes[1]) {
      divCol3_2.childNodes[0].style.display = "block";
      divCol3_2.childNodes[0].childNodes[0].style.display = "block";
    }
  });
  rowSection.addEventListener("mouseleave", (e) => {
    divCol3.style.borderRight = "none";
    divCol3_1.style.borderRight = "none";
    divCol3Boundary1.style.display = "none";
    divCol3Boundary2.style.display = "none";
    divCol3.childNodes[0].style.display = "none";
    divCol3_1.childNodes[0].style.display = "none";
    divCol3_2.childNodes[0].style.display = "none";
    divCol3.childNodes[0].childNodes[0].style.display = "none";
    divCol3_1.childNodes[0].childNodes[0].style.display = "none";
    divCol3_2.childNodes[0].childNodes[0].style.display = "none";
  });

  // setting resize
  var divCol3Boundary1 = document.createElement("div");
  divCol3Boundary1.classList.add("div-boundary");
  divCol3.appendChild(divCol3Boundary1);
  var divCol3Boundary2 = document.createElement("div");
  divCol3Boundary2.classList.add("div-boundary");
  divCol3_1.appendChild(divCol3Boundary2);
  var isResizing = false;
  var lastX;
  var resizingBoundary;
  divCol3Boundary1.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol3Boundary1";
  });
  divCol3Boundary2.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol3Boundary2";
  });
  var columnSize = rowSection.offsetWidth / 12;
  var columnNumber1;
  var columnNumber2;
  var columnNumber3;
  document.addEventListener("mousemove", function (e) {
    if (isResizing) {
      var offset = e.clientX - lastX;

      if (resizingBoundary === "divCol3Boundary1") {
        var newWidth1 = divCol3.offsetWidth + offset;
        var newWidth2 = divCol3_1.offsetWidth - offset;
        divCol3.style.width = newWidth1 + "px";
        divCol3_1.style.width = newWidth2 + "px";

        columnNumber1 = Math.round(newWidth1 / columnSize);
        columnNumber2 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol3Boundary2") {
        var newWidth1 = divCol3_1.offsetWidth + offset;
        var newWidth2 = divCol3_2.offsetWidth - offset;
        divCol3_1.style.width = newWidth1 + "px";
        divCol3_2.style.width = newWidth2 + "px";
        columnNumber2 = Math.round(newWidth1 / columnSize);
        columnNumber3 = Math.round(newWidth2 / columnSize);
      }

      lastX = e.clientX;
    }
  });
  document.addEventListener("mouseup", function () {
    isResizing = false;
    divCol3.style.width = columnNumber1 * columnSize + "px";
    divCol3_1.style.width = columnNumber2 * columnSize + "px";
    divCol3_2.style.width = columnNumber3 * columnSize + "px";
  });
  // configDragDrop();
  loadSections();
});
settingRow4.addEventListener("click", function (e) {
  e.preventDefault();
  var rowSection = createRowSection();
  container = document.getElementById(id);
  container.appendChild(rowSection);
  var divCol4 = createDivCol4();
  var divCol4_1 = createDivCol4();
  var divCol4_2 = createDivCol4();
  var divCol4_3 = createDivCol4();
  rowSection.appendChild(divCol4);
  rowSection.appendChild(divCol4_1);
  rowSection.appendChild(divCol4_2);
  rowSection.appendChild(divCol4_3);
  setColumnNumberPopup.style.right = "-350px";

  blueAddElementRolloverTools = addElement();
  blueAddElementRolloverTools1 = addElement();
  blueAddElementRolloverTools2 = addElement();
  blueAddElementRolloverTools3 = addElement();
  divCol4.appendChild(blueAddElementRolloverTools);
  divCol4_1.appendChild(blueAddElementRolloverTools1);
  divCol4_2.appendChild(blueAddElementRolloverTools2);
  divCol4_3.appendChild(blueAddElementRolloverTools3);

  rowSection.addEventListener("mouseenter", (e) => {
    divCol4.style.borderRight = "1px dotted #3a85ff";
    divCol4_1.style.borderRight = "1px dotted #3a85ff";
    divCol4_2.style.borderRight = "1px dotted #3a85ff";
    divCol4Boundary1.style.display = "block";
    divCol4Boundary2.style.display = "block";
    divCol4Boundary3.style.display = "block";
    if (!divCol4.childNodes[2]) {
      divCol4.childNodes[0].style.display = "block";
      divCol4.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol4_1.childNodes[2]) {
      divCol4_1.childNodes[0].style.display = "block";
      divCol4_1.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol4_2.childNodes[2]) {
      divCol4_2.childNodes[0].style.display = "block";
      divCol4_2.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol4_3.childNodes[1]) {
      divCol4_3.childNodes[0].style.display = "block";
      divCol4_3.childNodes[0].childNodes[0].style.display = "block";
    }
  });
  rowSection.addEventListener("mouseleave", (e) => {
    divCol4.style.borderRight = "none";
    divCol4_1.style.borderRight = "none";
    divCol4_2.style.borderRight = "none";
    divCol4Boundary1.style.display = "none";
    divCol4Boundary2.style.display = "none";
    divCol4Boundary3.style.display = "none";
    divCol4.childNodes[0].style.display = "none";
    divCol4_1.childNodes[0].style.display = "none";
    divCol4_2.childNodes[0].style.display = "none";
    divCol4_3.childNodes[0].style.display = "none";
    divCol4.childNodes[0].childNodes[0].style.display = "none";
    divCol4_1.childNodes[0].childNodes[0].style.display = "none";
    divCol4_2.childNodes[0].childNodes[0].style.display = "none";
    divCol4_3.childNodes[0].childNodes[0].style.display = "none";
  });

  // setting resize
  var divCol4Boundary1 = document.createElement("div");
  divCol4Boundary1.classList.add("div-boundary");
  divCol4.appendChild(divCol4Boundary1);
  var divCol4Boundary2 = document.createElement("div");
  divCol4Boundary2.classList.add("div-boundary");
  divCol4_1.appendChild(divCol4Boundary2);
  var divCol4Boundary3 = document.createElement("div");
  divCol4Boundary3.classList.add("div-boundary");
  divCol4_2.appendChild(divCol4Boundary3);
  var isResizing = false;
  var lastX;
  var resizingBoundary;
  var columnSize = rowSection.offsetWidth / 12;
  var columnNumber1;
  var columnNumber2;
  var columnNumber3;
  var columnNumber4;
  divCol4Boundary1.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol4Boundary1";
  });
  divCol4Boundary2.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol4Boundary2";
  });
  divCol4Boundary3.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol4Boundary3";
  });
  document.addEventListener("mousemove", function (e) {
    if (isResizing) {
      var offset = e.clientX - lastX;
      if (resizingBoundary === "divCol4Boundary1") {
        var newWidth1 = divCol4.offsetWidth + offset;
        var newWidth2 = divCol4_1.offsetWidth - offset;
        divCol4.style.width = newWidth1 + "px";
        divCol4_1.style.width = newWidth2 + "px";
        columnNumber1 = Math.round(newWidth1 / columnSize);
        columnNumber2 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol4Boundary2") {
        var newWidth1 = divCol4_1.offsetWidth + offset;
        var newWidth2 = divCol4_2.offsetWidth - offset;
        divCol4_1.style.width = newWidth1 + "px";
        divCol4_2.style.width = newWidth2 + "px";
        columnNumber2 = Math.round(newWidth1 / columnSize);
        columnNumber3 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol4Boundary3") {
        var newWidth1 = divCol4_2.offsetWidth + offset;
        var newWidth2 = divCol4_3.offsetWidth - offset;
        divCol4_2.style.width = newWidth1 + "px";
        divCol4_3.style.width = newWidth2 + "px";
        columnNumber3 = Math.round(newWidth1 / columnSize);
        columnNumber4 = Math.round(newWidth2 / columnSize);
      }
      lastX = e.clientX;
    }
  });
  document.addEventListener("mouseup", function () {
    isResizing = false;
    divCol4.style.width = columnNumber1 * columnSize + "px";
    divCol4_1.style.width = columnNumber2 * columnSize + "px";
    divCol4_2.style.width = columnNumber3 * columnSize + "px";
    divCol4_3.style.width = columnNumber4 * columnSize + "px";
  });

  // configDragDrop();
  loadSections();
});
settingRow5.addEventListener("click", function (e) {
  e.preventDefault();
  var rowSection = createRowSection();
  container = document.getElementById(id);
  container.appendChild(rowSection);
  var divCol5 = createDivCol5();
  var divCol5_1 = createDivCol5();
  var divCol5_2 = createDivCol5();
  var divCol5_3 = createDivCol5();
  var divCol5_4 = createDivCol5();

  rowSection.appendChild(divCol5);
  rowSection.appendChild(divCol5_1);
  rowSection.appendChild(divCol5_2);
  rowSection.appendChild(divCol5_3);
  rowSection.appendChild(divCol5_4);
  setColumnNumberPopup.style.right = "-350px";

  blueAddElementRolloverTools = addElement();
  blueAddElementRolloverTools1 = addElement();
  blueAddElementRolloverTools2 = addElement();
  blueAddElementRolloverTools3 = addElement();
  blueAddElementRolloverTools4 = addElement();
  divCol5.appendChild(blueAddElementRolloverTools);
  divCol5_1.appendChild(blueAddElementRolloverTools1);
  divCol5_2.appendChild(blueAddElementRolloverTools2);
  divCol5_3.appendChild(blueAddElementRolloverTools3);
  divCol5_4.appendChild(blueAddElementRolloverTools4);

  rowSection.addEventListener("mouseenter", (e) => {
    divCol5.style.borderRight = "1px dotted #3a85ff";
    divCol5_1.style.borderRight = "1px dotted #3a85ff";
    divCol5_2.style.borderRight = "1px dotted #3a85ff";
    divCol5_3.style.borderRight = "1px dotted #3a85ff";
    divCol5Boundary1.style.display = "block";
    divCol5Boundary2.style.display = "block";
    divCol5Boundary3.style.display = "block";
    divCol5Boundary4.style.display = "block";
    if (!divCol5.childNodes[2]) {
      divCol5.childNodes[0].style.display = "block";
      divCol5.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol5_1.childNodes[2]) {
      divCol5_1.childNodes[0].style.display = "block";
      divCol5_1.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol5_2.childNodes[2]) {
      divCol5_2.childNodes[0].style.display = "block";
      divCol5_2.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol5_3.childNodes[2]) {
      divCol5_3.childNodes[0].style.display = "block";
      divCol5_3.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol5_4.childNodes[1]) {
      divCol5_4.childNodes[0].style.display = "block";
      divCol5_4.childNodes[0].childNodes[0].style.display = "block";
    }
  });
  rowSection.addEventListener("mouseleave", (e) => {
    divCol5.style.borderRight = "none";
    divCol5_1.style.borderRight = "none";
    divCol5_2.style.borderRight = "none";
    divCol5_3.style.borderRight = "none";
    divCol5Boundary1.style.display = "none";
    divCol5Boundary2.style.display = "none";
    divCol5Boundary3.style.display = "none";
    divCol5Boundary4.style.display = "none";
    divCol5.childNodes[0].style.display = "none";
    divCol5_1.childNodes[0].style.display = "none";
    divCol5_2.childNodes[0].style.display = "none";
    divCol5_3.childNodes[0].style.display = "none";
    divCol5_4.childNodes[0].style.display = "none";
    divCol5.childNodes[0].childNodes[0].style.display = "none";
    divCol5_1.childNodes[0].childNodes[0].style.display = "none";
    divCol5_2.childNodes[0].childNodes[0].style.display = "none";
    divCol5_3.childNodes[0].childNodes[0].style.display = "none";
    divCol5_4.childNodes[0].childNodes[0].style.display = "none";
  });

  // setting resize
  var divCol5Boundary1 = document.createElement("div");
  divCol5Boundary1.classList.add("div-boundary");
  divCol5.appendChild(divCol5Boundary1);
  var divCol5Boundary2 = document.createElement("div");
  divCol5Boundary2.classList.add("div-boundary");
  divCol5_1.appendChild(divCol5Boundary2);
  var divCol5Boundary3 = document.createElement("div");
  divCol5Boundary3.classList.add("div-boundary");
  divCol5_2.appendChild(divCol5Boundary3);
  var divCol5Boundary4 = document.createElement("div");
  divCol5Boundary4.classList.add("div-boundary");
  divCol5_3.appendChild(divCol5Boundary4);
  var isResizing = false;
  var lastX;
  var resizingBoundary;
  var columnSize = rowSection.offsetWidth / 12;
  var columnNumber1;
  var columnNumber2;
  var columnNumber3;
  var columnNumber4;
  var columnNumber5;
  divCol5Boundary1.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol5Boundary1";
  });
  divCol5Boundary2.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol5Boundary2";
  });
  divCol5Boundary3.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol5Boundary3";
  });
  divCol5Boundary4.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol5Boundary4";
  });
  document.addEventListener("mousemove", function (e) {
    if (isResizing) {
      var offset = e.clientX - lastX;
      if (resizingBoundary === "divCol5Boundary1") {
        var newWidth1 = divCol5.offsetWidth + offset;
        var newWidth2 = divCol5_1.offsetWidth - offset;
        divCol5.style.width = newWidth1 + "px";
        divCol5_1.style.width = newWidth2 + "px";
        columnNumber1 = Math.round(newWidth1 / columnSize);
        columnNumber2 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol5Boundary2") {
        var newWidth1 = divCol5_1.offsetWidth + offset;
        var newWidth2 = divCol5_2.offsetWidth - offset;
        divCol5_1.style.width = newWidth1 + "px";
        divCol5_2.style.width = newWidth2 + "px";
        columnNumber2 = Math.round(newWidth1 / columnSize);
        columnNumber3 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol5Boundary3") {
        var newWidth1 = divCol5_2.offsetWidth + offset;
        var newWidth2 = divCol5_3.offsetWidth - offset;
        divCol5_2.style.width = newWidth1 + "px";
        divCol5_3.style.width = newWidth2 + "px";
        columnNumber3 = Math.round(newWidth1 / columnSize);
        columnNumber4 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol5Boundary4") {
        var newWidth1 = divCol5_3.offsetWidth + offset;
        var newWidth2 = divCol5_4.offsetWidth - offset;
        divCol5_3.style.width = newWidth1 + "px";
        divCol5_4.style.width = newWidth2 + "px";
        columnNumber4 = Math.round(newWidth1 / columnSize);
        columnNumber5 = Math.round(newWidth2 / columnSize);
      }
      lastX = e.clientX;
    }
  });
  document.addEventListener("mouseup", function () {
    isResizing = false;
    divCol5.style.width = columnNumber1 * columnSize + "px";
    divCol5_1.style.width = columnNumber2 * columnSize + "px";
    divCol5_2.style.width = columnNumber3 * columnSize + "px";
    divCol5_3.style.width = columnNumber4 * columnSize + "px";
    divCol5_4.style.width = columnNumber5 * columnSize + "px";
  });

  // configDragDrop();
  loadSections();
});
settingRow6.addEventListener("click", function (e) {
  e.preventDefault();
  var rowSection = createRowSection();
  container = document.getElementById(id);
  container.appendChild(rowSection);
  var divCol6 = createDivCol6();
  var divCol6_1 = createDivCol6();
  var divCol6_2 = createDivCol6();
  var divCol6_3 = createDivCol6();
  var divCol6_4 = createDivCol6();
  var divCol6_5 = createDivCol6();
  rowSection.appendChild(divCol6);
  rowSection.appendChild(divCol6_1);
  rowSection.appendChild(divCol6_2);
  rowSection.appendChild(divCol6_3);
  rowSection.appendChild(divCol6_4);
  rowSection.appendChild(divCol6_5);
  setColumnNumberPopup.style.right = "-350px";

  blueAddElementRolloverTools = addElement();
  blueAddElementRolloverTools1 = addElement();
  blueAddElementRolloverTools2 = addElement();
  blueAddElementRolloverTools3 = addElement();
  blueAddElementRolloverTools4 = addElement();
  blueAddElementRolloverTools5 = addElement();
  divCol6.appendChild(blueAddElementRolloverTools);
  divCol6_1.appendChild(blueAddElementRolloverTools1);
  divCol6_2.appendChild(blueAddElementRolloverTools2);
  divCol6_3.appendChild(blueAddElementRolloverTools3);
  divCol6_4.appendChild(blueAddElementRolloverTools4);
  divCol6_5.appendChild(blueAddElementRolloverTools5);

  rowSection.addEventListener("mouseenter", (e) => {
    divCol6.style.borderRight = "1px dotted #3a85ff";
    divCol6_1.style.borderRight = "1px dotted #3a85ff";
    divCol6_2.style.borderRight = "1px dotted #3a85ff";
    divCol6_3.style.borderRight = "1px dotted #3a85ff";
    divCol6_4.style.borderRight = "1px dotted #3a85ff";
    divCol6Boundary1.style.display = "block";
    divCol6Boundary2.style.display = "block";
    divCol6Boundary3.style.display = "block";
    divCol6Boundary4.style.display = "block";
    divCol6Boundary5.style.display = "block";
    if (!divCol6.childNodes[2]) {
      divCol6.childNodes[0].style.display = "block";
      divCol6.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol6_1.childNodes[2]) {
      divCol6_1.childNodes[0].style.display = "block";
      divCol6_1.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol6_2.childNodes[2]) {
      divCol6_2.childNodes[0].style.display = "block";
      divCol6_2.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol6_3.childNodes[2]) {
      divCol6_3.childNodes[0].style.display = "block";
      divCol6_3.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol6_4.childNodes[2]) {
      divCol6_4.childNodes[0].style.display = "block";
      divCol6_4.childNodes[0].childNodes[0].style.display = "block";
    }
    if (!divCol6_5.childNodes[1]) {
      divCol6_5.childNodes[0].style.display = "block";
      divCol6_5.childNodes[0].childNodes[0].style.display = "block";
    }
  });
  rowSection.addEventListener("mouseleave", (e) => {
    divCol6.style.borderRight = "none";
    divCol6_1.style.borderRight = "none";
    divCol6_2.style.borderRight = "none";
    divCol6_3.style.borderRight = "none";
    divCol6_4.style.borderRight = "none";
    divCol6Boundary1.style.display = "none";
    divCol6Boundary2.style.display = "none";
    divCol6Boundary3.style.display = "none";
    divCol6Boundary4.style.display = "none";
    divCol6Boundary5.style.display = "none";
    divCol6.childNodes[0].style.display = "none";
    divCol6_1.childNodes[0].style.display = "none";
    divCol6_2.childNodes[0].style.display = "none";
    divCol6_3.childNodes[0].style.display = "none";
    divCol6_4.childNodes[0].style.display = "none";
    divCol6_5.childNodes[0].style.display = "none";
    divCol6.childNodes[0].childNodes[0].style.display = "none";
    divCol6_1.childNodes[0].childNodes[0].style.display = "none";
    divCol6_2.childNodes[0].childNodes[0].style.display = "none";
    divCol6_3.childNodes[0].childNodes[0].style.display = "none";
    divCol6_4.childNodes[0].childNodes[0].style.display = "none";
    divCol6_5.childNodes[0].childNodes[0].style.display = "none";
  });

  // setting resize
  var divCol6Boundary1 = document.createElement("div");
  divCol6Boundary1.classList.add("div-boundary");
  divCol6.appendChild(divCol6Boundary1);
  var divCol6Boundary2 = document.createElement("div");
  divCol6Boundary2.classList.add("div-boundary");
  divCol6_1.appendChild(divCol6Boundary2);
  var divCol6Boundary3 = document.createElement("div");
  divCol6Boundary3.classList.add("div-boundary");
  divCol6_2.appendChild(divCol6Boundary3);
  var divCol6Boundary4 = document.createElement("div");
  divCol6Boundary4.classList.add("div-boundary");
  divCol6_3.appendChild(divCol6Boundary4);
  var divCol6Boundary5 = document.createElement("div");
  divCol6Boundary5.classList.add("div-boundary");
  divCol6_4.appendChild(divCol6Boundary5);
  var isResizing = false;
  var lastX;
  var resizingBoundary;
  var columnSize = rowSection.offsetWidth / 12;
  var columnNumber1;
  var columnNumber2;
  var columnNumber3;
  var columnNumber4;
  var columnNumber5;
  var columnNumber6;
  divCol6Boundary1.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol6Boundary1";
  });
  divCol6Boundary2.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol6Boundary2";
  });
  divCol6Boundary3.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol6Boundary3";
  });
  divCol6Boundary4.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol6Boundary4";
  });
  divCol6Boundary5.addEventListener("mousedown", function (e) {
    isResizing = true;
    lastX = e.clientX;
    resizingBoundary = "divCol6Boundary5";
  });
  document.addEventListener("mousemove", function (e) {
    if (isResizing) {
      var offset = e.clientX - lastX;
      if (resizingBoundary === "divCol6Boundary1") {
        var newWidth1 = divCol6.offsetWidth + offset;
        var newWidth2 = divCol6_1.offsetWidth - offset;
        divCol6.style.width = newWidth1 + "px";
        divCol6_1.style.width = newWidth2 + "px";
        columnNumber1 = Math.round(newWidth1 / columnSize);
        columnNumber2 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol6Boundary2") {
        var newWidth1 = divCol6_1.offsetWidth + offset;
        var newWidth2 = divCol6_2.offsetWidth - offset;
        divCol6_1.style.width = newWidth1 + "px";
        divCol6_2.style.width = newWidth2 + "px";
        columnNumber2 = Math.round(newWidth1 / columnSize);
        columnNumber3 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol6Boundary3") {
        var newWidth1 = divCol6_2.offsetWidth + offset;
        var newWidth2 = divCol6_3.offsetWidth - offset;
        divCol6_2.style.width = newWidth1 + "px";
        divCol6_3.style.width = newWidth2 + "px";
        columnNumber3 = Math.round(newWidth1 / columnSize);
        columnNumber4 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol6Boundary4") {
        var newWidth1 = divCol6_3.offsetWidth + offset;
        var newWidth2 = divCol6_4.offsetWidth - offset;
        divCol6_3.style.width = newWidth1 + "px";
        divCol6_4.style.width = newWidth2 + "px";
        columnNumber4 = Math.round(newWidth1 / columnSize);
        columnNumber5 = Math.round(newWidth2 / columnSize);
      } else if (resizingBoundary === "divCol6Boundary5") {
        var newWidth1 = divCol6_4.offsetWidth + offset;
        var newWidth2 = divCol6_5.offsetWidth - offset;
        divCol6_4.style.width = newWidth1 + "px";
        divCol6_5.style.width = newWidth2 + "px";
        columnNumber5 = Math.round(newWidth1 / columnSize);
        columnNumber6 = Math.round(newWidth2 / columnSize);
      }
      lastX = e.clientX;
    }
  });
  document.addEventListener("mouseup", function () {
    isResizing = false;
    divCol6.style.width = columnNumber1 * columnSize + "px";
    divCol6_1.style.width = columnNumber2 * columnSize + "px";
    divCol6_2.style.width = columnNumber3 * columnSize + "px";
    divCol6_3.style.width = columnNumber4 * columnSize + "px";
    divCol6_4.style.width = columnNumber5 * columnSize + "px";
    divCol6_5.style.width = columnNumber6 * columnSize + "px";
  });

  // configDragDrop();
  loadSections();
});

function setFormat(command) {
  document.execCommand(command, false, null);
}
function setAlignment(align) {
  document.execCommand("justify" + align, false, null);
}

function setLink() {
  var url = prompt("Enter the URL:");
  document.execCommand("createLink", false, url);
}
function moveUp(element) {
  if (element.previousElementSibling) {
    element.parentNode.insertBefore(element, element.previousElementSibling); // insert element before the previous sibling
  }
}

function moveDown(element) {
  if (element.nextElementSibling) {
    element.parentNode.insertBefore(
      element,
      element.nextElementSibling.nextElementSibling
    );
  }
}
function rowMoveUp(element) {
  if (element.previousElementSibling) {
    element.parentNode.insertBefore(element, element.previousElementSibling); // insert element before the previous sibling
  }
}

function rowMoveDown(element) {
  if (element.nextElementSibling) {
    element.parentNode.insertBefore(
      element,
      element.nextElementSibling.nextElementSibling
    );
  }
}

function removeElement(element) {
  element.parentNode.removeChild(element);
}
function greenClone(element) {
  const copySection = element.parentNode.parentNode;
  const pasteSection = copySection.cloneNode(true);
  var key = new Date().getTime();
  pasteSection.setAttribute("id", key);
  traverseAndSetUniqueId(pasteSection);
  copySection.insertAdjacentElement("afterend", pasteSection);
  // mouseenter and mouseleave control about section, row, element
  sectionControl(pasteSection);
  const pasteRows = pasteSection.querySelectorAll('div[id^="row-"]');
  pasteRows.forEach((pasteRow) => {
    rowControl(pasteRow);
    const pasteColumns = pasteRow.querySelectorAll('div.col-div');
    pasteRow.addEventListener('mouseenter', function() {
      pasteColumns.forEach((pasteColumn) => {
        pasteColumn.style.borderRight = "1px dotted rgb(58, 133, 255)";
        if (pasteColumn.childNodes[1] && pasteColumn.childNodes[1].className === 'div-boundary') {
          pasteColumn.childNodes[1].style.display = "block";
        }
        if(!pasteColumn.querySelector('div.draggable')) {
          pasteColumn.childNodes[0].childNodes[0].style.display = "block";
        } else {
          pasteColumn.childNodes[0].childNodes[0].style.display = "none";
        }
      });
    });
    pasteRow.addEventListener('mouseleave', function() {
      pasteColumns.forEach((pasteColumn) => {
        pasteColumn.style.borderRight = "none";
        if (pasteColumn.childNodes[1] && pasteColumn.childNodes[1].className === 'div-boundary') {
          pasteColumn.childNodes[1].style.display = "none";
        }
        pasteColumn.childNodes[0].childNodes[0].style.display = "none";
      });
    });
  });
  const pasteElements = pasteSection.querySelectorAll('div.draggable');
  pasteElements.forEach((pasteElement) => {
    elementControl(pasteElement);
    editTextControl(pasteElement);
  });
}

function blueClone(element) {
  const copyRow = element.parentNode.parentNode;
  const pasteRow = copyRow.cloneNode(true);
  var key = new Date().getTime();
  pasteRow.setAttribute("id", "row-" + key);
  traverseAndSetUniqueId(pasteRow);
  copyRow.insertAdjacentElement("afterend", pasteRow);
  
    rowControl(pasteRow);
    const pasteColumns = pasteRow.querySelectorAll('div.col-div');
    pasteRow.addEventListener('mouseenter', function() {
      pasteColumns.forEach((pasteColumn) => {
        pasteColumn.style.borderRight = "1px dotted rgb(58, 133, 255)";
        if (pasteColumn.childNodes[1] && pasteColumn.childNodes[1].className === 'div-boundary') {
          pasteColumn.childNodes[1].style.display = "block";
        }
        if(!pasteColumn.querySelector('div.draggable')) {
          pasteColumn.childNodes[0].childNodes[0].style.display = "block";
        } else {
          pasteColumn.childNodes[0].childNodes[0].style.display = "none";
        }
      });
    });
    pasteRow.addEventListener('mouseleave', function() {
      pasteColumns.forEach((pasteColumn) => {
        pasteColumn.style.borderRight = "none";
        if (pasteColumn.childNodes[1] && pasteColumn.childNodes[1].className === 'div-boundary') {
          pasteColumn.childNodes[1].style.display = "none";
        }
        pasteColumn.childNodes[0].childNodes[0].style.display = "none";
      });
    });
    const pasteElements = pasteRow.querySelectorAll('div.draggable');
  pasteElements.forEach((pasteElement) => {
    elementControl(pasteElement);
    editTextControl(pasteElement);
  });
}

function orangeClone(element) {

  const copyElement = element.parentNode.parentNode;
  const pasteElement = copyElement.cloneNode(true);
  const copyElementId = copyElement.getAttribute("id");
  const idParts = copyElementId.split('-');
  var key = new Date().getTime();
  pasteElement.setAttribute("id", idParts[0] + '-' + key);
  traverseAndSetUniqueId(pasteElement);
  copyElement.insertAdjacentElement("afterend", pasteElement);
  
  cloneElementControl(pasteElement);
  cloneEditTextControl(pasteElement);
}

function traverseAndSetUniqueId(sourceElement) {
  const allCopyElements = sourceElement.querySelectorAll('*');
  const idMap = new Map(); // Map to store original prefixes and their corresponding new unique numbers

  allCopyElements.forEach(copyElement => {
      const existingId = copyElement.getAttribute('id');
      if (existingId && existingId.includes('-')) {
          const idParts = existingId.split('-');
          const prefix = idParts[0];

          if (!idMap.has(prefix)) {
              idMap.set(prefix, Math.floor(Math.random() * 1000000)); // Store a random unique number for this prefix
          }

          const newId = prefix + '-' + idMap.get(prefix);
          copyElement.setAttribute('id', newId);
          idMap.set(prefix, idMap.get(prefix) + 1); // Update the unique number for the next element with the same prefix
      }
  });
}
function cloneEditTextControl(element) {
  var editTextRolloverTools = element.childNodes[4];
  element.addEventListener("mouseup", () => {
    const selectedText = window.getSelection().toString().trim();
    if (selectedText) {
      const selection = window.getSelection();
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect(); // Get the position of the selected text
      // Calculate the position relative to the parent
      const parentRect = element.getBoundingClientRect();
      const relativeLeft = rect.x - parentRect.x;
      // Get the width of the selected text in pixels
      const selectedTextRect = range.getClientRects()[0];
      const textWidth = selectedTextRect.width;

      // Set the left position of editTextRolloverTools based on the position of the selected text
      if (relativeLeft < 130) {
        editTextRolloverTools.style.left = "0";
      } else if (relativeLeft > parentRect.width - 140 - textWidth / 2) {
        editTextRolloverTools.style.left = parentRect.width - 280 + "px";
      } else {
        editTextRolloverTools.style.left =
          relativeLeft - 140 + textWidth / 2 + "px";
      }

      element.style.border = "1px solid #777";
      for (let i = 0; i < 3; i++) {
        element.childNodes[1].childNodes[i].style.display = "none";
      }
      for (let i = 0; i < 2; i++) {
        element.childNodes[2].childNodes[i].style.display = "none";
      }
      element.childNodes[3].childNodes[0].style.display = "none";
      editTextRolloverTools.style.display = "block";
      for (let i = 0; i < 8; i++) {
        editTextRolloverTools.childNodes[i].style.display = "block";
      }
    } else {
      editTextRolloverTools.style.display = "none";
      for (let i = 0; i < 8; i++) {
        editTextRolloverTools.childNodes[i].style.display = "none";
      }
    }
  });
  document.addEventListener("click", function (event) {
    if (!element.contains(event.target)) {
      // If the click is outside of the paragraphelement, hide the editTextRolloverTools
      editTextRolloverTools.style.display = "none";
      for (let i = 0; i < 8; i++) {
        editTextRolloverTools.childNodes[i].style.display = "none";
      }
    }
  });
}
function editTextControl(element) {
  var editTextRolloverTools = document.createElement("div");
  editTextRolloverTools.classList.add(
    "text-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex"
  );
  editTextRolloverTools.style.display = "none";
  editTextRolloverTools.style.zIndex = "100";

  var editBoldButton = document.createElement("div");
  editBoldButton.classList.add("de-rollover-bold");
  editBoldButton.style.display = "none";
  editBoldButton.innerHTML = '<i class="fa fa-bold"></i>';
  editBoldButton.setAttribute("onclick", "setFormat('bold')");
  var editItalicButton = document.createElement("div");
  editItalicButton.classList.add("de-rollover-italic");
  editItalicButton.style.display = "none";
  editItalicButton.innerHTML = '<i class="fa fa-italic"></i>';
  editItalicButton.setAttribute("onclick", "setFormat('italic')");
  var editUnderlineButton = document.createElement("div");
  editUnderlineButton.classList.add("de-rollover-underline");
  editUnderlineButton.style.display = "none";
  editUnderlineButton.innerHTML = '<i class="fa fa-underline"></i>';
  editUnderlineButton.setAttribute("onclick", "setFormat('underline')");
  var editStrikeButton = document.createElement("div");
  editStrikeButton.classList.add("de-rollover-strike");
  editStrikeButton.style.display = "none";
  editStrikeButton.innerHTML = '<i class="fa fa-strikethrough"></i>';
  editStrikeButton.setAttribute("onclick", "setFormat('strikeThrough')");
  var editLeftButton = document.createElement("div");
  editLeftButton.classList.add("de-rollover-left");
  editLeftButton.style.display = "none";
  editLeftButton.innerHTML = '<i class="fa fa-align-left"></i>';
  editLeftButton.setAttribute("onclick", "setAlignment('left')");
  var editCenterButton = document.createElement("div");
  editCenterButton.classList.add("de-rollover-center");
  editCenterButton.style.display = "none";
  editCenterButton.innerHTML = '<i class="fa fa-align-center"></i>';
  editCenterButton.setAttribute("onclick", "setAlignment('center')");
  var editRightButton = document.createElement("div");
  editRightButton.classList.add("de-rollover-right");
  editRightButton.style.display = "none";
  editRightButton.innerHTML = '<i class="fa fa-align-right"></i>';
  editRightButton.setAttribute("onclick", "setAlignment('right')");
  var editLinkButton = document.createElement("div");
  editLinkButton.classList.add("de-rollover-link");
  editLinkButton.style.display = "none";
  editLinkButton.innerHTML = '<i class="fa fa-link"></i>';
  editLinkButton.setAttribute("onclick", "setLink()");

  editTextRolloverTools.appendChild(editBoldButton);
  editTextRolloverTools.appendChild(editItalicButton);
  editTextRolloverTools.appendChild(editUnderlineButton);
  editTextRolloverTools.appendChild(editStrikeButton);
  editTextRolloverTools.appendChild(editLeftButton);
  editTextRolloverTools.appendChild(editCenterButton);
  editTextRolloverTools.appendChild(editRightButton);
  editTextRolloverTools.appendChild(editLinkButton);

  element.appendChild(editTextRolloverTools);

  element.addEventListener("mouseup", () => {
    const selectedText = window.getSelection().toString().trim();
    if (selectedText) {
      const selection = window.getSelection();
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect(); // Get the position of the selected text
      // Calculate the position relative to the parent
      const parentRect = element.getBoundingClientRect();
      const relativeLeft = rect.x - parentRect.x;
      // Get the width of the selected text in pixels
      const selectedTextRect = range.getClientRects()[0];
      const textWidth = selectedTextRect.width;

      // Set the left position of editTextRolloverTools based on the position of the selected text
      if (relativeLeft < 130) {
        editTextRolloverTools.style.left = "0";
      } else if (relativeLeft > parentRect.width - 140 - textWidth / 2) {
        editTextRolloverTools.style.left = parentRect.width - 280 + "px";
      } else {
        editTextRolloverTools.style.left =
          relativeLeft - 140 + textWidth / 2 + "px";
      }

      element.style.border = "1px solid #777";
      for (let i = 0; i < 3; i++) {
        element.childNodes[1].childNodes[i].style.display = "none";
      }
      for (let i = 0; i < 2; i++) {
        element.childNodes[2].childNodes[i].style.display = "none";
      }
      element.childNodes[3].childNodes[0].style.display = "none";
      editTextRolloverTools.style.display = "block";
      for (let i = 0; i < 8; i++) {
        editTextRolloverTools.childNodes[i].style.display = "block";
      }
    } else {
      editTextRolloverTools.style.display = "none";
      for (let i = 0; i < 8; i++) {
        editTextRolloverTools.childNodes[i].style.display = "none";
      }
    }
  });
  document.addEventListener("click", function (event) {
    if (!element.contains(event.target)) {
      // If the click is outside of the paragraphelement, hide the editTextRolloverTools
      editTextRolloverTools.style.display = "none";
      for (let i = 0; i < 8; i++) {
        editTextRolloverTools.childNodes[i].style.display = "none";
      }
    }
  });
}
function cloneElementControl(element) {
  var orangeRolloverTools = element.childNodes[1];
  var orangeArrowRolloverTools = element.childNodes[2];
  var orangeAddRolloverTools = element.childNodes[3];
  element.addEventListener("mouseenter", () => {
    orangeRolloverTools.style.display = "block";
    orangeArrowRolloverTools.style.display = "block";
    orangeAddRolloverTools.style.display = "block";
    orangeRolloverTools.childNodes[0].style.display = "block";
    orangeRolloverTools.childNodes[1].style.display = "block";
    orangeRolloverTools.childNodes[2].style.display = "block";
    orangeArrowRolloverTools.childNodes[0].style.display = "block";
    orangeArrowRolloverTools.childNodes[1].style.display = "block";
    orangeArrowRolloverTools.childNodes[2].style.display = "block";
    orangeAddRolloverTools.childNodes[0].style.display = "block";
    element.style.border = "1px solid orange"; // Change border color on mouseover

    element.parentNode.parentNode.style.border = "none";
    for (let i = 0; i < 3; i++) {
      element.parentNode.parentNode.childNodes[0].childNodes[i].style.display = "none";
    }
    for (let i = 0; i < 3; i++) {
      element.parentNode.parentNode.childNodes[1].childNodes[i].style.display = "none";
    }
    element.parentNode.parentNode.childNodes[2].childNodes[0].style.display = "none";
    for (let i = 3; i < element.parentNode.parentNode.children.length; i++ ) {
      element.parentNode.parentNode.childNodes[i].style.borderRight = "none";
      if ( element.parentNode.parentNode.childNodes[i].childNodes[1].className == "div-boundary") {
        element.parentNode.parentNode.childNodes[i].childNodes[1].style.display = "none";
      }
    }
    addElementButtons = document.querySelectorAll("[id*='blue_add']");
    addElementButtons.forEach((item) => {
      item.style.display = "none";
    });
  });

  element.addEventListener("mouseleave", () => {
    orangeRolloverTools.style.display = "none";
    orangeArrowRolloverTools.style.display = "none";
    orangeAddRolloverTools.style.display = "none";
    orangeRolloverTools.childNodes[0].style.display = "none";
    orangeRolloverTools.childNodes[1].style.display = "none";
    orangeRolloverTools.childNodes[2].style.display = "none";
    orangeArrowRolloverTools.childNodes[0].style.display = "none";
    orangeArrowRolloverTools.childNodes[1].style.display = "none";
    orangeArrowRolloverTools.childNodes[2].style.display = "none";
    orangeAddRolloverTools.childNodes[0].style.display = "none";
    element.style.border = "none"; // Reset border color on mouseout

    element.parentNode.parentNode.style.border = "1px solid rgb(58, 133, 255)";
    for (let i = 0; i < 3; i++) {
      element.parentNode.parentNode.childNodes[0].childNodes[i].style.display = "block";
    }
    for (let i = 0; i < 3; i++) {
      element.parentNode.parentNode.childNodes[1].childNodes[i].style.display = "block";
    }
    element.parentNode.parentNode.childNodes[2].childNodes[0].style.display = "block";
    for (let i = 4; i < element.parentNode.parentNode.children.length; i++) {
      element.parentNode.parentNode.childNodes[i - 1].style.borderRight = "1px dotted rgb(58, 133, 255)";
      if (element.parentNode.parentNode.childNodes[i - 1].childNodes[0].className == "div-boundary") {
        element.parentNode.parentNode.childNodes[i - 1].childNodes[0].style.display = "block";
      }
    }
  });
  document.addEventListener("click", function(event) {
    const isSetRowPopup = event.target.parentNode === element && element.contains(event.target);
    if (isSetRowPopup) {
      event.target.parentNode.childNodes[2].childNodes[2].click();
    }
  })
}

function elementControl(element) {
  // create orange rollover
  var orangeRolloverTools = document.createElement("div");
  orangeRolloverTools.classList.add(
    "orange-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex"
  );
  orangeRolloverTools.style.display = "none";

  var orangeMoveButton = document.createElement("div");
  orangeMoveButton.classList.add("de-rollover-move");
  orangeMoveButton.style.display = "none";
  orangeMoveButton.style.padding = "0 5px";
  orangeMoveButton.innerHTML = '<i class="fa fa-arrows"></i>';
  orangeMoveButton.style.cursor = "move";

  var orangeCloneButton = document.createElement("div");
  orangeCloneButton.classList.add("de-rollover-clone");
  orangeCloneButton.style.zIndex = "10";
  orangeCloneButton.style.display = "none";
  orangeCloneButton.innerHTML = '<i class="fa fa-copy"></i>';
  orangeCloneButton.setAttribute("type", "button");
  orangeCloneButton.setAttribute('onclick', "orangeClone(this)");

  var orangeGearButton = document.createElement("div");
  orangeGearButton.classList.add("de-rollover-settings");
  orangeGearButton.style.display = "none";
  orangeGearButton.style.padding = "0 5px";
  orangeGearButton.innerHTML = '<i class="fa fa-cog"></i>';
  orangeGearButton.setAttribute("type", "button");
  orangeGearButton.setAttribute("id", `orange_gear-${Date.now()}`);
  orangeGearButton.setAttribute('onclick', "orangeSetting(this)");

  var orangeRemoveButton = document.createElement("div");
  orangeRemoveButton.classList.add("de-rollover-remove");
  orangeRemoveButton.style.display = "none";
  orangeRemoveButton.style.padding = "0 5px";
  orangeRemoveButton.innerHTML = '<i class="fa fa-trash"></i>';
  orangeRemoveButton.setAttribute("type", "button");
  orangeRemoveButton.setAttribute(
    "onclick",
    "removeElement(parentElement.parentElement)"
  );
  orangeRolloverTools.appendChild(orangeMoveButton);
  orangeRolloverTools.appendChild(orangeCloneButton);
  orangeRolloverTools.appendChild(orangeRemoveButton);
  // create orange arrow rollover
  var orangeArrowRolloverTools = document.createElement("div");
  orangeArrowRolloverTools.classList.add(
    "orange-arrow-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex"
  );
  orangeArrowRolloverTools.style.display = "none";
  var orangeArrowUpButton = document.createElement("div");
  orangeArrowUpButton.classList.add("de-rollover-arrow-up");
  orangeArrowUpButton.style.backgroundColor = "orange";
  orangeArrowUpButton.style.display = "none";
  orangeArrowUpButton.style.padding = "0 5px";
  orangeArrowUpButton.innerHTML = '<i class="fa fa-arrow-up"></i>';
  orangeArrowUpButton.setAttribute("type", "button");
  orangeArrowUpButton.setAttribute(
    "onclick",
    "moveUp(parentElement.parentElement)"
  );

  var orangeArrowDownButton = document.createElement("div");
  orangeArrowDownButton.classList.add("de-rollover-arrow-down");
  orangeArrowDownButton.style.backgroundColor = "orange";
  orangeArrowDownButton.style.display = "none";
  orangeArrowDownButton.style.padding = "0 5px";
  orangeArrowDownButton.innerHTML = '<i class="fa fa-arrow-down"></i>';
  orangeArrowDownButton.setAttribute("type", "button");
  orangeArrowDownButton.setAttribute(
    "onclick",
    "moveDown(parentElement.parentElement)"
  );
  orangeArrowRolloverTools.appendChild(orangeArrowUpButton);
  orangeArrowRolloverTools.appendChild(orangeArrowDownButton);
  orangeArrowRolloverTools.appendChild(orangeGearButton);

  // create orange add circle rollover
  var orangeAddRolloverTools = document.createElement("div");
  orangeAddRolloverTools.classList.add(
    "plus-de-rollover-tools",
    "smallWidthElementHover",
    "d-flex"
  );
  orangeAddRolloverTools.style.display = "none";

  var orangeAddButton = document.createElement("div");
  orangeAddButton.classList.add("de-rollover-plus-circle");
  orangeAddButton.style.backgroundColor = "orange";
  orangeAddButton.style.display = "none";
  orangeAddButton.setAttribute("type", "button");
  orangeAddButton.style.zIndex = "10";
  orangeAddButton.style.position = "relative";
  orangeAddButton.style.left = "-50%";
  orangeAddButton.innerHTML = '<i class="fa fa-plus"></i>';
  orangeAddButton.setAttribute("type", "button");
  orangeAddButton.setAttribute("id", `orange_add-${Date.now()}`);
  orangeAddButton.setAttribute('onclick', "openAddElementPopup(this)");
  orangeAddRolloverTools.appendChild(orangeAddButton);

  // Append all the elements to the element
  element.appendChild(orangeRolloverTools);
  element.appendChild(orangeArrowRolloverTools);
  element.appendChild(orangeAddRolloverTools);
  element.style.position = "relative";

  element.childNodes[0].addEventListener("click", function(event) {
    event.stopPropagation();
    element.childNodes[2].childNodes[2].click();
  })
  // Add event listeners to show/hide rollover tools and change border color on mouseover
  element.addEventListener("mouseenter", () => {
    orangeRolloverTools.style.display = "block";
    orangeArrowRolloverTools.style.display = "block";
    orangeAddRolloverTools.style.display = "block";
    orangeRolloverTools.childNodes[0].style.display = "block";
    orangeRolloverTools.childNodes[1].style.display = "block";
    orangeRolloverTools.childNodes[2].style.display = "block";
    orangeArrowRolloverTools.childNodes[0].style.display = "block";
    orangeArrowRolloverTools.childNodes[1].style.display = "block";
    orangeArrowRolloverTools.childNodes[2].style.display = "block";
    orangeAddRolloverTools.childNodes[0].style.display = "block";
    element.style.border = "1px solid orange"; // Change border color on mouseover

    element.parentNode.parentNode.style.border = "none";
    for (let i = 0; i < 3; i++) {
      element.parentNode.parentNode.childNodes[0].childNodes[i].style.display = "none";
    }
    for (let i = 0; i < 3; i++) {
      element.parentNode.parentNode.childNodes[1].childNodes[i].style.display = "none";
    }
    element.parentNode.parentNode.childNodes[2].childNodes[0].style.display = "none";
    for (let i = 3; i < element.parentNode.parentNode.children.length; i++ ) {
      element.parentNode.parentNode.childNodes[i].style.borderRight = "none";
      if ( element.parentNode.parentNode.childNodes[i].childNodes[1].className == "div-boundary") {
        element.parentNode.parentNode.childNodes[i].childNodes[1].style.display = "none";
      }
    }
    addElementButtons = document.querySelectorAll("[id*='blue_add']");
    addElementButtons.forEach((item) => {
      item.style.display = "none";
    });
  });

  element.addEventListener("mouseleave", () => {
    orangeRolloverTools.style.display = "none";
    orangeArrowRolloverTools.style.display = "none";
    orangeAddRolloverTools.style.display = "none";
    orangeRolloverTools.childNodes[0].style.display = "none";
    orangeRolloverTools.childNodes[1].style.display = "none";
    orangeRolloverTools.childNodes[2].style.display = "none";
    orangeArrowRolloverTools.childNodes[0].style.display = "none";
    orangeArrowRolloverTools.childNodes[1].style.display = "none";
    orangeArrowRolloverTools.childNodes[2].style.display = "none";
    orangeAddRolloverTools.childNodes[0].style.display = "none";
    element.style.border = "none"; // Reset border color on mouseout

    element.parentNode.parentNode.style.border = "1px solid rgb(58, 133, 255)";
    for (let i = 0; i < 3; i++) {
      element.parentNode.parentNode.childNodes[0].childNodes[i].style.display = "block";
    }
    for (let i = 0; i < 3; i++) {
      element.parentNode.parentNode.childNodes[1].childNodes[i].style.display = "block";
    }
    element.parentNode.parentNode.childNodes[2].childNodes[0].style.display = "block";
    for (let i = 4; i < element.parentNode.parentNode.children.length; i++) {
      element.parentNode.parentNode.childNodes[i - 1].style.borderRight = "1px dotted rgb(58, 133, 255)";
      if (element.parentNode.parentNode.childNodes[i - 1].childNodes[0].className == "div-boundary") {
        element.parentNode.parentNode.childNodes[i - 1].childNodes[0].style.display = "block";
      }
    }
  });
}
function orangeSetting(element) {
  var parentWrapper = element.parentElement.parentElement;
    var parentType = parentWrapper.getAttribute("data-de-type");
    var firstChild = parentWrapper.firstChild;
    if (parentType === "headline") {
      headlineGearElement(parentWrapper, parentType);
    } else if (parentType === "subhead") {
      headlineGearElement(parentWrapper, parentType);
    } else if (parentType === "text") {
      headlineGearElement(parentWrapper, parentType);
    } else if (parentType === "button") {
      openSidebar(firstChild);
    } else if (parentType === "combo") {
      twoStepGearElement(parentWrapper);
    } else if (parentType === "image") {
      imageGearElement(parentWrapper);
    } else if (parentType === "video") {
      videoGearElement(parentWrapper);
    } else {
      headlineGearElement(parentWrapper, parentType);
    }
}
loadSections = function () {
  var newContainer = document.getElementById(id);
  var allContainers = newContainer.querySelectorAll(".col-div");

  if (allContainers.length > 0) {
    allContainers.forEach((container) => {
      var condition = container.getAttribute("data-dragetted");
      if (!condition) {
        container.setAttribute("data-dragetted", "true");
        addEventListenersForContainer(container);
      }
    });
    // updateContainers();
  } else {
    // Handle the case when no elements with the class .editor-container are found.
    // You can choose to display an error message or take appropriate action here.
  }
};

function configPopup() {
  let container = document.createElement("div");
  container.classList.add("editor-container", "new-section"); //p-3
  container.style.minHeight = "250px";
  container.style.backgroundColor = "#ffffff";

  let section = document.createElement("div");
  container.appendChild(section);
  // popupContainer.appendChild(container);
  var allContainers = document.querySelectorAll(".editor-container");

  if (allContainers.length > 0) {
    allContainers.forEach((container) => {
      addEventListenersForContainer(container);
    });
  } else {
  }
}

updateDraggables = function () {
  draggables = document.querySelectorAll(".draggable");
};

addEventListeners = function () {
  if (draggables) {
    draggables.forEach((draggable) => {
      draggable.addEventListener(
        "dragstart",
        (e) => onDragStart(e, draggable),
        false
      );
      draggable.addEventListener(
        "dragend",
        (e) => onDragEnd(e, draggable),
        false
      );
    });
  }
};

createPlaceHolder = function () {
  placeholder = document.createElement("div");
  placeholder.style.height = "50px";
  placeholder.style.borderRadius = "5px";
  placeholder.style.backgroundColor = "#eee";
  placeholder.style.margin = "10px 0";
  placeholder = placeholder;
};

getDragAfterElement = function (container, y) {
  const draggableElements = [
    ...container.querySelectorAll(".draggable:not(.dragging)"),
  ];
  return draggableElements.reduce(
    (closest, child) => {
      const box = child.getBoundingClientRect();
      const offset = y - box.top - box.height / 2;
      if (offset < 0 && offset > closest.offset) {
        return {
          offset: offset,
          element: child,
        };
      } else {
        return closest;
      }
    },
    {
      offset: Number.NEGATIVE_INFINITY,
    }
  ).element;
};

onDragStart = function (e, draggable) {
  e.stopPropagation();

  if (draggable && draggable.getAttribute("name")) {
    let element = draggable.getAttribute("name");

    switch (element) {
      case "headline-field": // * HEADLINE *****************************************
        const wrapper = document.createElement("div");
        wrapper.classList.add(
          "draggable",
          "de",
          "elHeadlineWrapper",
          "ui-droppable",
          "de-editable"
        );
        wrapper.setAttribute("id", `headline-${Date.now()}`);
        wrapper.setAttribute("data-de-type", "headline");
        wrapper.setAttribute("data-de-editing", "false");
        wrapper.setAttribute("data-title", "headline");
        wrapper.setAttribute("data-ce", "true");
        wrapper.setAttribute("data-trigger", "none");
        wrapper.setAttribute("data-animate", "fade");
        wrapper.setAttribute("data-delay", "500");
        // wrapper.style.marginTop = '15px';
        wrapper.style.outline = "none";
        wrapper.style.cursor = "pointer";
        wrapper.style.padding = "0";
        wrapper.style.backgroundColor = "transparent";
        wrapper.setAttribute("aria-disabled", "false");
        wrapper.setAttribute("draggable", true);

        wrapperElemnt = document.createElement("h1");
        wrapperElemnt.classList.add(
          "ne",
          "elHeadline",
          // "fs-1",
          "lh4",
          "elMargin0",
          "elBGStyle0",
          "hsTextShadow0",
          "display-5",
          "font-weight-normal"
        );
        wrapperElemnt.style.textAlign = "center";
        wrapperElemnt.style.fontSize = "32px";
        // wrapperElemnt.dataset.bold = "inherit";
        wrapperElemnt.dataset.gramm = "false";
        wrapperElemnt.style.color = "#000000";
        // wrapperElemnt.setAttribute('contenteditable', 'false');
        wrapperElemnt.setAttribute("contenteditable", "true");

        const bElement = document.createElement("b");
        bElement.textContent = "How To [GOOD] Without [BAD]";

        wrapperElemnt.appendChild(bElement);
        wrapperElemnt.setAttribute("id", `field-${Date.now()}`);

        wrapperElemnt.setAttribute("placeholder", "Text");
        wrapper.appendChild(wrapperElemnt);

        elementControl(wrapper);
        editTextControl(wrapper);
        elementToInsert = wrapper;
        existingElement = false;

        break;

      case "subhead-field":
        const subheadWrapper = document.createElement("div");
        subheadWrapper.classList.add(
          "draggable",
          "de",
          "elSubHeadlineWrapper",
          "ui-droppable",
          "de-editable"
        );
        subheadWrapper.setAttribute("id", `subhead-${Date.now()}`);
        subheadWrapper.setAttribute("data-de-type", "sub-headline");
        subheadWrapper.setAttribute("data-de-editing", "false");
        subheadWrapper.setAttribute("data-title", "subhead");
        subheadWrapper.setAttribute("data-ce", "true");
        subheadWrapper.setAttribute("data-trigger", "none");
        subheadWrapper.setAttribute("data-animate", "fade");
        subheadWrapper.setAttribute("data-delay", "500");
        // subheadWrapper.style.marginTop = '15px';
        subheadWrapper.style.outline = "none";
        subheadWrapper.style.cursor = "pointer";
        subheadWrapper.style.padding = "0";
        subheadWrapper.setAttribute("aria-disabled", "false");
        subheadWrapper.setAttribute("draggable", true);

        const subheadElement = document.createElement("h3");
        subheadElement.classList.add(
          "ne",
          "elSubHeadline",
          "hsSize3",
          "lh4",
          "elMargin0",
          "elBGStyle0",
          "hsTextShadow0"
        );
        subheadElement.style.textAlign = "center";
        subheadElement.style.fontSize = "28px";
        subheadElement.dataset.bold = "inherit";
        subheadElement.dataset.gramm = "false";
        subheadElement.textContent =
        "FREE: Brand New On-Demand Class Reveals ...";
        subheadElement.setAttribute("id", `field-${Date.now()}`);
        subheadElement.setAttribute("placeholder", "Subhead Text");
        subheadElement.setAttribute("contenteditable", "true");

        subheadWrapper.appendChild(subheadElement);
        elementControl(subheadWrapper);
        editTextControl(subheadWrapper);

        elementToInsert = subheadWrapper;
        existingElement = false;
        break;

      case "paragraph-field":
        const paragraphWrapper = document.createElement("div");
        paragraphWrapper.classList.add(
          "draggable",
          "de",
          "elparagraphWrapper",
          "ui-droppable",
          "de-editable"
        );
        paragraphWrapper.setAttribute("id", `text-${Date.now()}`);
        paragraphWrapper.setAttribute("data-de-type", "text");
        paragraphWrapper.setAttribute("data-de-editing", "false");
        paragraphWrapper.setAttribute("data-title", "text");
        paragraphWrapper.setAttribute("data-ce", "true");
        paragraphWrapper.setAttribute("data-trigger", "none");
        paragraphWrapper.setAttribute("data-animate", "fade");
        paragraphWrapper.setAttribute("data-delay", "500");
        // paragraphWrapper.style.marginTop = '15px';
        paragraphWrapper.style.outline = "none";
        paragraphWrapper.style.padding = "0";
        paragraphWrapper.style.cursor = "pointer";
        paragraphWrapper.setAttribute("aria-disabled", "false");
        paragraphWrapper.setAttribute("draggable", true);

        const textElement = document.createElement("p");
        textElement.classList.add(
          "ne",
          "elText",
          "hsSize3",
          "lh4",
          "elMargin0",
          "elBGStyle0",
          "hsTextShadow0"
        );
        // textElement.style.textAlign = 'center';
        textElement.style.fontSize = "20px";
        textElement.dataset.bold = "inherit";
        textElement.dataset.gramm = "false";
        // textElement.setAttribute('contenteditable', 'false');

        // const textPElement = document.createElement('p');
        textElement.textContent =
          "This Class Is Available Instantly ...No Waiting.";

        // textElement.appendChild(textPElement);
        textElement.setAttribute("id", `field-${Date.now()}`);
        textElement.setAttribute("placeholder", "Text");
        textElement.setAttribute("contenteditable", "true");

        paragraphWrapper.appendChild(textElement);
        elementControl(paragraphWrapper);
        editTextControl(paragraphWrapper);
        elementToInsert = paragraphWrapper;
        existingElement = false;
        break;

      case "image-field":
        const imageWrapper = document.createElement("div");
        imageWrapper.classList.add(
          "draggable",
          "de",
          "elSubHeadlineWrapper",
          "ui-droppable",
          "de-editable"
        );
        imageWrapper.setAttribute("id", `image-${Date.now()}`);
        imageWrapper.setAttribute("data-de-type", "image");
        imageWrapper.setAttribute("data-de-editing", "false");
        imageWrapper.setAttribute("data-title", "image");
        imageWrapper.setAttribute("data-ce", "true");
        imageWrapper.setAttribute("data-trigger", "none");
        imageWrapper.setAttribute("data-animate", "fade");
        imageWrapper.setAttribute("data-delay", "500");
        imageWrapper.style.outline = "none";
        imageWrapper.style.cursor = "pointer";
        imageWrapper.style.textAlign = "center";
        imageWrapper.setAttribute("aria-disabled", "false");
        imageWrapper.setAttribute("draggable", true);
        imageWrapper.innerHTML = `<img data-v-21a2eb52="" src="https://storage.googleapis.com/preview-production-assets/funnel/img/img_400x300.png" alt="broken image..." class="img-none img-border-none img-shadow-none img-effects-none">`;
        elementControl(imageWrapper);

        elementToInsert = imageWrapper;
        existingElement = false;
        break;

      case "video-field":
          const videoWrapper = document.createElement("div");
          videoWrapper.classList.add(
            "draggable",
            "de",
            "elSubHeadlineWrapper",
            "ui-droppable",
            "de-editable"
          );
          videoWrapper.setAttribute("id", `video-${Date.now()}`);
          videoWrapper.setAttribute("data-de-type", "video");
          videoWrapper.setAttribute("data-de-editing", "false");
          videoWrapper.setAttribute("data-title", "video");
          videoWrapper.setAttribute("data-ce", "true");
          videoWrapper.setAttribute("data-trigger", "none");
          videoWrapper.setAttribute("data-animate", "fade");
          videoWrapper.setAttribute("data-delay", "500");
          videoWrapper.style.outline = "none";
          videoWrapper.style.cursor = "unset";
          videoWrapper.setAttribute("aria-disabled", "false");
          videoWrapper.setAttribute("draggable", true);
          videoWrapper.innerHTML = `<video class="video-overlay" controls></video>`
          elementControl(videoWrapper);

          elementToInsert = videoWrapper;
          existingElement = false;
          break;

      case "list-field":
        const listWrapper = document.createElement("div");
        listWrapper.classList.add(
          "draggable",
          "de",
          "elSubHeadlineWrapper",
          "ui-droppable",
          "de-editable"
        );
        listWrapper.setAttribute("id", `list-${Date.now()}`);
        listWrapper.setAttribute("data-de-type", "Bullet List");
        listWrapper.setAttribute("data-de-editing", "false");
        listWrapper.setAttribute("data-title", "list");
        listWrapper.setAttribute("data-ce", "true");
        listWrapper.setAttribute("data-trigger", "none");
        listWrapper.setAttribute("data-animate", "fade");
        listWrapper.setAttribute("data-delay", "500");
        // listWrapper.style.marginTop = '15px';
        listWrapper.style.outline = "none";
        listWrapper.style.cursor = "pointer";
        listWrapper.setAttribute("aria-disabled", "false");
        listWrapper.setAttribute("draggable", true);

        const listWrapperElement = document.createElement("p");
        listWrapperElement.classList.add(
          "ne",
          "elText",
          "hsSize3",
          "lh4",
          "elMargin0",
          "elBGStyle0",
          "hsTextShadow0"
        );
        listWrapperElement.style.fontSize = "20px";
        listWrapperElement.dataset.bold = "inherit";
        listWrapperElement.dataset.gramm = "false";
        listWrapperElement.innerHTML = `<i class="bi bi-check"></i> Bullet List`;
        listWrapperElement.setAttribute("id", `field-${Date.now()}`);
        listWrapperElement.setAttribute("placeholder", "Text");
        listWrapperElement.setAttribute("contenteditable", "true");

        listWrapper.appendChild(listWrapperElement);

        elementControl(listWrapper);
        editTextControl(listWrapper);

        elementToInsert = listWrapper;
        existingElement = false;
        break;

      case "button-field":
        // Create the outer container
        const buttonContainer = document.createElement("div");
        buttonContainer.classList.add(
          "draggable",
          "de",
          "elBTN",
          "de-editable",
          "elAlign_center",
          "elMargin0"
        );
        buttonContainer.id = `tmp_button-${Date.now()}`;
        buttonContainer.dataset.deType = "button";
        buttonContainer.dataset.deEditing = "false";
        buttonContainer.dataset.title = "button";
        buttonContainer.dataset.ce = "false";
        buttonContainer.dataset.trigger = "none";
        buttonContainer.dataset.animate = "fade";
        buttonContainer.dataset.delay = "500";
        buttonContainer.style.outline = "none";
        buttonContainer.style.textAlign = "center";
        buttonContainer.setAttribute("onclick", "getButtonContainerId(this)");
        // buttonContainer.style.margin = '20px 30px';

        // Create the <a> element
        const linkElement = document.createElement("a");
        linkElement.href = "#submit-form";
        linkElement.id = `the_button-${Date.now()}`;
        linkElement.classList.add(
          "elSettings",
          "elButton",
          "elButtonSize1",
          "elButtonColor1",
          "elButtonRounded",
          "elButtonPadding2",
          "elBtnVP_10",
          "elButtonCorner3",
          "elButtonFluid",
          "elBtnHP_25",
          "elBTN_b_1",
          "elButtonShadowN1",
          "elButtonTxtColor1"
        );
        linkElement.style.color = "rgb(255, 255, 255)";
        linkElement.style.fontWeight = "600";
        linkElement.style.backgroundColor = "#ff0000";
        linkElement.style.fontSize = "20px";
        linkElement.rel = "noopener noreferrer";

        // Create the main and sub spans
        const mainSpan = document.createElement("span");
        mainSpan.classList.add("elButtonMain");
        mainSpan.textContent = "Let Me In!";

        const subSpan = document.createElement("span");
        subSpan.classList.add("elButtonSub");

        // Append the main and sub spans to the <a> element
        linkElement.appendChild(mainSpan);
        linkElement.appendChild(subSpan);

        // Append the <a> element to the button container
        buttonContainer.appendChild(linkElement);

        // Set the draggable attribute
        elementToInsert = buttonContainer;
        elementToInsert.setAttribute("draggable", true);
        elementControl(buttonContainer);

        elementToInsert = elementToInsert;
        existingElement = false;
        break;

      case "countdown-field":
        const currentDate = new Date();
        const futureDate = new Date();

        futureDate.setDate(currentDate.getDate() + 1); // Add 1 day
        futureDate.setHours(currentDate.getHours() + 12); // Add 11 hours

        // Construct the targetDateStr with the desired format, including hours, minutes, and seconds
        const targetDateStr = `${futureDate.getFullYear()}-${(
          futureDate.getMonth() + 1
        )
          .toString()
          .padStart(2, "0")}-${futureDate
          .getDate()
          .toString()
          .padStart(2, "0")}T${futureDate
          .getHours()
          .toString()
          .padStart(2, "0")}:${futureDate
          .getMinutes()
          .toString()
          .padStart(2, "0")}:${futureDate
          .getSeconds()
          .toString()
          .padStart(2, "0")}`;

        const targetDate = new Date(targetDateStr);
        const targetStamp = targetDate.getTime();

        const containercountdownWrapper = document.createElement("div");
        containercountdownWrapper.classList.add(
          "container-fluid",
          "draggable",
          "de",
          "elCountdownWrapper",
          "ui-droppable",
          "de-editable"
        );
        containercountdownWrapper.setAttribute("data-de-type", "CountDown");

        const countdownWrapper = document.createElement("div");
        countdownWrapper.classList.add("row", "no-gutters");
        countdownWrapper.setAttribute("id", `field-${Date.now()}`);
        // countdownWrapper.style.margin = 0;
        countdownWrapper.style.backgroundColor = "red";
        countdownWrapper.style.color = "yellow";
        countdownWrapper.style.display = "flex"; // Enable Flexbox
        countdownWrapper.style.alignItems = "center"; // Center content vertically

        const leftColumn = document.createElement("div");
        // leftColumn.classList.add('col-md-9');
        leftColumn.classList.add("col-md-8", "d-none", "d-md-block"); // Hide on iPhones, show on medium and larger screens

        const textLeft = document.createElement("div");
        textLeft.classList.add("text-left");

        function getFormattedDate(date) {
          const options = {
            weekday: "long",
            hour: "numeric",
            minute: "numeric",
            timeZoneName: "short",
            timeZone: "America/New_York",
            // timeZone: 'Europe/Vienna'
          };
          return date.toLocaleString("en-US", options);
        }

        const heading = document.createElement("div");
        // heading.style.fontSize = '24px'; // Set font size
        heading.style.fontSize = "1.6vw"; // 3% of the viewport width

        heading.style.fontWeight = "600"; // Set font weight
        heading.style.letterSpacing = "letter-spacing: -0.5px;"; // Set letter spacing
        heading.style.fontFamily = "Nunito Sans, sans-serif"; // Set font family
        heading.style.paddingLeft = "20px";
        const formattedTargetDateMessage = `Hurry! This special offer is available until ${getFormattedDate(
          currentDate
        )}`;
        heading.textContent = formattedTargetDateMessage;

        textLeft.appendChild(heading);
        // textLeft.appendChild(paragraph);
        leftColumn.appendChild(textLeft);

        const rightColumn = document.createElement("div");
        // rightColumn.classList.add('col-md-3');
        rightColumn.classList.add("col-12", "col-md-4"); // Span full width on small screens, and col-3 on medium and larger screens

        const countdownDiv = document.createElement("div");
        countdownDiv.classList.add(
          "de",
          "elCountdown",
          "de-editable",
          "elAlign_center",
          "elMargin0"
        );
        countdownDiv.setAttribute("id", `countdown-${Date.now()}`);
        countdownDiv.setAttribute("data-de-type", "countdown");
        countdownDiv.setAttribute("data-de-editing", "false");
        countdownDiv.setAttribute("data-title", "Date Countdown 2.0");
        countdownDiv.setAttribute("data-ce", "false");
        countdownDiv.setAttribute("data-trigger", "none");
        countdownDiv.setAttribute("data-animate", "fade");
        countdownDiv.setAttribute("data-delay", "500");
        countdownDiv.style.outline = "none";
        countdownDiv.style.backgroundColor = "red";
        countdownDiv.style.color = "yellow";
        countdownDiv.style.border = "0px none";

        const countdownElement = document.createElement("div");
        countdownElement.classList.add(
          "realcountdown",
          "wideCountdownSize2",
          "cdBlack",
          "cdStyleTextOnly",
          "clearfix",
          "hide"
        );

        countdownElement.setAttribute("data-date", targetDateStr);
        countdownElement.setAttribute("data-time", targetStamp);
        countdownElement.setAttribute("data-tz", "America/New_York");
        // countdownElement.setAttribute('data-tz', 'Europe/Vienna');
        countdownElement.setAttribute("data-url", "#");
        countdownElement.setAttribute("data-lang", "eng");
        countdownElement.textContent = "";

        const countdownDemo = document.createElement("div");
        countdownDemo.classList.add(
          "wideCountdown",
          "wideCountdownSize2",
          "cdBlack",
          "cdStyleTextOnly",
          "wideCountdown-demo",
          "is-countdown",
          "clearfix"
        );

        const timerDiv = document.createElement("div");
        timerDiv.classList.add("timer");

        const timerElements = [
          {
            number: "03",
            word: "days",
          },
          {
            number: "04",
            word: "hrs",
          },
          {
            number: "12",
            word: "min",
          },
          {
            number: "03",
            word: "sec",
          },
        ];

        timerElements.forEach((element) => {
          const timerItem = document.createElement("div");
          timerItem.style.display = "inline-block";
          timerItem.style.marginRight = "10px";

          const timerNumber = document.createElement("div");
          timerNumber.classList.add("timer-number");
          timerNumber.textContent = element.number;

          const timerWord = document.createElement("div");
          timerWord.classList.add("timer-word");
          timerWord.textContent = element.word;

          timerItem.appendChild(timerNumber);
          timerItem.appendChild(timerWord);
          timerDiv.appendChild(timerItem);
        });

        countdownElement.appendChild(timerDiv); // Nest the timer inside .realcountdown

        countdownDiv.appendChild(countdownElement);
        countdownDiv.appendChild(countdownDemo);

        // Append columns to the countdown wrapper
        containercountdownWrapper.appendChild(countdownWrapper);

        countdownWrapper.appendChild(leftColumn);
        countdownWrapper.appendChild(rightColumn);

        rightColumn.appendChild(countdownDiv);

        // countdownWrapper.appendChild(rolloverTools);

        countdownWrapper.setAttribute("draggable", true);
        elementControl(containercountdownWrapper);

        elementToInsert = containercountdownWrapper;
        existingElement = false;

        break;

      case "input-field":
        const inputWrapper = document.createElement("div");
        inputWrapper.classList.add(
          "draggable",
          "de",
          "elInputWrapper",
          "de-editable",
          "de-input-block",
          "elAlign_center",
          "elMargin0"
        );
        inputWrapper.setAttribute("id", `tmp_input-${Date.now()}`);
        inputWrapper.setAttribute("data-de-type", "input");
        inputWrapper.setAttribute("data-de-editing", "false");
        inputWrapper.setAttribute("data-title", "input");
        inputWrapper.setAttribute("data-ce", "false");
        inputWrapper.setAttribute("data-trigger", "none");
        inputWrapper.setAttribute("data-animate", "fade");
        inputWrapper.setAttribute("data-delay", "500");
        // inputWrapper.style.marginTop = "30px";
        inputWrapper.style.outline = "none";

        const inputElement = document.createElement("input");
        inputElement.type = "text";
        inputElement.setAttribute("id", `field-${Date.now()}`);
        inputElement.placeholder = "Your Name Here...";
        inputElement.name = "name"; //not-set
        inputElement.classList.add(
          "elInput",
          "elInput100",
          "elAlign_left",
          "elInputMid",
          "elInputStyl0",
          "elInputBG1",
          "elInputBR5",
          "elInputI0",
          "elInputIBlack",
          "elInputIRight",
          "required0",
          "ceoinput"
        );
        inputElement.dataset.type = "extra";
        inputElement.style.width = "100%"; // This sets the input field to full width

        moveButton = document.createElement("div");
        moveButton.classList.add("de-rollover-move");
        moveButton.innerHTML = '<i class="fa fa-arrows"></i>';

        advanceButton = document.createElement("div");
        advanceButton.classList.add("de-rollover-advance");
        advanceButton.innerHTML = '<i class="fa fa-cog"></i>';

        cloneButton = document.createElement("div");
        cloneButton.classList.add("de-rollover-clone");
        cloneButton.innerHTML = '<i class="fa fa-copy"></i>';

        removeButton = document.createElement("div");
        removeButton.classList.add("de-rollover-remove");
        removeButton.innerHTML = '<i class="fa fa-trash"></i>';

        // Append input and rollover tools to the wrapper
        inputWrapper.appendChild(inputElement);
        // inputWrapper.appendChild(rolloverTools);

        // Create addElementFlyoutDOM
        addElementFlyoutDOM = document.createElement("div");
        addElementFlyoutDOM.classList.add("addElementFlyoutDOM");
        addElementFlyoutDOM.style.display = "none";
        addElementFlyoutDOM.style.left = "325px";
        addElementFlyoutDOM.innerHTML = '<i class="fa fa-plus"></i>';

        inputWrapper.appendChild(addElementFlyoutDOM);

        // Set the draggable attribute
        inputWrapper.setAttribute("draggable", true);
        elementControl(inputWrapper);

        elementToInsert = inputWrapper;
        existingElement = false;
        break;

      case "email-field":
        const emailWrapper = document.createElement("div");
        emailWrapper.classList.add(
          "draggable",
          "de",
          "elemailWrapper",
          "de-editable",
          "de-input-block",
          "elAlign_center",
          "elMargin0"
        );
        emailWrapper.setAttribute("id", `tmp_input-${Date.now()}`);
        emailWrapper.setAttribute("data-de-type", "input");
        emailWrapper.setAttribute("data-de-editing", "false");
        emailWrapper.setAttribute("data-title", "input");
        emailWrapper.setAttribute("data-ce", "false");
        emailWrapper.setAttribute("data-trigger", "none");
        emailWrapper.setAttribute("data-animate", "fade");
        emailWrapper.setAttribute("data-delay", "500");
        // emailWrapper.style.marginTop = "30px";
        emailWrapper.style.outline = "none";

        const emailElement = document.createElement("input");
        emailElement.type = "text";
        emailElement.placeholder = "Your Email Address Here...";
        emailElement.name = "email";
        emailElement.setAttribute("id", `field-${Date.now()}`);
        emailElement.classList.add(
          "elInput",
          "elInput100",
          "elAlign_left",
          "elInputMid",
          "elInputStyl0",
          "elInputBG1",
          "elInputBR5",
          "elInputI0",
          "elInputIBlack",
          "elInputIRight",
          "required0",
          "ceoinput"
        );
        emailElement.dataset.type = "extra";
        emailElement.style.width = "100%"; // This sets the input field to full width

        // Append input and rollover tools to the wrapper
        emailWrapper.appendChild(emailElement);

        // Create addElementFlyoutDOM
        addElementFlyoutDOM = document.createElement("div");
        addElementFlyoutDOM.classList.add("addElementFlyoutDOM");
        addElementFlyoutDOM.style.display = "none";
        addElementFlyoutDOM.style.left = "325px";
        addElementFlyoutDOM.innerHTML = '<i class="fa fa-plus"></i>';

        emailWrapper.appendChild(addElementFlyoutDOM);

        // Set the draggable attribute
        emailWrapper.setAttribute("draggable", true);
        elementControl(emailWrapper);

        elementToInsert = emailWrapper;
        existingElement = false;
        break;

      case "2step-combo":
        const comboWrapper = document.createElement("div");
        comboWrapper.classList.add("container-fluid");
        comboWrapper.setAttribute("data-de-type", "combo");
        comboWrapper.setAttribute("id", `combo-${Date.now()}`);
        // comboWrapper.id = "2step-form1";

        const card = document.createElement("div");
        card.classList.add(
          "card",
          "px-5",
          "pb-5",
          "col-12",
          "col-lg-8",
          "mx-auto"
        );

        const container = document.createElement("div");
        container.classList.add("container", "mt-3");

        const form = document.createElement("form");
        form.id = "two-step-order-form";
        form.classList.add("container-order-form-two-step");

        const formTitle = document.createElement("div");
        formTitle.classList.add("form-title");

        const row = document.createElement("div");
        row.classList.add("row");

        const colMd6Step1 = createFormStep("Your profile", "Contact details");
        const colMd6Step2 = createFormStep(
          "Normally $297. Use coupon code FAP to get 90% OFF",
          "Billing details"
        );

        row.appendChild(colMd6Step1);
        row.appendChild(colMd6Step2);

        formTitle.appendChild(row);

        const dividerForm = document.createElement("div");
        dividerForm.classList.add("divider-form");
        dividerForm.innerHTML = '<i class="fas fa-caret-up caret-up"></i>';

        const formBody = document.createElement("div");
        formBody.classList.add("form-body", "pt-4");
        formBody.id = `formBody-${Date.now()}`;

        const sectionInfo = document.createElement("section");
        sectionInfo.classList.add("info");

        const inputs1 = [
          "Company Name..",
          "Full Name...",
          "Email Address...",
          "Phone Number...",
        ];
        inputs1.forEach((placeholder) => {
          const input = createInput("text", placeholder);
          sectionInfo.appendChild(input);
        });

        const sectionShipping = document.createElement("section");
        sectionShipping.classList.add("shipping");

        const inputs2 = [
          "Full Address...",
          "City Name...",
          "State / Province...",
          "Zip Code...",
        ];
        inputs2.forEach((placeholder) => {
          const input = createInput("text", placeholder);
          sectionShipping.appendChild(input);
        });

        const select = document.createElement("select");
        select.classList.add("form-select", "mb-3");
        select.value = "";
        select.name = "country";

        const option = document.createElement("option");
        option.disabled = true;
        option.value = "";
        option.textContent = "Select Country";
        select.appendChild(option);

        const countryOption = document.createElement("option");
        countryOption.value = "US";
        countryOption.textContent = "United Kingdom";
        select.appendChild(countryOption);

        sectionShipping.appendChild(select);

        const sectionButton = document.createElement("section");

        const button = document.createElement("button");
        button.classList.add("btn", "btn-success", "w-100", "p-2");
        button.type = "button";
        // button.onclick = () => showForm(form, formBody2.id);
        button.innerHTML = `<i class="fas fa-arrow-right fs-5"></i>
                      <span class="main-text fs-4" style="font-weight: 600;"> &nbsp; Go To Step #2 </span><br>
                      <span class="sub-text"></span>`;

        sectionButton.appendChild(button);

        const orderFormFooter = document.createElement("section");
        orderFormFooter.classList.add("order-form-footer");
        orderFormFooter.innerHTML =
          "<span>We Respect Your Privacy &amp; Information.</span>";

        formBody.appendChild(sectionInfo);
        formBody.appendChild(sectionShipping);
        formBody.appendChild(sectionButton);
        formBody.appendChild(orderFormFooter);

        // Second part for 2 Step Combo
        const formBody2 = document.createElement("div");
        formBody2.classList.add("form-body", "pt-4", "hidden");
        formBody2.id = `formBody2-${Date.now()}`;

        const sectionDetail = document.createElement("section");
        sectionDetail.classList.add("product-detail");
        sectionDetail.id = "ctwo-setp-order";

        const productTitle = document.createElement("div");
        productTitle.classList.add("product-title");
        productTitle.innerHTML = `
              <span class="item">Item</span>
              <span class="item text-center">Quantity</span>
              <span class="item">Price</span>
          `;

        const dividerProduct = document.createElement("div");
        dividerProduct.classList.add("divider-product");

        const productDescription = document.createElement("div");
        productDescription.id = "659d9244637b7ce094361944";
        productDescription.classList.add("product-description");
        productDescription.innerHTML = `
              <div class="d-flex">
                  <div class="d-flex radioBtn">
                      <input id="checkbox-ctwo-setp-order-659d9244637b7ce094361944" type="checkbox" value="659d9244637b7ce094361944">
                  </div>
                  <div>
                      <span class="item product-name" style="margin-left:7px;"><strong>FAP Airtable System</strong></span>
                      <div class="item-description"><strong></strong></div>
                  </div>
              </div>
              <div class="text-center item">1</div>
              <span class="item item-price">$29.00</span>
          `;

        sectionDetail.appendChild(productTitle);
        sectionDetail.appendChild(dividerProduct);
        sectionDetail.appendChild(productDescription);

        // Create main container
        const bpContainer = document.createElement("section");
        bpContainer.classList.add("bp-container");

        // Create product bump divider
        const productBumpDivider = document.createElement("div");
        productBumpDivider.classList.add("product-bump-divider");

        // Create order bump container
        const orderBumpContainer = document.createElement("section");
        orderBumpContainer.classList.add("order-bump-container");

        // Create main section within order bump container
        const mainSection = document.createElement("div");
        mainSection.classList.add("main-section");
        mainSection.innerHTML = `
            <img src="data:image/webp;base64,UklGRsYBAABXRUJQVlA4WAoAAAASAAAAGwAAEAAAQU5JTQYAAAAAAAAAAABBTk1GsgAAAAAAAAAAABsAABAAAA4BAANWUDhMmgAAAC8bAAQQH8GgbSRHx59rL/8/ys/gmH/FbSQ19F8pvxwHBs1/FIG/ppDrB1yyELIAuslyFqb4AEKWNQHOIiSbiaij+ADg3QGyESEADttIUqQ+Zmaeu84/y/v/mY8gov8TgH+eYwt5et+AvCoLck3eJuoOgQWlcQzIPbMgJ4uz0Ls7D2pLBKAefnxejhyqQlJaF2pjCG3ZUuiX+BpBTk1GJgAAAAAAAAAAAAAAAAAAAOYAAABWUDhMDQAAAC8AAAAQBxAREYiI/gcAQU5NRrIAAAAAAAAAAAAbAAAQAABGAAAAVlA4TJoAAAAvGwAEEB/BoG0kR8efay//P8rP4Jh/xW0kNfRfKb8cBwbNfxSBv6aQ6wdcshCyALrJcham+ABCljUBziIkm4moo/gA4N0BshEhAA7bSFKkPmZmnrvOP8v7/5mPIKL/E4B/nmMLeXrfgLwqC3JN3ibqDoEFpXEMyD2zICeLs9C7Ow9qSwSgHn58Xo4cqkJSWhdqYwht2VLol/ga" class="bump--flashing-arrow">
            <input type="checkbox" name="order-bump" class="bump--checkbox">
            <span class="headline bump-headline">YES! Add the "Advanced Ads Scaling Q&amp;A" for just $29!</span>
          `;

        // Create paragraph within order bump container
        const paragraph = document.createElement("p");
        paragraph.innerHTML = `
            <span class="oto-headline">Advanced Ads Scaling Q&amp;A Session</span>
            <span> Get a recording of one of our live monthly calls! Our media buyer who has run ads for Frank Kern, Agora, Dean Graziosi, Jeff Lerner (and more!) not only shows how to launch and SCALE campaigns but also answers the TOP questions most people when trying to scale ads! This is "Behind Closed Doors" information for pennies!</span>
          `;

        orderBumpContainer.appendChild(mainSection);
        orderBumpContainer.appendChild(paragraph);

        // Create separator for order summary
        const separator = document.createElement("div");
        separator.classList.add("separator");
        separator.textContent = "Order Summary";

        // Create product cost total section
        const productCostTotal = document.createElement("section");
        productCostTotal.classList.add("product-cost-total");
        productCostTotal.innerHTML = `
            <div class="product-title">
                <span class="item">item</span>
                <span class="item text-center">Quantity</span>
                <span class="item">amount</span>
            </div>
            <div class="divider-product"></div>
            <div class="product-description">
                <span class="item"><span class="coupon-item">FAP Airtable System</span><!----></span>
                <span class="item text-center">1</span>
                <span class="item item-price">$ 29.00</span>
            </div>
            <div class="divider-product"></div>
            <div class="order-total">
                <span class="item"><strong>Order Total</strong></span>
                <span class="item text-right">
                    <div class="item-price">$ 29.00</div>
                    <!---->
                </span>
            </div>
          `;

        // Append all elements to the main container
        bpContainer.appendChild(productBumpDivider);
        bpContainer.appendChild(orderBumpContainer);
        bpContainer.appendChild(separator);
        bpContainer.appendChild(productCostTotal);

        // Create billing form section
        const billingSection = document.createElement("section");
        billingSection.classList.add("billing");

        // Create credit card input elements
        const creditCardContainer = document.createElement("div");
        creditCardContainer.classList.add("ghl-payment-element", "pb-4");

        const inlineCreditCardContainer = document.createElement("div");
        inlineCreditCardContainer.classList.add("inline-credit-card-container");

        const rowDiv = document.createElement("div");
        rowDiv.classList.add("row");

        const colMd6Div1 = document.createElement("div");
        colMd6Div1.classList.add("col-md-6");

        const cardNumberLabel = document.createElement("label");
        cardNumberLabel.setAttribute("for", "cardNumber");
        cardNumberLabel.classList.add("card-input-label", "d-block");
        cardNumberLabel.textContent = "Card Number";

        const cardNumberInput = document.createElement("input");
        cardNumberInput.setAttribute("type", "text");
        cardNumberInput.setAttribute("name", "cc");
        cardNumberInput.setAttribute(
          "id",
          "cc-ctwo-setp-order-payment-element"
        );
        cardNumberInput.setAttribute("placeholder", "1234 1234 1234 1234");
        cardNumberInput.classList.add("card-input");

        colMd6Div1.appendChild(cardNumberLabel);
        colMd6Div1.appendChild(cardNumberInput);

        const colMd6Div2 = document.createElement("div");
        colMd6Div2.classList.add("col-md-6");

        const creditCardSubContainer = document.createElement("div");
        creditCardSubContainer.classList.add("credit-card-sub-container");

        const rowDiv2 = document.createElement("div");
        rowDiv2.classList.add("row");

        const colMd6Div3 = document.createElement("div");
        colMd6Div3.classList.add("col-md-6");

        const expirationLabel = document.createElement("label");
        expirationLabel.setAttribute("for", "cardExpiration");
        expirationLabel.classList.add("card-input-label");
        expirationLabel.textContent = "Expiration";

        const expirationInput = document.createElement("input");
        expirationInput.setAttribute("type", "text");
        expirationInput.setAttribute("name", "card-expiration");
        expirationInput.setAttribute(
          "id",
          "card-expiration-ctwo-setp-order-payment-element"
        );
        expirationInput.setAttribute("maxlength", "5");
        expirationInput.setAttribute("placeholder", "MM / YY");
        expirationInput.classList.add("card-input");

        colMd6Div3.appendChild(expirationLabel);
        colMd6Div3.appendChild(expirationInput);

        const colMd6Div4 = document.createElement("div");
        colMd6Div4.classList.add("col-md-6");

        const cvcLabel = document.createElement("label");
        cvcLabel.setAttribute("for", "cardCvc");
        cvcLabel.classList.add("card-input-label");
        cvcLabel.textContent = "CVC";

        const cvcInput = document.createElement("input");
        cvcInput.setAttribute("type", "text");
        cvcInput.setAttribute("name", "card-cvc");
        cvcInput.setAttribute("id", "card-cvc-ctwo-setp-order-payment-element");
        cvcInput.setAttribute("maxlength", "3");
        cvcInput.setAttribute("placeholder", "CVC");
        cvcInput.classList.add("card-input");

        colMd6Div4.appendChild(cvcLabel);
        colMd6Div4.appendChild(cvcInput);

        rowDiv2.appendChild(colMd6Div3);
        rowDiv2.appendChild(colMd6Div4);

        creditCardSubContainer.appendChild(rowDiv2);

        colMd6Div2.appendChild(creditCardSubContainer);

        rowDiv.appendChild(colMd6Div1);
        rowDiv.appendChild(colMd6Div2);

        inlineCreditCardContainer.appendChild(rowDiv);

        creditCardContainer.appendChild(inlineCreditCardContainer);

        // Create order button
        const orderButton = document.createElement("button");
        orderButton.classList.add("btn", "btn-success", "w-100", "p-2");
        orderButton.onclick = () => showForm(form, formBody.id);

        const icon = document.createElement("i");
        icon.classList.add("fas", "fa-arrow-right", "fs-5");

        const mainText = document.createElement("span");
        mainText.classList.add("main-text", "fs-4");
        mainText.setAttribute("style", "font-weight: 600;");
        mainText.innerHTML = "&nbsp; Complete Order";

        const subText = document.createElement("span");
        subText.classList.add("sub-text");

        orderButton.appendChild(icon);
        orderButton.appendChild(mainText);
        orderButton.appendChild(document.createElement("br"));
        orderButton.appendChild(subText);

        // Create order form footer section
        const orderFormFooter2 = document.createElement("section");
        orderFormFooter2.classList.add("order-form-footer");
        orderFormFooter2.innerHTML =
          "<span>* 100% Secure & Safe Payments *</span>";

        // Append elements to the billing section
        billingSection.appendChild(creditCardContainer);
        billingSection.appendChild(orderButton);
        billingSection.appendChild(orderFormFooter2);

        formBody2.appendChild(sectionDetail);
        formBody2.appendChild(bpContainer);
        formBody2.appendChild(billingSection);

        form.appendChild(formTitle);
        form.appendChild(dividerForm);
        form.appendChild(formBody);
        form.appendChild(formBody2);

        container.appendChild(form);
        card.appendChild(container);
        comboWrapper.appendChild(card);
        elementControl(comboWrapper);

        elementToInsert = comboWrapper;
        existingElement = false;
        break;

      case "phone-field":
        const phoneWrapper = document.createElement("div");
        phoneWrapper.classList.add(
          "draggable",
          "de",
          "elSubHeadlineWrapper",
          "ui-droppable",
          "de-editable"
        );
        phoneWrapper.setAttribute("id", `phone-${Date.now()}`);
        phoneWrapper.setAttribute("data-de-type", "phone-field");
        phoneWrapper.setAttribute("data-de-editing", "false");
        phoneWrapper.setAttribute("data-title", "phone");
        phoneWrapper.setAttribute("data-ce", "true");
        phoneWrapper.setAttribute("data-trigger", "none");
        phoneWrapper.setAttribute("data-animate", "fade");
        phoneWrapper.setAttribute("data-delay", "500");
        phoneWrapper.style.outline = "none";
        phoneWrapper.style.cursor = "pointer";
        phoneWrapper.setAttribute("aria-disabled", "false");
        phoneWrapper.setAttribute("draggable", true);
        phoneWrapper.innerHTML = `<p id=field-${Date.now()}" style="display:flex; margin:auto; justify-content:center;">Phone</p>`;
        elementControl(phoneWrapper);

        elementToInsert = phoneWrapper;
        existingElement = false;
        break;
      default:
        elementToInsert = draggable;
        existingElement = true;
        break;
    }
  } else {
    existingElement = true;
    elementToInsert = draggable;
  }
  placeholder.setAttribute("id", `placeholder-${Date.now()}`);
  draggable.classList.add("dragging");
};

function onDragEnd(e, draggable) {
  draggable.classList.remove("dragging");
  updateTextareaFromContainer(
    "da-main-container",
    "step[large_html_blob_content]"
  );
  updateTextareaFromContainer(
    "da-popup-container",
    "step[popup_html_blob_content]"
  );

  var settingsSidebar = document.getElementById("settingsSidebar");
  var anchor = elementToInsert.querySelector("a.elSettings"); // Find the anchor element within 'this'

  if (anchor) {
    anchor.addEventListener("click", function (event) {
      event.preventDefault(); // Prevent the default behavior

      if (settingsSidebar.style.right === "0px") {
        closeSidebar();
      } else {
        openSidebar(anchor);
      }
    });
  }

  if (!existingElement) {
    addEventListenerForDraggableItem(elementToInsert);
    updateDraggables("draggables");
  } else {
    elementToInsert.classList.remove("dragging");
  }
}



function addElementWithClickInput(e, draggable, inputedField) {
  e.stopPropagation();
  if (draggable && draggable.getAttribute("name")) {
    let element = draggable.getAttribute("name");

    switch (element) {
      case "headline-field": // * HEADLINE *****************************************
        const wrapper = document.createElement("div");
        wrapper.classList.add(
          "draggable",
          "de",
          "elHeadlineWrapper",
          "ui-droppable",
          "de-editable"
        );
        wrapper.setAttribute("id", `headline-${Date.now()}`);
        wrapper.setAttribute("data-de-type", "headline");
        wrapper.setAttribute("data-de-editing", "false");
        wrapper.setAttribute("data-title", "headline");
        wrapper.setAttribute("data-ce", "true");
        wrapper.setAttribute("data-trigger", "none");
        wrapper.setAttribute("data-animate", "fade");
        wrapper.setAttribute("data-delay", "500");
        // wrapper.style.marginTop = '15px';
        wrapper.style.outline = "none";
        wrapper.style.cursor = "pointer";
        wrapper.style.padding = "0";
        wrapper.style.backgroundColor = "transparent";
        wrapper.setAttribute("aria-disabled", "false");
        wrapper.setAttribute("draggable", true);

        wrapperElemnt = document.createElement("h1");
        wrapperElemnt.classList.add(
          "ne",
          "elHeadline",
          // "fs-1",
          "lh4",
          "elMargin0",
          "elBGStyle0",
          "hsTextShadow0",
          "display-5",
          "font-weight-normal"
        );
        wrapperElemnt.style.textAlign = "center";
        wrapperElemnt.style.fontSize = "32px";
        // wrapperElemnt.dataset.bold = "inherit";
        wrapperElemnt.dataset.gramm = "false";
        wrapperElemnt.style.color = "#000000";
        // wrapperElemnt.setAttribute('contenteditable', 'false');
        wrapperElemnt.setAttribute("contenteditable", "true");

        const bElement = document.createElement("b");
        bElement.textContent = "How To [GOOD] Without [BAD]";

        wrapperElemnt.appendChild(bElement);
        wrapperElemnt.setAttribute("id", `field-${Date.now()}`);

        wrapperElemnt.setAttribute("placeholder", "Text");
        wrapper.appendChild(wrapperElemnt);

        elementControl(wrapper);
        editTextControl(wrapper);
        inputedField.appendChild(wrapper);
        break;

      case "subhead-field":
        const subheadWrapper = document.createElement("div");
        subheadWrapper.classList.add(
          "draggable",
          "de",
          "elSubHeadlineWrapper",
          "ui-droppable",
          "de-editable"
        );
        subheadWrapper.setAttribute("id", `subhead-${Date.now()}`);
        subheadWrapper.setAttribute("data-de-type", "sub-headline");
        subheadWrapper.setAttribute("data-de-editing", "false");
        subheadWrapper.setAttribute("data-title", "subhead");
        subheadWrapper.setAttribute("data-ce", "true");
        subheadWrapper.setAttribute("data-trigger", "none");
        subheadWrapper.setAttribute("data-animate", "fade");
        subheadWrapper.setAttribute("data-delay", "500");
        // subheadWrapper.style.marginTop = '15px';
        subheadWrapper.style.outline = "none";
        subheadWrapper.style.cursor = "pointer";
        subheadWrapper.style.padding = "0";
        subheadWrapper.setAttribute("aria-disabled", "false");
        subheadWrapper.setAttribute("draggable", true);

        const subheadElement = document.createElement("h3");
        subheadElement.classList.add(
          "ne",
          "elSubHeadline",
          "hsSize3",
          "lh4",
          "elMargin0",
          "elBGStyle0",
          "hsTextShadow0"
        );
        subheadElement.style.textAlign = "center";
        subheadElement.style.fontSize = "28px";
        subheadElement.dataset.bold = "inherit";
        subheadElement.dataset.gramm = "false";
        subheadElement.textContent =
        "FREE: Brand New On-Demand Class Reveals ...";
        subheadElement.setAttribute("id", `field-${Date.now()}`);
        subheadElement.setAttribute("placeholder", "Subhead Text");
        subheadElement.setAttribute("contenteditable", "true");

        subheadWrapper.appendChild(subheadElement);
        elementControl(subheadWrapper);
        editTextControl(subheadWrapper);

        inputedField.appendChild(subheadWrapper);
        existingElement = false;
        break;

      case "paragraph-field":
        const paragraphWrapper = document.createElement("div");
        paragraphWrapper.classList.add(
          "draggable",
          "de",
          "elparagraphWrapper",
          "ui-droppable",
          "de-editable"
        );
        paragraphWrapper.setAttribute("id", `text-${Date.now()}`);
        paragraphWrapper.setAttribute("data-de-type", "text");
        paragraphWrapper.setAttribute("data-de-editing", "false");
        paragraphWrapper.setAttribute("data-title", "text");
        paragraphWrapper.setAttribute("data-ce", "true");
        paragraphWrapper.setAttribute("data-trigger", "none");
        paragraphWrapper.setAttribute("data-animate", "fade");
        paragraphWrapper.setAttribute("data-delay", "500");
        // paragraphWrapper.style.marginTop = '15px';
        paragraphWrapper.style.outline = "none";
        paragraphWrapper.style.padding = "0";
        paragraphWrapper.style.cursor = "pointer";
        paragraphWrapper.setAttribute("aria-disabled", "false");
        paragraphWrapper.setAttribute("draggable", true);

        const textElement = document.createElement("p");
        textElement.classList.add(
          "ne",
          "elText",
          "hsSize3",
          "lh4",
          "elMargin0",
          "elBGStyle0",
          "hsTextShadow0"
        );
        // textElement.style.textAlign = 'center';
        textElement.style.fontSize = "20px";
        textElement.dataset.bold = "inherit";
        textElement.dataset.gramm = "false";
        // textElement.setAttribute('contenteditable', 'false');

        // const textPElement = document.createElement('p');
        textElement.textContent =
          "This Class Is Available Instantly ...No Waiting.";

        // textElement.appendChild(textPElement);
        textElement.setAttribute("id", `field-${Date.now()}`);
        textElement.setAttribute("placeholder", "Text");
        textElement.setAttribute("contenteditable", "true");

        paragraphWrapper.appendChild(textElement);
        elementControl(paragraphWrapper);
        editTextControl(paragraphWrapper);
        inputedField.appendChild(paragraphWrapper);
        existingElement = false;
        break;

      case "image-field":
        const imageWrapper = document.createElement("div");
        imageWrapper.classList.add(
          "draggable",
          "de",
          "elSubHeadlineWrapper",
          "ui-droppable",
          "de-editable"
        );
        imageWrapper.setAttribute("id", `image-${Date.now()}`);
        imageWrapper.setAttribute("data-de-type", "image");
        imageWrapper.setAttribute("data-de-editing", "false");
        imageWrapper.setAttribute("data-title", "image");
        imageWrapper.setAttribute("data-ce", "true");
        imageWrapper.setAttribute("data-trigger", "none");
        imageWrapper.setAttribute("data-animate", "fade");
        imageWrapper.setAttribute("data-delay", "500");
        imageWrapper.style.outline = "none";
        imageWrapper.style.cursor = "pointer";
        imageWrapper.style.textAlign = "center";
        imageWrapper.setAttribute("aria-disabled", "false");
        imageWrapper.setAttribute("draggable", true);
        imageWrapper.innerHTML = `<img data-v-21a2eb52="" src="https://storage.googleapis.com/preview-production-assets/funnel/img/img_400x300.png" alt="broken image..." class="img-none img-border-none img-shadow-none img-effects-none">`;
        elementControl(imageWrapper);

        inputedField.appendChild(imageWrapper);
        existingElement = false;
        break;

      case "video-field":
          const videoWrapper = document.createElement("div");
          videoWrapper.classList.add(
            "draggable",
            "de",
            "elSubHeadlineWrapper",
            "ui-droppable",
            "de-editable"
          );
          videoWrapper.setAttribute("id", `video-${Date.now()}`);
          videoWrapper.setAttribute("data-de-type", "video");
          videoWrapper.setAttribute("data-de-editing", "false");
          videoWrapper.setAttribute("data-title", "video");
          videoWrapper.setAttribute("data-ce", "true");
          videoWrapper.setAttribute("data-trigger", "none");
          videoWrapper.setAttribute("data-animate", "fade");
          videoWrapper.setAttribute("data-delay", "500");
          videoWrapper.style.outline = "none";
          videoWrapper.style.cursor = "unset";
          videoWrapper.setAttribute("aria-disabled", "false");
          videoWrapper.setAttribute("draggable", true);
          videoWrapper.innerHTML = `<video class="video-overlay" controls></video>`
          elementControl(videoWrapper);

          inputedField.appendChild(videoWrapper);
          existingElement = false;
          break;

        case "list-field":
          const listWrapper = document.createElement("div");
          listWrapper.classList.add(
            "draggable",
            "de",
            "elSubHeadlineWrapper",
            "ui-droppable",
            "de-editable"
          );
          listWrapper.setAttribute("id", `list-${Date.now()}`);
          listWrapper.setAttribute("data-de-type", "Bullet List");
          listWrapper.setAttribute("data-de-editing", "false");
          listWrapper.setAttribute("data-title", "list");
          listWrapper.setAttribute("data-ce", "true");
          listWrapper.setAttribute("data-trigger", "none");
          listWrapper.setAttribute("data-animate", "fade");
          listWrapper.setAttribute("data-delay", "500");
          // listWrapper.style.marginTop = '15px';
          listWrapper.style.outline = "none";
          listWrapper.style.cursor = "pointer";
          listWrapper.setAttribute("aria-disabled", "false");
          listWrapper.setAttribute("draggable", true);
  
          const listWrapperElement = document.createElement("p");
          listWrapperElement.classList.add(
            "ne",
            "elText",
            "hsSize3",
            "lh4",
            "elMargin0",
            "elBGStyle0",
            "hsTextShadow0"
          );
          listWrapperElement.style.fontSize = "20px";
          listWrapperElement.dataset.bold = "inherit";
          listWrapperElement.dataset.gramm = "false";
          listWrapperElement.innerHTML = `<i class="bi bi-check"></i> Bullet List`;
          listWrapperElement.setAttribute("id", `field-${Date.now()}`);
          listWrapperElement.setAttribute("placeholder", "Text");
          listWrapperElement.setAttribute("contenteditable", "true");
  
          listWrapper.appendChild(listWrapperElement);
  
          elementControl(listWrapper);
          editTextControl(listWrapper);
  
          inputedField.appendChild(listWrapper);
          existingElement = false;
          break;
          

      case "button-field":
        // Create the outer container
        const buttonContainer = document.createElement("div");
        buttonContainer.classList.add(
          "draggable",
          "de",
          "elBTN",
          "de-editable",
          "elAlign_center",
          "elMargin0"
        );
        buttonContainer.id = `tmp_button-${Date.now()}`;
        buttonContainer.dataset.deType = "button";
        buttonContainer.dataset.deEditing = "false";
        buttonContainer.dataset.title = "button";
        buttonContainer.dataset.ce = "false";
        buttonContainer.dataset.trigger = "none";
        buttonContainer.dataset.animate = "fade";
        buttonContainer.dataset.delay = "500";
        buttonContainer.style.outline = "none";
        buttonContainer.style.textAlign = "center";
        buttonContainer.setAttribute("onclick", "getButtonContainerId(this)");
        // buttonContainer.style.margin = '20px 30px';

        // Create the <a> element
        const linkElement = document.createElement("a");
        linkElement.href = "#submit-form";
        linkElement.id = `the_button-${Date.now()}`;
        linkElement.classList.add(
          "elSettings",
          "elButton",
          "elButtonSize1",
          "elButtonColor1",
          "elButtonRounded",
          "elButtonPadding2",
          "elBtnVP_10",
          "elButtonCorner3",
          "elButtonFluid",
          "elBtnHP_25",
          "elBTN_b_1",
          "elButtonShadowN1",
          "elButtonTxtColor1"
        );
        linkElement.style.color = "rgb(255, 255, 255)";
        linkElement.style.fontWeight = "600";
        linkElement.style.backgroundColor = "#ff0000";
        linkElement.style.fontSize = "20px";
        linkElement.rel = "noopener noreferrer";

        // Create the main and sub spans
        const mainSpan = document.createElement("span");
        mainSpan.classList.add("elButtonMain");
        mainSpan.textContent = "Let Me In!";

        const subSpan = document.createElement("span");
        subSpan.classList.add("elButtonSub");

        // Append the main and sub spans to the <a> element
        linkElement.appendChild(mainSpan);
        linkElement.appendChild(subSpan);

        // Append the <a> element to the button container
        buttonContainer.appendChild(linkElement);

        // Add rollover tools for the button (you should complete this part)

        // Set the draggable attribute
        elementToInsert = buttonContainer;
        elementToInsert.setAttribute("draggable", true);
        elementControl(buttonContainer);

        inputedField.appendChild(buttonContainer);
        existingElement = false;
        break;

      case "countdown-field":
        const currentDate = new Date();
        const futureDate = new Date();

        futureDate.setDate(currentDate.getDate() + 1); // Add 1 day
        futureDate.setHours(currentDate.getHours() + 12); // Add 11 hours

        // Construct the targetDateStr with the desired format, including hours, minutes, and seconds
        const targetDateStr = `${futureDate.getFullYear()}-${(
          futureDate.getMonth() + 1
        )
          .toString()
          .padStart(2, "0")}-${futureDate
          .getDate()
          .toString()
          .padStart(2, "0")}T${futureDate
          .getHours()
          .toString()
          .padStart(2, "0")}:${futureDate
          .getMinutes()
          .toString()
          .padStart(2, "0")}:${futureDate
          .getSeconds()
          .toString()
          .padStart(2, "0")}`;

        const targetDate = new Date(targetDateStr);
        const targetStamp = targetDate.getTime();

        const containercountdownWrapper = document.createElement("div");
        containercountdownWrapper.classList.add(
          "container-fluid",
          "draggable",
          "de",
          "elCountdownWrapper",
          "ui-droppable",
          "de-editable"
        );
        containercountdownWrapper.setAttribute("data-de-type", "CountDown");

        const countdownWrapper = document.createElement("div");
        countdownWrapper.classList.add("row", "no-gutters");
        countdownWrapper.setAttribute("id", `field-${Date.now()}`);
        // countdownWrapper.style.margin = 0;
        countdownWrapper.style.backgroundColor = "red";
        countdownWrapper.style.color = "yellow";
        countdownWrapper.style.display = "flex"; // Enable Flexbox
        countdownWrapper.style.alignItems = "center"; // Center content vertically

        const leftColumn = document.createElement("div");
        // leftColumn.classList.add('col-md-9');
        leftColumn.classList.add("col-md-8", "d-none", "d-md-block"); // Hide on iPhones, show on medium and larger screens

        const textLeft = document.createElement("div");
        textLeft.classList.add("text-left");

        function getFormattedDate(date) {
          const options = {
            weekday: "long",
            hour: "numeric",
            minute: "numeric",
            timeZoneName: "short",
            timeZone: "America/New_York",
            // timeZone: 'Europe/Vienna'
          };
          return date.toLocaleString("en-US", options);
        }

        const heading = document.createElement("div");
        // heading.style.fontSize = '24px'; // Set font size
        heading.style.fontSize = "1.6vw"; // 3% of the viewport width

        heading.style.fontWeight = "600"; // Set font weight
        heading.style.letterSpacing = "letter-spacing: -0.5px;"; // Set letter spacing
        heading.style.fontFamily = "Nunito Sans, sans-serif"; // Set font family
        heading.style.paddingLeft = "20px";
        const formattedTargetDateMessage = `Hurry! This special offer is available until ${getFormattedDate(
          currentDate
        )}`;
        heading.textContent = formattedTargetDateMessage;

        textLeft.appendChild(heading);
        // textLeft.appendChild(paragraph);
        leftColumn.appendChild(textLeft);

        const rightColumn = document.createElement("div");
        // rightColumn.classList.add('col-md-3');
        rightColumn.classList.add("col-12", "col-md-4"); // Span full width on small screens, and col-3 on medium and larger screens

        const countdownDiv = document.createElement("div");
        countdownDiv.classList.add(
          "de",
          "elCountdown",
          "de-editable",
          "elAlign_center",
          "elMargin0"
        );
        countdownDiv.setAttribute("id", `countdown-${Date.now()}`);
        countdownDiv.setAttribute("data-de-type", "countdown");
        countdownDiv.setAttribute("data-de-editing", "false");
        countdownDiv.setAttribute("data-title", "Date Countdown 2.0");
        countdownDiv.setAttribute("data-ce", "false");
        countdownDiv.setAttribute("data-trigger", "none");
        countdownDiv.setAttribute("data-animate", "fade");
        countdownDiv.setAttribute("data-delay", "500");
        countdownDiv.style.outline = "none";
        countdownDiv.style.backgroundColor = "red";
        countdownDiv.style.color = "yellow";
        countdownDiv.style.border = "0px none";

        const countdownElement = document.createElement("div");
        countdownElement.classList.add(
          "realcountdown",
          "wideCountdownSize2",
          "cdBlack",
          "cdStyleTextOnly",
          "clearfix",
          "hide"
        );

        countdownElement.setAttribute("data-date", targetDateStr);
        countdownElement.setAttribute("data-time", targetStamp);
        countdownElement.setAttribute("data-tz", "America/New_York");
        // countdownElement.setAttribute('data-tz', 'Europe/Vienna');
        countdownElement.setAttribute("data-url", "#");
        countdownElement.setAttribute("data-lang", "eng");
        countdownElement.textContent = "";

        const countdownDemo = document.createElement("div");
        countdownDemo.classList.add(
          "wideCountdown",
          "wideCountdownSize2",
          "cdBlack",
          "cdStyleTextOnly",
          "wideCountdown-demo",
          "is-countdown",
          "clearfix"
        );

        const timerDiv = document.createElement("div");
        timerDiv.classList.add("timer");

        const timerElements = [
          {
            number: "03",
            word: "days",
          },
          {
            number: "04",
            word: "hrs",
          },
          {
            number: "12",
            word: "min",
          },
          {
            number: "03",
            word: "sec",
          },
        ];

        timerElements.forEach((element) => {
          const timerItem = document.createElement("div");
          timerItem.style.display = "inline-block";
          timerItem.style.marginRight = "10px";

          const timerNumber = document.createElement("div");
          timerNumber.classList.add("timer-number");
          timerNumber.textContent = element.number;

          const timerWord = document.createElement("div");
          timerWord.classList.add("timer-word");
          timerWord.textContent = element.word;

          timerItem.appendChild(timerNumber);
          timerItem.appendChild(timerWord);
          timerDiv.appendChild(timerItem);
        });

        countdownElement.appendChild(timerDiv); // Nest the timer inside .realcountdown

        countdownDiv.appendChild(countdownElement);
        countdownDiv.appendChild(countdownDemo);

        // Append columns to the countdown wrapper
        containercountdownWrapper.appendChild(countdownWrapper);

        countdownWrapper.appendChild(leftColumn);
        countdownWrapper.appendChild(rightColumn);

        rightColumn.appendChild(countdownDiv);

        // countdownWrapper.appendChild(rolloverTools);

        countdownWrapper.setAttribute("draggable", true);
        elementControl(containercountdownWrapper);

        inputedField.appendChild(containercountdownWrapper);
        existingElement = false;

        break;

      case "input-field":
        const inputWrapper = document.createElement("div");
        inputWrapper.classList.add(
          "draggable",
          "de",
          "elInputWrapper",
          "de-editable",
          "de-input-block",
          "elAlign_center",
          "elMargin0"
        );
        inputWrapper.setAttribute("id", `tmp_input-${Date.now()}`);
        inputWrapper.setAttribute("data-de-type", "input");
        inputWrapper.setAttribute("data-de-editing", "false");
        inputWrapper.setAttribute("data-title", "input");
        inputWrapper.setAttribute("data-ce", "false");
        inputWrapper.setAttribute("data-trigger", "none");
        inputWrapper.setAttribute("data-animate", "fade");
        inputWrapper.setAttribute("data-delay", "500");
        // inputWrapper.style.marginTop = "30px";
        inputWrapper.style.outline = "none";

        const inputElement = document.createElement("input");
        inputElement.type = "text";
        inputElement.setAttribute("id", `field-${Date.now()}`);
        inputElement.placeholder = "Your Name Here...";
        inputElement.name = "name"; //not-set
        inputElement.classList.add(
          "elInput",
          "elInput100",
          "elAlign_left",
          "elInputMid",
          "elInputStyl0",
          "elInputBG1",
          "elInputBR5",
          "elInputI0",
          "elInputIBlack",
          "elInputIRight",
          "required0",
          "ceoinput"
        );
        inputElement.dataset.type = "extra";
        inputElement.style.width = "100%"; // This sets the input field to full width

        moveButton = document.createElement("div");
        moveButton.classList.add("de-rollover-move");
        moveButton.innerHTML = '<i class="fa fa-arrows"></i>';

        advanceButton = document.createElement("div");
        advanceButton.classList.add("de-rollover-advance");
        advanceButton.innerHTML = '<i class="fa fa-cog"></i>';

        cloneButton = document.createElement("div");
        cloneButton.classList.add("de-rollover-clone");
        cloneButton.innerHTML = '<i class="fa fa-copy"></i>';

        removeButton = document.createElement("div");
        removeButton.classList.add("de-rollover-remove");
        removeButton.innerHTML = '<i class="fa fa-trash"></i>';

        // Append input and rollover tools to the wrapper
        inputWrapper.appendChild(inputElement);
        // inputWrapper.appendChild(rolloverTools);

        // Create addElementFlyoutDOM
        addElementFlyoutDOM = document.createElement("div");
        addElementFlyoutDOM.classList.add("addElementFlyoutDOM");
        addElementFlyoutDOM.style.display = "none";
        addElementFlyoutDOM.style.left = "325px";
        addElementFlyoutDOM.innerHTML = '<i class="fa fa-plus"></i>';

        inputWrapper.appendChild(addElementFlyoutDOM);

        // Set the draggable attribute
        inputWrapper.setAttribute("draggable", true);
        elementControl(inputWrapper);

        inputedField.appendChild(inputWrapper);
        existingElement = false;
        break;

      case "email-field":
        const emailWrapper = document.createElement("div");
        emailWrapper.classList.add(
          "draggable",
          "de",
          "elemailWrapper",
          "de-editable",
          "de-input-block",
          "elAlign_center",
          "elMargin0"
        );
        emailWrapper.setAttribute("id", `tmp_input-${Date.now()}`);
        emailWrapper.setAttribute("data-de-type", "input");
        emailWrapper.setAttribute("data-de-editing", "false");
        emailWrapper.setAttribute("data-title", "input");
        emailWrapper.setAttribute("data-ce", "false");
        emailWrapper.setAttribute("data-trigger", "none");
        emailWrapper.setAttribute("data-animate", "fade");
        emailWrapper.setAttribute("data-delay", "500");
        // emailWrapper.style.marginTop = "30px";
        emailWrapper.style.outline = "none";

        const emailElement = document.createElement("input");
        emailElement.type = "text";
        emailElement.placeholder = "Your Email Address Here...";
        emailElement.name = "email";
        emailElement.setAttribute("id", `field-${Date.now()}`);
        emailElement.classList.add(
          "elInput",
          "elInput100",
          "elAlign_left",
          "elInputMid",
          "elInputStyl0",
          "elInputBG1",
          "elInputBR5",
          "elInputI0",
          "elInputIBlack",
          "elInputIRight",
          "required0",
          "ceoinput"
        );
        emailElement.dataset.type = "extra";
        emailElement.style.width = "100%"; // This sets the input field to full width

        // Append input and rollover tools to the wrapper
        emailWrapper.appendChild(emailElement);

        // Create addElementFlyoutDOM
        addElementFlyoutDOM = document.createElement("div");
        addElementFlyoutDOM.classList.add("addElementFlyoutDOM");
        addElementFlyoutDOM.style.display = "none";
        addElementFlyoutDOM.style.left = "325px";
        addElementFlyoutDOM.innerHTML = '<i class="fa fa-plus"></i>';

        emailWrapper.appendChild(addElementFlyoutDOM);

        // Set the draggable attribute
        emailWrapper.setAttribute("draggable", true);
        elementControl(emailWrapper);

        inputedField.appendChild(emailWrapper);
        existingElement = false;
        break;

      case "2step-combo":
        const comboWrapper = document.createElement("div");
        comboWrapper.classList.add("container-fluid");
        comboWrapper.setAttribute("data-de-type", "combo");
        comboWrapper.setAttribute("id", `combo-${Date.now()}`);
        // comboWrapper.id = "2step-form1";

        const card = document.createElement("div");
        card.classList.add(
          "card",
          "px-5",
          "pb-5",
          "col-12",
          "col-lg-8",
          "mx-auto"
        );

        const container = document.createElement("div");
        container.classList.add("container", "mt-3");

        const form = document.createElement("form");
        form.id = "two-step-order-form";
        form.classList.add("container-order-form-two-step");

        const formTitle = document.createElement("div");
        formTitle.classList.add("form-title");

        const row = document.createElement("div");
        row.classList.add("row");

        const colMd6Step1 = createFormStep("Your profile", "Contact details");
        const colMd6Step2 = createFormStep(
          "Normally $297. Use coupon code FAP to get 90% OFF",
          "Billing details"
        );

        row.appendChild(colMd6Step1);
        row.appendChild(colMd6Step2);

        formTitle.appendChild(row);

        const dividerForm = document.createElement("div");
        dividerForm.classList.add("divider-form");
        dividerForm.innerHTML = '<i class="fas fa-caret-up caret-up"></i>';

        const formBody = document.createElement("div");
        formBody.classList.add("form-body", "pt-4");
        formBody.id = `formBody-${Date.now()}`;

        const sectionInfo = document.createElement("section");
        sectionInfo.classList.add("info");

        const inputs1 = [
          "Company Name..",
          "Full Name...",
          "Email Address...",
          "Phone Number...",
        ];
        inputs1.forEach((placeholder) => {
          const input = createInput("text", placeholder);
          sectionInfo.appendChild(input);
        });

        const sectionShipping = document.createElement("section");
        sectionShipping.classList.add("shipping");

        const inputs2 = [
          "Full Address...",
          "City Name...",
          "State / Province...",
          "Zip Code...",
        ];
        inputs2.forEach((placeholder) => {
          const input = createInput("text", placeholder);
          sectionShipping.appendChild(input);
        });

        const select = document.createElement("select");
        select.classList.add("form-select", "mb-3");
        select.value = "";
        select.name = "country";

        const option = document.createElement("option");
        option.disabled = true;
        option.value = "";
        option.textContent = "Select Country";
        select.appendChild(option);

        const countryOption = document.createElement("option");
        countryOption.value = "US";
        countryOption.textContent = "United Kingdom";
        select.appendChild(countryOption);

        sectionShipping.appendChild(select);

        const sectionButton = document.createElement("section");

        const button = document.createElement("button");
        button.classList.add("btn", "btn-success", "w-100", "p-2");
        button.type = "button";
        // button.onclick = () => showForm(form, formBody2.id);
        button.innerHTML = `<i class="fas fa-arrow-right fs-5"></i>
                      <span class="main-text fs-4" style="font-weight: 600;"> &nbsp; Go To Step #2 </span><br>
                      <span class="sub-text"></span>`;

        sectionButton.appendChild(button);

        const orderFormFooter = document.createElement("section");
        orderFormFooter.classList.add("order-form-footer");
        orderFormFooter.innerHTML =
          "<span>We Respect Your Privacy &amp; Information.</span>";

        formBody.appendChild(sectionInfo);
        formBody.appendChild(sectionShipping);
        formBody.appendChild(sectionButton);
        formBody.appendChild(orderFormFooter);

        // Second part for 2 Step Combo
        const formBody2 = document.createElement("div");
        formBody2.classList.add("form-body", "pt-4", "hidden");
        formBody2.id = `formBody2-${Date.now()}`;

        const sectionDetail = document.createElement("section");
        sectionDetail.classList.add("product-detail");
        sectionDetail.id = "ctwo-setp-order";

        const productTitle = document.createElement("div");
        productTitle.classList.add("product-title");
        productTitle.innerHTML = `
              <span class="item">Item</span>
              <span class="item text-center">Quantity</span>
              <span class="item">Price</span>
          `;

        const dividerProduct = document.createElement("div");
        dividerProduct.classList.add("divider-product");

        const productDescription = document.createElement("div");
        productDescription.id = "659d9244637b7ce094361944";
        productDescription.classList.add("product-description");
        productDescription.innerHTML = `
              <div class="d-flex">
                  <div class="d-flex radioBtn">
                      <input id="checkbox-ctwo-setp-order-659d9244637b7ce094361944" type="checkbox" value="659d9244637b7ce094361944">
                  </div>
                  <div>
                      <span class="item product-name" style="margin-left:7px;"><strong>FAP Airtable System</strong></span>
                      <div class="item-description"><strong></strong></div>
                  </div>
              </div>
              <div class="text-center item">1</div>
              <span class="item item-price">$29.00</span>
          `;

        sectionDetail.appendChild(productTitle);
        sectionDetail.appendChild(dividerProduct);
        sectionDetail.appendChild(productDescription);

        // Create main container
        const bpContainer = document.createElement("section");
        bpContainer.classList.add("bp-container");

        // Create product bump divider
        const productBumpDivider = document.createElement("div");
        productBumpDivider.classList.add("product-bump-divider");

        // Create order bump container
        const orderBumpContainer = document.createElement("section");
        orderBumpContainer.classList.add("order-bump-container");

        // Create main section within order bump container
        const mainSection = document.createElement("div");
        mainSection.classList.add("main-section");
        mainSection.innerHTML = `
            <img src="data:image/webp;base64,UklGRsYBAABXRUJQVlA4WAoAAAASAAAAGwAAEAAAQU5JTQYAAAAAAAAAAABBTk1GsgAAAAAAAAAAABsAABAAAA4BAANWUDhMmgAAAC8bAAQQH8GgbSRHx59rL/8/ys/gmH/FbSQ19F8pvxwHBs1/FIG/ppDrB1yyELIAuslyFqb4AEKWNQHOIiSbiaij+ADg3QGyESEADttIUqQ+Zmaeu84/y/v/mY8gov8TgH+eYwt5et+AvCoLck3eJuoOgQWlcQzIPbMgJ4uz0Ls7D2pLBKAefnxejhyqQlJaF2pjCG3ZUuiX+BpBTk1GJgAAAAAAAAAAAAAAAAAAAOYAAABWUDhMDQAAAC8AAAAQBxAREYiI/gcAQU5NRrIAAAAAAAAAAAAbAAAQAABGAAAAVlA4TJoAAAAvGwAEEB/BoG0kR8efay//P8rP4Jh/xW0kNfRfKb8cBwbNfxSBv6aQ6wdcshCyALrJcham+ABCljUBziIkm4moo/gA4N0BshEhAA7bSFKkPmZmnrvOP8v7/5mPIKL/E4B/nmMLeXrfgLwqC3JN3ibqDoEFpXEMyD2zICeLs9C7Ow9qSwSgHn58Xo4cqkJSWhdqYwht2VLol/ga" class="bump--flashing-arrow">
            <input type="checkbox" name="order-bump" class="bump--checkbox">
            <span class="headline bump-headline">YES! Add the "Advanced Ads Scaling Q&amp;A" for just $29!</span>
          `;

        // Create paragraph within order bump container
        const paragraph = document.createElement("p");
        paragraph.innerHTML = `
            <span class="oto-headline">Advanced Ads Scaling Q&amp;A Session</span>
            <span> Get a recording of one of our live monthly calls! Our media buyer who has run ads for Frank Kern, Agora, Dean Graziosi, Jeff Lerner (and more!) not only shows how to launch and SCALE campaigns but also answers the TOP questions most people when trying to scale ads! This is "Behind Closed Doors" information for pennies!</span>
          `;

        orderBumpContainer.appendChild(mainSection);
        orderBumpContainer.appendChild(paragraph);

        // Create separator for order summary
        const separator = document.createElement("div");
        separator.classList.add("separator");
        separator.textContent = "Order Summary";

        // Create product cost total section
        const productCostTotal = document.createElement("section");
        productCostTotal.classList.add("product-cost-total");
        productCostTotal.innerHTML = `
            <div class="product-title">
                <span class="item">item</span>
                <span class="item text-center">Quantity</span>
                <span class="item">amount</span>
            </div>
            <div class="divider-product"></div>
            <div class="product-description">
                <span class="item"><span class="coupon-item">FAP Airtable System</span><!----></span>
                <span class="item text-center">1</span>
                <span class="item item-price">$ 29.00</span>
            </div>
            <div class="divider-product"></div>
            <div class="order-total">
                <span class="item"><strong>Order Total</strong></span>
                <span class="item text-right">
                    <div class="item-price">$ 29.00</div>
                    <!---->
                </span>
            </div>
          `;

        // Append all elements to the main container
        bpContainer.appendChild(productBumpDivider);
        bpContainer.appendChild(orderBumpContainer);
        bpContainer.appendChild(separator);
        bpContainer.appendChild(productCostTotal);

        // Create billing form section
        const billingSection = document.createElement("section");
        billingSection.classList.add("billing");

        // Create credit card input elements
        const creditCardContainer = document.createElement("div");
        creditCardContainer.classList.add("ghl-payment-element", "pb-4");

        const inlineCreditCardContainer = document.createElement("div");
        inlineCreditCardContainer.classList.add("inline-credit-card-container");

        const rowDiv = document.createElement("div");
        rowDiv.classList.add("row");

        const colMd6Div1 = document.createElement("div");
        colMd6Div1.classList.add("col-md-6");

        const cardNumberLabel = document.createElement("label");
        cardNumberLabel.setAttribute("for", "cardNumber");
        cardNumberLabel.classList.add("card-input-label", "d-block");
        cardNumberLabel.textContent = "Card Number";

        const cardNumberInput = document.createElement("input");
        cardNumberInput.setAttribute("type", "text");
        cardNumberInput.setAttribute("name", "cc");
        cardNumberInput.setAttribute(
          "id",
          "cc-ctwo-setp-order-payment-element"
        );
        cardNumberInput.setAttribute("placeholder", "1234 1234 1234 1234");
        cardNumberInput.classList.add("card-input");

        colMd6Div1.appendChild(cardNumberLabel);
        colMd6Div1.appendChild(cardNumberInput);

        const colMd6Div2 = document.createElement("div");
        colMd6Div2.classList.add("col-md-6");

        const creditCardSubContainer = document.createElement("div");
        creditCardSubContainer.classList.add("credit-card-sub-container");

        const rowDiv2 = document.createElement("div");
        rowDiv2.classList.add("row");

        const colMd6Div3 = document.createElement("div");
        colMd6Div3.classList.add("col-md-6");

        const expirationLabel = document.createElement("label");
        expirationLabel.setAttribute("for", "cardExpiration");
        expirationLabel.classList.add("card-input-label");
        expirationLabel.textContent = "Expiration";

        const expirationInput = document.createElement("input");
        expirationInput.setAttribute("type", "text");
        expirationInput.setAttribute("name", "card-expiration");
        expirationInput.setAttribute(
          "id",
          "card-expiration-ctwo-setp-order-payment-element"
        );
        expirationInput.setAttribute("maxlength", "5");
        expirationInput.setAttribute("placeholder", "MM / YY");
        expirationInput.classList.add("card-input");

        colMd6Div3.appendChild(expirationLabel);
        colMd6Div3.appendChild(expirationInput);

        const colMd6Div4 = document.createElement("div");
        colMd6Div4.classList.add("col-md-6");

        const cvcLabel = document.createElement("label");
        cvcLabel.setAttribute("for", "cardCvc");
        cvcLabel.classList.add("card-input-label");
        cvcLabel.textContent = "CVC";

        const cvcInput = document.createElement("input");
        cvcInput.setAttribute("type", "text");
        cvcInput.setAttribute("name", "card-cvc");
        cvcInput.setAttribute("id", "card-cvc-ctwo-setp-order-payment-element");
        cvcInput.setAttribute("maxlength", "3");
        cvcInput.setAttribute("placeholder", "CVC");
        cvcInput.classList.add("card-input");

        colMd6Div4.appendChild(cvcLabel);
        colMd6Div4.appendChild(cvcInput);

        rowDiv2.appendChild(colMd6Div3);
        rowDiv2.appendChild(colMd6Div4);

        creditCardSubContainer.appendChild(rowDiv2);

        colMd6Div2.appendChild(creditCardSubContainer);

        rowDiv.appendChild(colMd6Div1);
        rowDiv.appendChild(colMd6Div2);

        inlineCreditCardContainer.appendChild(rowDiv);

        creditCardContainer.appendChild(inlineCreditCardContainer);

        // Create order button
        const orderButton = document.createElement("button");
        orderButton.classList.add("btn", "btn-success", "w-100", "p-2");
        orderButton.onclick = () => showForm(form, formBody.id);

        const icon = document.createElement("i");
        icon.classList.add("fas", "fa-arrow-right", "fs-5");

        const mainText = document.createElement("span");
        mainText.classList.add("main-text", "fs-4");
        mainText.setAttribute("style", "font-weight: 600;");
        mainText.innerHTML = "&nbsp; Complete Order";

        const subText = document.createElement("span");
        subText.classList.add("sub-text");

        orderButton.appendChild(icon);
        orderButton.appendChild(mainText);
        orderButton.appendChild(document.createElement("br"));
        orderButton.appendChild(subText);

        // Create order form footer section
        const orderFormFooter2 = document.createElement("section");
        orderFormFooter2.classList.add("order-form-footer");
        orderFormFooter2.innerHTML =
          "<span>* 100% Secure & Safe Payments *</span>";

        // Append elements to the billing section
        billingSection.appendChild(creditCardContainer);
        billingSection.appendChild(orderButton);
        billingSection.appendChild(orderFormFooter2);

        formBody2.appendChild(sectionDetail);
        formBody2.appendChild(bpContainer);
        formBody2.appendChild(billingSection);

        form.appendChild(formTitle);
        form.appendChild(dividerForm);
        form.appendChild(formBody);
        form.appendChild(formBody2);

        container.appendChild(form);
        card.appendChild(container);
        comboWrapper.appendChild(card);
        elementControl(comboWrapper);

        inputedField.appendChild(comboWrapper);
        existingElement = false;
        break;

      case "phone-field":
        const phoneWrapper = document.createElement("div");
        phoneWrapper.classList.add(
          "draggable",
          "de",
          "elSubHeadlineWrapper",
          "ui-droppable",
          "de-editable"
        );
        phoneWrapper.setAttribute("id", `phone-${Date.now()}`);
        phoneWrapper.setAttribute("data-de-type", "phone-field");
        phoneWrapper.setAttribute("data-de-editing", "false");
        phoneWrapper.setAttribute("data-title", "phone");
        phoneWrapper.setAttribute("data-ce", "true");
        phoneWrapper.setAttribute("data-trigger", "none");
        phoneWrapper.setAttribute("data-animate", "fade");
        phoneWrapper.setAttribute("data-delay", "500");
        phoneWrapper.style.outline = "none";
        phoneWrapper.style.cursor = "pointer";
        phoneWrapper.setAttribute("aria-disabled", "false");
        phoneWrapper.setAttribute("draggable", true);
        phoneWrapper.innerHTML = `<p id=field-${Date.now()}" style="display:flex; margin:auto; justify-content:center;">Phone</p>`;
        elementControl(phoneWrapper);

        inputedField.appendChild(phoneWrapper);
        existingElement = false;
        break;
      default:
        elementToInsert = draggable;
        existingElement = true;
        break;
    }
  } else {
    existingElement = true;
    elementToInsert = draggable;
  }
}
  

function addEventListenerForDraggableItem(element) {
  element.addEventListener("dragstart", (e) => onDragStart(e, element));
  element.addEventListener("dragend", (e) => onDragEnd(e, element));

  const elHeadlineElements = element.querySelectorAll(
    ".elHeadline, .elText, .elSubHeadline"
  ); // Select .elHeadline elements inside the div

  // Add click event listener for content editing to each .elHeadline element
  elHeadlineElements.forEach((elHeadlineElement) => {
    elHeadlineElement.addEventListener("mousedown", function () {
      elHeadlineElement.setAttribute("contenteditable", "true");
      elHeadlineElement.style.cursor = "text";
    });
  });
}

function addEventListenersForContainer(container) {
  container.addEventListener("dragover", (e) =>
    onDragHover(e, container, false)
  );
  container.addEventListener("drop", (e) => onDragDrop(e), false);
  container.addEventListener("dragleave", (e) => onDragLeave(e), false);
  container.addEventListener("dragenter", (e) => onDragEnter(e), false);
}

function onDragHover(e, container) {
  e.preventDefault();
  afterElement = getDragAfterElement(container, e.clientY);

  if (afterElement == null) {
    container.appendChild(placeholder);
  } else {
    container.insertBefore(placeholder, afterElement);
  }
}

function onDragEnter(e) {
  e.preventDefault();
}

function onDragLeave(e) {
  e.preventDefault();
}

function onDragDrop(e) {
  e.preventDefault();
  placeholder.replaceWith(elementToInsert);
}

function init() {
  try {
    mainContainer = document.getElementById("da-main-container");
    popupContainer = document.getElementById("da-popup-container");
    configPopup();

    // updateContainers();
    updateDraggables();
    addEventListeners();
    createPlaceHolder();
  } catch (e) {
  }
}

//* BEGINNING FOR THE 2PART FORM

function createFormContainer(id, heading1, subHeading1, heading2, subHeading2) {
  const container = document.createElement("div");
  container.classList.add("container-fluid");
  container.id = id;

  const card = document.createElement("div");
  card.classList.add("card", "px-5", "pb-5", "col-12", "col-lg-8", "mx-auto");

  const containerInner = document.createElement("div");
  containerInner.classList.add("container", "mt-3");

  const formTitle = document.createElement("div");
  formTitle.classList.add("form-title");

  const row = document.createElement("div");
  row.classList.add("row");

  const colMd6Step1 = createFormStep("Your profile222", "Contact details");
  const colMd6Step2 = createFormStep(
    "Normally $297. Use coupon code FAP to get 90% OFF",
    "Billing details"
  );

  row.appendChild(colMd6Step1);
  row.appendChild(colMd6Step2);

  formTitle.appendChild(row);
  containerInner.appendChild(formTitle);

  card.appendChild(containerInner);
  container.appendChild(card);

  return container;
}

function createForm(id, formClass, nextFormId) {
  const form = document.createElement("form");
  form.id = id;
  form.classList.add(formClass);

  const dividerForm = document.createElement("div");
  dividerForm.classList.add("divider-form");
  dividerForm.innerHTML = '<i class="fas fa-caret-up caret-up"></i>';

  form.appendChild(dividerForm);

  return form;
}

function createFormStep(heading, subHeading) {
  const colMd6 = document.createElement("div");
  colMd6.classList.add("col-md-6");

  const rowInner = document.createElement("div");
  rowInner.classList.add("row");

  const formStep = document.createElement("div");
  formStep.classList.add("form-step", "text-center", "col-md-11", "p-0");
  formStep.innerHTML = `<span class="form-heading active">${heading}</span> <br>
                        <span class="form-sub-heading">${subHeading}</span>`;

  const colMd1 = document.createElement("div");
  colMd1.classList.add("col-md-1", "p-0");

  const hr = document.createElement("hr");
  hr.classList.add("separator-vertical", "m-0");

  rowInner.appendChild(formStep);
  rowInner.appendChild(colMd1);
  rowInner.appendChild(hr);

  colMd6.appendChild(rowInner);

  return colMd6;
}

function createFormBody(id, inputs1, inputs2, country) {
  const formBody = document.createElement("div");
  formBody.classList.add("form-body", "pt-4");
  formBody.id = id;

  const sectionInfo = document.createElement("section");
  sectionInfo.classList.add("info");

  inputs1.forEach((placeholder) => {
    const input = createInput("text", placeholder);
    sectionInfo.appendChild(input);
  });

  const sectionShipping = document.createElement("section");
  sectionShipping.classList.add("shipping");

  inputs2.forEach((placeholder) => {
    const input = createInput("text", placeholder);
    sectionShipping.appendChild(input);
  });

  const select = document.createElement("select");
  select.classList.add("form-select", "mb-3");
  select.name = "country";

  const option = document.createElement("option");
  option.disabled = true;
  option.value = "";
  option.textContent = "Select Country";

  select.appendChild(option);

  const countryOption = document.createElement("option");
  countryOption.value = "US";
  countryOption.textContent = country;

  select.appendChild(countryOption);

  sectionShipping.appendChild(select);

  const sectionButton = document.createElement("section");

  const button = document.createElement("button");
  button.classList.add("btn", "btn-success", "w-100", "p-2");
  button.type = "button";
  // button.onclick = () => showForm();
  button.innerHTML = `<i class="fas fa-arrow-right fs-5"></i>
                      <span class="main-text fs-4" style="font-weight: 600;"> &nbsp; Go To Step #2 </span><br>
                      <span class="sub-text"></span>`;

  sectionButton.appendChild(button);

  formBody.appendChild(sectionInfo);
  formBody.appendChild(sectionShipping);
  formBody.appendChild(sectionButton);

  return formBody;
}

function createInput(type, placeholder) {
  const input = document.createElement("input");
  input.type = type;
  input.name = placeholder.toLowerCase().replace(/\s/g, "");
  input.placeholder = placeholder;
  input.classList.add("form-control", "mb-3");

  return input;
}

function createFormButtons(nextFormId, buttonText) {
  const section = document.createElement("section");
  section.classList.add("order-form-footer");

  const button = document.createElement("button");
  button.classList.add("btn", "btn-success", "w-100", "p-2");
  // button.onclick = () => showForm(nextFormId);
  button.innerHTML = `<i class="fas fa-arrow-right fs-5"></i>
                      <span class="main-text fs-4" style="font-weight: 600;"> &nbsp; ${buttonText} </span><br>
                      <span class="sub-text"></span>`;

  section.appendChild(button);

  return section;
}

function createPaymentForm() {
  const form = document.createElement("form");
  form.classList.add("form-payment", "order-form-v2");

  const paymentContent = document.createElement("div");
  paymentContent.classList.add("payment-content");

  const paymentForm = document.createElement("div");
  paymentForm.id = "ctwo-setp-order-payment-form";
  paymentForm.classList.add("payment-form");

  const vSpinner = document.createElement("div");
  vSpinner.classList.add("v-spinner", "loaderClass");
  vSpinner.style.display = "none";

  const vMoon1 = createVMoon("30px", "30px", "100%", "rgb(24, 139, 246)");
  const vMoon2 = createVMoon(
    "4.28571px",
    "4.28571px",
    "100%",
    "rgb(24, 139, 246)"
  );
  const vMoon3 = createVMoon(
    "30px",
    "30px",
    "100%",
    "rgb(24, 139, 246)",
    "4.28571px"
  );

  vSpinner.appendChild(vMoon1);
  vSpinner.appendChild(vMoon2);
  vSpinner.appendChild(vMoon3);

  paymentForm.appendChild(vSpinner);

  paymentContent.appendChild(paymentForm);
  form.appendChild(paymentContent);

  return form;
}

function createVMoon(height, width, borderRadius, backgroundColor, border) {
  const vMoon = document.createElement("div");
  vMoon.classList.add("v-moon");
  vMoon.style.height = height;
  vMoon.style.width = width;
  vMoon.style.borderRadius = borderRadius;
  vMoon.style.backgroundColor = backgroundColor;

  if (border) {
    vMoon.style.border = border;
  }

  return vMoon;
}

function showForm(form, formId) {
  document.getElementById(form.childNodes[2].id).classList.add("hidden");
  document.getElementById(form.childNodes[3].id).classList.add("hidden");
  const currentForm = document.getElementById(formId);
  if (currentForm) {
    currentForm.classList.remove("hidden");
  }
}

function appendElements(parent, elements) {
  elements.forEach((element) => {
    parent.appendChild(element);
  });
}

//* END FOR 2PART FORM

function updateTextareaFromContainer(containerId, textareaName) {
  const mainContainer = document.getElementById(containerId);
  const textarea = document.querySelector(`textarea[name="${textareaName}"]`);

  if (mainContainer && textarea) {
    textarea.value = mainContainer.innerHTML;
  } else {
    console.error("Container or textarea not found");
  }
}

function isPopupOpen() {
  var popup = document.querySelector(".popup-container");
  return popup.classList.contains("open"); // Or check the display style
}

// * MAIN CODE SECTION ------------------------------------------------------------------

var customDragnDropInitialized = false;

function loadSections() {
  var newContainer = document.getElementById(id);
  var allContainers = newContainer.querySelectorAll(".col-div");

  if (allContainers.length > 0) {
    allContainers.forEach((container) => {
      var condition = container.getAttribute("data-dragetted");
      if (!condition) {
        container.setAttribute("data-dragetted", "true");
        addEventListenersForContainer(container);
      }
    });
    // updateContainers();
  } else {
    // Handle the case when no elements with the class .editor-container are found.
    // You can choose to display an error message or take appropriate action here.
  }
}

function addEventListenersForContainer(container) {
  container.addEventListener("dragover", (e) =>
    onDragHover(e, container, false)
  );
  container.addEventListener("drop", (e) => onDragDrop(e), false);
  container.addEventListener("dragleave", (e) => onDragLeave(e), false);
  container.addEventListener("dragenter", (e) => onDragEnter(e), false);
}

function onDragHover(e, container) {
  e.preventDefault();
  afterElement = getDragAfterElement(container, e.clientY);

  if (afterElement == null) {
    container.appendChild(placeholder);
  } else {
    container.insertBefore(placeholder, afterElement);
  }
}
function onDragEnter(e) {
  e.preventDefault();
}

function onDragLeave(e) {
  e.preventDefault();
}

function onDragDrop(e) {
  e.preventDefault();
  placeholder.replaceWith(elementToInsert);
}

// document.addEventListener('turbolinks:load', () => {
document.addEventListener("DOMContentLoaded", function (e) {
  if (!customDragnDropInitialized) {
    init();

    const addSectionButton = document.getElementById("add-section-button");
    if (addSectionButton) {
      addSectionButton.addEventListener("click", () => {
        if (setSectionWidthPopup.style.right === "0px") {
          setSectionWidthPopup.style.right = "-350px"; // Slide out the popup
        } else {
          setSectionWidthPopup.style.right = "0px"; // Slide in the popup
        }
      });
    }
  } else {
  }
});

openElementsPanel.addEventListener("click", function () {
  openAddElementPopup(this);
});
function closeElementsPanel() {
  leftSlidingPopup.classList.add("hidden");
  basicContainerSection.style.maxWidth = "100vw";
  basicContainerSection.style.marginLeft = "0px";
}

//here we will add the listener to save the HTML before they submit the form
document.addEventListener("DOMContentLoaded", function () {
  const formWrapper = document.getElementById("editorFormWrapper");
  const form = formWrapper.querySelector("form");

  if (form) {
    form.addEventListener("submit", function (e) {
      // Prevent the form from submitting immediately.
      e.preventDefault();

      // Call the updateTextareaFromContainer function.
      updateTextareaFromContainer(
        "da-main-container",
        "step[large_html_blob_content]"
      );
      updateTextareaFromContainer(
        "da-popup-container",
        "step[popup_html_blob_content]"
      );
      // Now, you can choose to submit the form manually.
      form.submit();
    });
  }
});

// The popup START
const openPopupButton = document.getElementById("open-popup");
const closePopupButton = document.getElementById("close-popup");
const popup = document.querySelector(".popup-container");
const thebody = document.querySelector("body");
const damaincontainer = document.getElementById("da-main-container");

openPopupButton.addEventListener("click", function (event) {
  event.preventDefault();

  // Display the popup
  popup.classList.add("open");

  popup.style.display = "block";
  thebody.style.backgroundColor = "rgba(100, 100, 100, 0.1)"; // Red with 50% opacity
  // damaincontainer.style.opacity = 0.5;
  damaincontainer.style.display = "none"; // Set the background color to red
});

closePopupButton.addEventListener("click", function (event) {
  event.preventDefault();
  popup.classList.remove("open");
  popup.style.display = "none";

  damaincontainer.style.display = "block"; // Set the background color to red
});
// The popup END

//------------------------------------------------------------------
//settingsSidebar

let selectedElSettings = null; // Global variable to store the selected .elSettings element

// Select all anchor elements within elements with class "elSettings"
var elSettingsAnchors = document.querySelectorAll("a.elSettings");
var settingsSidebar = document.getElementById("settingsSidebar");

function openSidebar(element) {
  selectedElSettings = element.id; // Store the clicked element's ID
  if (settingsSidebar.style.right === "0px") {
    closeSidebar();
  } else {
    settingsSidebar.style.right = "0px";
  }
  loadPresetButtonSettings(element);
}

function closeSidebar() {
  selectedElSettings = null;
  settingsSidebar.style.right = "-350px";
}

// Attach the click event to each anchor element within "elSettings" buttons
elSettingsAnchors.forEach(function (anchor) {
  anchor.addEventListener("click", function (event) {
    event.preventDefault(); // Prevent the default behavior
    if (settingsSidebar.style.right === "0px") {
      closeSidebar();
    } else {
      openSidebar(anchor);
    }
  });
});

// hide the url input -- this is only when the page is already loaded -- it looks like the code  in the loadPresetSettings, but we need this too

const urlInputContainers = document.querySelectorAll(".url-input-container");
const actionSelect = document.getElementById("action-select");

actionSelect.addEventListener("change", () => {
  const selectedValue = actionSelect.value;
  urlInputContainers.forEach((container) => {
    if (selectedValue === "#") {
      container.style.display = "flex";
      const urlInput = document.getElementById("url-input");
      if (urlInput.value.trim() === "") {
        urlInput.value = "#";
      }
    } else {
      container.style.display = "none";
    }
  });
});

function loadPresetButtonSettings(element) {
  // Action select dropdown -----------------------------------------
  const urlInputContainers = document.querySelectorAll(".url-input-container");
  const actionSelect = document.getElementById("action-select");
  const actionText = document.getElementById(selectedElSettings);
  const urlInput = document.getElementById("url-input");
  const buttonGeneralTab = document.getElementById("button-general-tab");
  const buttonGeneralContent = document.getElementById("button-general-content");
  const buttonAdvancedTab = document.getElementById("button-advanced-tab");
  const buttonAdvancedContent = document.getElementById("button-advanced-content");
  buttonGeneralTab.addEventListener("click", function () {
    buttonGeneralContent.classList.add("active");
    buttonGeneralTab.classList.add("active");
    buttonAdvancedContent.classList.remove("active");
    buttonAdvancedTab.classList.remove("active");
  });
  buttonAdvancedTab.addEventListener("click", function () {
    buttonGeneralContent.classList.remove("active");
    buttonGeneralTab.classList.remove("active");
    buttonAdvancedContent.classList.add("active");
    buttonAdvancedTab.classList.add("active");
  });
  const selectText = document.getElementById(selectedElSettings); // Get the element by its ID
  //get margin padding value
  var editorComponentStyles = getComputedStyle(selectText);
  setButtonMarginTop.innerText = editorComponentStyles.getPropertyValue('margin-top');
  setButtonMarginBottom.innerText = editorComponentStyles.getPropertyValue('margin-bottom');
  setButtonPaddingTop.innerText = editorComponentStyles.getPropertyValue('padding-top');
  setButtonPaddingLeft.innerText = editorComponentStyles.getPropertyValue('padding-left');
  setButtonPaddingRight.innerText = editorComponentStyles.getPropertyValue('padding-right');
  setButtonPaddingBottom.innerText = editorComponentStyles.getPropertyValue('padding-bottom');
  // Initialize the dropdown with the current value of the href attribute
  readHref = actionText.getAttribute("href");
  if (
    readHref === "#open-popup" ||
    readHref === "#submit-form" ||
    readHref === "#"
  ) {
    actionSelect.value = readHref;
  } else {
    actionSelect.value = "#";
    urlInput.value = readHref;
  }

  urlInputContainers.forEach((container) => {
    //if doesn't equal those vals the show the field
    if (!(readHref === "#open-popup" || readHref === "#submit-form")) {
      container.style.display = "flex";
      if (urlInput.value.trim() === "") {
        urlInput.value = "#";
      }
    } else {
      container.style.display = "none";
    }
  });

  // Listen for changes in the dropdown value----------------
  actionSelect.addEventListener("change", function () {
    if (selectedElSettings) {
      const targetElement = document.getElementById(selectedElSettings);
      // Update the href attribute with the selected value from the dropdown
      targetElement.setAttribute("href", actionSelect.value);
    }
  });

  // Listen for changes in the url value---------------------
  urlInput.addEventListener("input", function () {
    if (selectedElSettings) {
      const targetElement = document.getElementById(selectedElSettings);
      // Update the href attribute with the selected value from the dropdown
      targetElement.setAttribute("href", urlInput.value);
    }
  });

  // fontSizeSlider -----------------------------------------
  const fontSizeSlider = document.getElementById("font-size-slider");
  // Get the initial font size from the selected element
  const initialFontSize = window.getComputedStyle(element).fontSize;
  // Set the slider value to the initial font size
  fontSizeSlider.value = parseFloat(initialFontSize);
  // Listen for changes in the slider value
  fontSizeSlider.addEventListener("input", function () {
    if (selectedElSettings) {
      // Apply the font size to the selected .elSettings element
      const targetElement = document.getElementById(selectedElSettings);
      const fontSize = this.value;
      targetElement.style.fontSize = fontSize + "px";
    }
  });

  // buttonTextInput -----------------------------------------
  const buttonTextInput = document.getElementById("button-text-input");
  const buttonText = document.getElementById(selectedElSettings);
  buttonTextInput.value = buttonText.textContent;
  // Listen for changes in buttonTextInput
  buttonTextInput.addEventListener("input", function () {
    if (selectedElSettings) {
      const targetElement = document.getElementById(selectedElSettings);
      targetElement.innerHTML = this.value;
    }
  });

  // font family dropdown -----------------------------------------
  const fontFamilySelect = document.getElementById("font-family-select");
  
  fontFamilySelect.value = selectText.style.fontFamily.replace(/['"]/g, "");

  // Listen for changes for font-----------------------------
  fontFamilySelect.addEventListener("change", function () {
    if (selectedElSettings) {
      const targetElement = document.getElementById(selectedElSettings);

      targetElement.style.fontFamily = fontFamilySelect.value;
    }
  });
  // Background color setting
  const buttonBackColor = document.getElementById("button-back-color");
  const buttonBackColorIcon = document.getElementById("button-back-color-icon");
  buttonBackColor.style.color = element.style.backgroundColor;
  buttonBackColorIcon.style.color = element.style.backgroundColor;
  buttonBackColor.addEventListener("input", function () {
    buttonBackColorIcon.style.color = buttonBackColor.value;
    element.style.backgroundColor = buttonBackColor.value;
    buttonOpacitySelect.value = "1.0";
  });

  // Button Text color setting
  const buttonTextColor = document.getElementById("button-text-color");
  const buttonTextColorIcon = document.getElementById("button-text-color-icon");
  buttonTextColor.style.color = element.style.color;
  buttonTextColorIcon.style.color = element.style.color;
  buttonTextColor.addEventListener("input", function () {
    buttonTextColorIcon.style.color = buttonTextColor.value;
    element.style.color = buttonTextColor.value;
  });
  const buttonOpacitySelect = document.getElementById(
    "button-opacity-select"
  );
  // Background color opacity for button Element
  buttonOpacitySelect.addEventListener("change", function () {
    let rgbColor = selectText.style.backgroundColor;
    if (selectText.style.backgroundColor.includes("rgba")) {
      rgbColor =
        selectText.style.backgroundColor.replace(/, [\d\.]+\)$/, "") +
        ")";
    }
    let convertedRGBA = rgbColor.replace(
      ")",
      `, ${buttonOpacitySelect.value})`
    );
    selectText.style.backgroundColor = convertedRGBA;
  });

  // Text Alignment for button Element
  const buttonAlignLeft = document.getElementById("button-align-left");
  const buttonAlignCenter = document.getElementById("button-align-center");
  const buttonAlignRigth = document.getElementById("button-align-right");
  const buttonAlignFull = document.getElementById("button-align-full");
  buttonAlignLeft.addEventListener('click', function() {
    selectText.parentNode.style.textAlign = "left";
    buttonAlignLeft.classList.add("selected-button");
    buttonAlignCenter.classList.remove("selected-button");
    buttonAlignRigth.classList.remove("selected-button");
    buttonAlignFull.classList.remove("selected-button");
  })
  buttonAlignCenter.addEventListener('click', function() {
    selectText.parentNode.style.textAlign = "center";
    buttonAlignLeft.classList.remove("selected-button");
    buttonAlignCenter.classList.add("selected-button");
    buttonAlignRigth.classList.remove("selected-button");
    buttonAlignFull.classList.remove("selected-button");
  })
  buttonAlignRigth.addEventListener('click', function() {
    selectText.parentNode.style.textAlign = "right";
    buttonAlignLeft.classList.remove("selected-button");
    buttonAlignCenter.classList.remove("selected-button");
    buttonAlignRigth.classList.add("selected-button");
    buttonAlignFull.classList.remove("selected-button");
  })
  buttonAlignFull.addEventListener('click', function() {
    selectText.parentNode.style.textAlign = "justify";
    buttonAlignLeft.classList.remove("selected-button");
    buttonAlignCenter.classList.remove("selected-button");
    buttonAlignRigth.classList.remove("selected-button");
    buttonAlignFull.classList.add("selected-button");
  })
  // Text Shadow
  const buttonTextShadow = document.getElementById("set-button-text-shadow");
  buttonTextShadow.addEventListener('change', function() {
    if(buttonTextShadow.value == 'No Shadow') {
      selectText.style.textShadow = 'none';
    } else if(buttonTextShadow.value == 'Light Fade') {
      selectText.style.textShadow = '1px 1px 1px rgba(0,0,0,0.2)';
    } else if(buttonTextShadow.value == 'Mid Shadow') {
      selectText.style.textShadow = '1px 1px 2px rgba(0,0,0,0.4)';
    } else if(buttonTextShadow.value == 'Strong Shadow') {
      selectText.style.textShadow = '1px 1px 3px rgba(0,0,0,0.5)';
    }
  })
  // Letter Spacing
  const buttonLetterSpacing = document.getElementById("set-button-letter-spacing");
  buttonLetterSpacing.addEventListener('change', function() {
    if(buttonLetterSpacing.value == 'Normal') {
      selectText.style.letterSpacing = '0';
    } else if(buttonLetterSpacing.value == '1px') {
      selectText.style.letterSpacing = '1px';
    } else if(buttonLetterSpacing.value == '2px') {
      selectText.style.letterSpacing = '2px';
    } else if(buttonLetterSpacing.value == '3px') {
      selectText.style.letterSpacing = '3px';
    } else if(buttonLetterSpacing.value == '-1px') {
      selectText.style.letterSpacing = '-1px';
    }
  })
  //Box Shadow
  const setBoxShadow = document.getElementById("set-button-box-shadow");
  setBoxShadow.addEventListener("change", function () {
    if (setBoxShadow.value == "No Shadow") {
      selectText.style.boxShadow = "none";
    } else if (setBoxShadow.value == "5% Drop Shadow") {
      selectText.style.boxShadow = "0 1px 3px #0000000d";
    } else if (setBoxShadow.value == "10% Drop Shadow") {
      selectText.style.boxShadow = "0 1px 5px #0000001a";
    } else if (setBoxShadow.value == "20% Drop Shadow") {
      selectText.style.boxShadow = "0 1px 5px #0003";
    } else if (setBoxShadow.value == "30% Drop Shadow") {
      selectText.style.boxShadow = "0 2px 5px 2px #0000004d";
    } else if (setBoxShadow.value == "40% Drop Shadow") {
      selectText.style.boxShadow = "0 2px 5px 2px #0006";
    } else if (setBoxShadow.value == "5% Inner Shadow") {
      selectText.style.boxShadow = "0 1px 3px #0000000d inset";
    } else if (setBoxShadow.value == "10% Inner Shadow") {
      selectText.style.boxShadow = "0 1px 5px #0000001a inset";
    } else if (setBoxShadow.value == "20% Inner Shadow") {
      selectText.style.boxShadow = "0 1px 5px #0003 inset";
    } else if (setBoxShadow.value == "30% Inner Shadow") {
      selectText.style.boxShadow = "0 2px 5px 2px #0000004d inset";
    } else if (setBoxShadow.value == "40% Inner Shadow") {
      selectText.style.boxShadow = "0 2px 5px 2px #0006 inset";
    }
  });
  // Typography Type
  const buttonTypography = document.getElementById("set-button-typography-type");
  buttonTypography.addEventListener('change', function() {
    if(buttonTypography.value == 'Headline Font') {
      selectText.style.fontFamily = 'Inter, sans-serif';
    } else if(buttonTypography.value == 'Content Font') {
      selectText.style.fontFamily = 'eufont';
    }
  })
  function settingButtonBorderMouseLeave() {
    if (settedbuttonBorderType == "No Border") {
      selectText.style.border = "none";
    } else if (settedbuttonBorderType == "full") {
      selectText.style.border = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
      
    } else if (settedbuttonBorderType == "bottom") {
      selectText.style.border = "none";
      selectText.style.borderBottom = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
    } else if (settedbuttonBorderType == "top") {
      selectText.style.border = "none";
      selectText.style.borderTop = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
    } else if (settedbuttonBorderType == "top&bototm") {
      selectText.style.border = "none";
      selectText.style.borderBottom = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
      selectText.style.borderTop = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
    }
    selectText.style.borderRadius = settedRadiusValue;
    selectText.addEventListener('mouseleave', function() {
      if (settedbuttonBorderType == "No Border") {
        selectText.style.border = "none";
      } else if (settedbuttonBorderType == "full") {
        selectText.style.border = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
      } else if (settedbuttonBorderType == "bottom") {
        selectText.style.border = "none";
        selectText.style.borderBottom = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
      } else if (settedbuttonBorderType == "top") {
        selectText.style.border = "none";
        selectText.style.borderTop = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
      } else if (settedbuttonBorderType == "top&bototm") {
        selectText.style.border = "none";
        selectText.style.borderBottom = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
        selectText.style.borderTop = `${settedbuttonBorderWidth} ${settedbuttonBorderStyle} ${settedbuttonBorderColor}`;
      }
    })
  }
  //Border select
  var settedbuttonBorderType;
  const borderSelect = document.getElementById("setting-button-border-select");
  borderSelect.addEventListener("change", function () {
    settedbuttonBorderType = borderSelect.value;
    settingButtonBorderMouseLeave();
    if (borderSelect.value != "No Border") {
      document.getElementById("button-border-setting").style.display = "block";
    } else {
      document.getElementById("button-border-setting").style.display = "none";
    }
  });
  //set border style
  var settedbuttonBorderStyle = 'solid';
  const borderStyle = document.getElementById("setting-button-border-style");
  borderStyle.addEventListener("change", function () {
    settedbuttonBorderStyle = borderStyle.value;
    settingButtonBorderMouseLeave();
  });
  //set border width
  var settedbuttonBorderWidth = '3px';
  const borderWidth = document.getElementById("setting-button-border-width");
  borderWidth.addEventListener("change", function () {
    settedbuttonBorderWidth = borderWidth.value;
    settingButtonBorderMouseLeave();
  });
  //set border color
  var settedbuttonBorderColor = '#333';
  const borderColor = document.getElementById("button-border-color");
  const borderColorIcon = document.getElementById("button-border-color-icon");
  borderColor.style.color = selectText.style.borderColor;
  borderColorIcon.style.color = selectText.style.borderColor;
  borderColor.addEventListener("input", function () {
    borderColorIcon.style.color = borderColor.value;
    selectText.style.borderColor = borderColor.value;
    settedbuttonBorderColor = borderColor.value;
    
  });
  //set border radius
  var settedRadiusValue = '0px';
  const borderRadius = document.getElementById("setting-button-border-radius");
  borderRadius.addEventListener("change", function () {
    settedRadiusValue = borderRadius.value;
    settingButtonBorderMouseLeave();
  });
  //set border edge
  const borderEdge = document.getElementById("setting-button-edge");
  borderEdge.addEventListener("change", function () {
    if (borderEdge.value == "All Edges") {
        selectText.style.borderRadius = settedRadiusValue;
    } else if (borderEdge.value == "Top Only Edges") {
        selectText.style.borderRadius = `${settedRadiusValue} ${settedRadiusValue} 0 0`;
    } else if (borderEdge.value == "Bottom Only Edges") {
        selectText.style.borderRadius = `0 0 ${settedRadiusValue} ${settedRadiusValue}`;
    }
  });
  //set text transform
  const textTransform = document.getElementById("set-button-text-transform");
  textTransform.addEventListener("change", function() {
    if(textTransform.value == "Normal") {
      selectText.style.textTransform = "none";
    } else if(textTransform.value == "Uppercase") {
      selectText.style.textTransform = "uppercase";
    } else if(textTransform.value == "Lowercase") {
      selectText.style.textTransform = "lowercase";
    } else if(textTransform.value == "Capitalize") {
      selectText.style.textTransform = "capitalize";
    } 
  })
  //set text width
  const textWidth = document.getElementById("set-button-text-width");
  textWidth.addEventListener("change", function() {
    if(textWidth.value == "Fluid") {
      selectText.style.width = "auto";
    } else if(textWidth.value == "Full Width") {
      selectText.style.width = "100%";
    } 
  })
}
// Add event listener to the search panel for elements input
document.querySelector(".search-panel").addEventListener("input", function () {
  const searchKeyword = this.value.toLowerCase();
  const elementPanels = document.querySelectorAll(".element-panel");

  // Loop through each element panel and check if it matches the search keyword
  elementPanels.forEach(function (panel) {
    const panelText = panel.textContent.toLowerCase();
    if (panelText.includes(searchKeyword)) {
      panel.style.display = "flex"; // Show the element panel
    } else {
      panel.style.display = "none"; // Hide the element panel
    }
  });
});

// Close Settings Panel
const buttonSettingClose = document.getElementById("button-setting-close");
buttonSettingClose.addEventListener("click", function () {
  closeSidebar();
});

// Settings for Green Section Container
let selectedGreenSection = null;
function greenGearElement(id) {
  selectedGreenSection = id;
  if (setSectionPopup.style.right === "0px") {
    setSectionPopup.style.right = "-350px"; // Slide out the popup
  } else {
    setSectionPopup.style.right = "0px"; // Slide in the popup
  }
  loadPresetGreenSettings(id);
}
const greenSettingClose = document.getElementById("popup4-close");
greenSettingClose.addEventListener("click", function () {
  selectedGreenSection = null;
  setSectionPopup.style.right = "-350px"; // Slide out the popup
});
function loadPresetGreenSettings(id) {
  const editorComponent = document.getElementById(id);
  //get margin padding value
  let editorComponentStyles = getComputedStyle(editorComponent);
  setGreenMarginTop.innerText = editorComponentStyles.getPropertyValue('margin-top');
  setGreenMarginBottom.innerText = editorComponentStyles.getPropertyValue('margin-bottom');
  setGreenPaddingTop.innerText = editorComponentStyles.getPropertyValue('padding-top');
  setGreenPaddingLeft.innerText = editorComponentStyles.getPropertyValue('padding-left');
  setGreenPaddingRight.innerText = editorComponentStyles.getPropertyValue('padding-right');
  setGreenPaddingBottom.innerText = editorComponentStyles.getPropertyValue('padding-bottom');
  // Background color setting for Green Section
  const greenBackColor = document.getElementById("green-back-color");
  const greenBackColorIcon = document.getElementById("green-back-color-icon");
  greenBackColor.style.color = editorComponent.style.backgroundColor;
  greenBackColorIcon.style.color = editorComponent.style.backgroundColor;
  greenBackColor.addEventListener("input", function () {
    greenBackColorIcon.style.color = greenBackColor.value;
    const editorComponent = document.getElementById(selectedGreenSection);
    editorComponent.style.backgroundColor = greenBackColor.value;
  });

  //Setting Background Image
  const backgroundImage = document.getElementById("input-green-image");
  backgroundImage.addEventListener("input", function () {
    editorComponent.style.backgroundImage =
      'url("' + backgroundImage.value + '")';
  });
  const imageRepeatOption = document.getElementById(
    "select-green-image-repeat-options"
  );
  imageRepeatOption.addEventListener("change", function () {
    if (imageRepeatOption.value == "No Repeat") {
      editorComponent.style.backgroundRepeat = "no-repeat";
    } else if (imageRepeatOption.value == "Repeat") {
      editorComponent.style.backgroundRepeat = "repeat";
    } else if (imageRepeatOption.value == "Repeat Horizontally") {
      editorComponent.style.backgroundRepeat = "repeat-x";
    } else if (imageRepeatOption.value == "Repeat Vertically") {
      editorComponent.style.backgroundRepeat = "repeat-y";
    }
  });
  const imageSizeOption = document.getElementById(
    "select-green-image-size-options"
  );
  imageSizeOption.addEventListener("change", function () {
    if (imageSizeOption.value == "Full Center") {
      editorComponent.style.backgroundSize = "auto";
    } else if (imageSizeOption.value == "Full 100% Width") {
      editorComponent.style.backgroundSize = "100% auto";
    } else if (imageSizeOption.value == "Full 100% Width & Height") {
      editorComponent.style.backgroundSize = "100% 100%";
    } else if (imageSizeOption.value == "Contain") {
      editorComponent.style.backgroundSize = "contain";
    }
  });
  //Box Shadow
  const setBoxShadow = document.getElementById("set-green-box-shadow");
  setBoxShadow.addEventListener("change", function () {
    if (setBoxShadow.value == "No Shadow") {
      editorComponent.style.boxShadow = "none";
    } else if (setBoxShadow.value == "5% Drop Shadow") {
      editorComponent.style.boxShadow = "0 1px 3px #0000000d";
    } else if (setBoxShadow.value == "10% Drop Shadow") {
      editorComponent.style.boxShadow = "0 1px 5px #0000001a";
    } else if (setBoxShadow.value == "20% Drop Shadow") {
      editorComponent.style.boxShadow = "0 1px 5px #0003";
    } else if (setBoxShadow.value == "30% Drop Shadow") {
      editorComponent.style.boxShadow = "0 2px 5px 2px #0000004d";
    } else if (setBoxShadow.value == "40% Drop Shadow") {
      editorComponent.style.boxShadow = "0 2px 5px 2px #0006";
    } else if (setBoxShadow.value == "5% Inner Shadow") {
      editorComponent.style.boxShadow = "0 1px 3px #0000000d inset";
    } else if (setBoxShadow.value == "10% Inner Shadow") {
      editorComponent.style.boxShadow = "0 1px 5px #0000001a inset";
    } else if (setBoxShadow.value == "20% Inner Shadow") {
      editorComponent.style.boxShadow = "0 1px 5px #0003 inset";
    } else if (setBoxShadow.value == "30% Inner Shadow") {
      editorComponent.style.boxShadow = "0 2px 5px 2px #0000004d inset";
    } else if (setBoxShadow.value == "40% Inner Shadow") {
      editorComponent.style.boxShadow = "0 2px 5px 2px #0006 inset";
    }
  });
  function settingSectionBorderMouseLeave() {
    if (settedSectionBorderType == "No Border") {
      editorComponent.style.border = "none";
    } else if (settedSectionBorderType == "full") {
      editorComponent.style.border = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
      
    } else if (settedSectionBorderType == "bottom") {
      editorComponent.style.border = "none";
      editorComponent.style.borderBottom = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
    } else if (settedSectionBorderType == "top") {
      editorComponent.style.border = "none";
      editorComponent.style.borderTop = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
    } else if (settedSectionBorderType == "top&bototm") {
      editorComponent.style.border = "none";
      editorComponent.style.borderBottom = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
      editorComponent.style.borderTop = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
    }
    editorComponent.style.borderRadius = settedRadiusValue;
    editorComponent.addEventListener('mouseleave', function() {
      if (settedSectionBorderType == "No Border") {
        editorComponent.style.border = "none";
      } else if (settedSectionBorderType == "full") {
        editorComponent.style.border = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
      } else if (settedSectionBorderType == "bottom") {
        editorComponent.style.border = "none";
        editorComponent.style.borderBottom = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
      } else if (settedSectionBorderType == "top") {
        editorComponent.style.border = "none";
        editorComponent.style.borderTop = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
      } else if (settedSectionBorderType == "top&bototm") {
        editorComponent.style.border = "none";
        editorComponent.style.borderBottom = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
        editorComponent.style.borderTop = `${settedSectionBorderWidth} ${settedSectionBorderStyle} ${settedSectionBorderColor}`;
      }
    })
  }
  //Border select
  var settedSectionBorderType;
  const borderSelect = document.getElementById("setting-section-border-select");
  borderSelect.addEventListener("change", function () {
    settedSectionBorderType = borderSelect.value;
    settingSectionBorderMouseLeave();
    if (borderSelect.value != "No Border") {
      document.getElementById("green-border-setting").style.display = "block";
    } else {
      document.getElementById("green-border-setting").style.display = "none";
    }
  });
  //set border style
  var settedSectionBorderStyle = 'solid';
  const borderStyle = document.getElementById("setting-section-border-style");
  borderStyle.addEventListener("change", function () {
    settedSectionBorderStyle = borderStyle.value;
    settingSectionBorderMouseLeave();
  });
  //set border width
  var settedSectionBorderWidth = '3px';
  const borderWidth = document.getElementById("setting-section-border-width");
  borderWidth.addEventListener("change", function () {
    settedSectionBorderWidth = borderWidth.value;
    settingSectionBorderMouseLeave();
  });
  //set border color
  var settedSectionBorderColor = '#333';
  const borderColor = document.getElementById("section-border-color");
  const borderColorIcon = document.getElementById("section-border-color-icon");
  borderColor.style.color = editorComponent.style.borderColor;
  borderColorIcon.style.color = editorComponent.style.borderColor;
  borderColor.addEventListener("input", function () {
    borderColorIcon.style.color = borderColor.value;
    editorComponent.style.borderColor = borderColor.value;
    settedSectionBorderColor = borderColor.value;
    
  });
  //set border radius
  var settedRadiusValue = '0px';
  const borderRadius = document.getElementById("setting-section-border-radius");
  borderRadius.addEventListener("change", function () {
    settedRadiusValue = borderRadius.value;
    settingSectionBorderMouseLeave();
  });
  //set border edge
  const borderEdge = document.getElementById("setting-section-edge");
  borderEdge.addEventListener("change", function () {
    if (borderEdge.value == "All Edges") {
        editorComponent.style.borderRadius = settedRadiusValue;
    } else if (borderEdge.value == "Top Only Edges") {
        editorComponent.style.borderRadius = `${settedRadiusValue} ${settedRadiusValue} 0 0`;
    } else if (borderEdge.value == "Bottom Only Edges") {
        editorComponent.style.borderRadius = `0 0 ${settedRadiusValue} ${settedRadiusValue}`;
    }
  });
  //set section width
  const sectionWidth = document.getElementById("setting-section-width");
  sectionWidth.addEventListener("change", function () {
    if (sectionWidth.value == "full") {
        editorComponent.style.width = "100%";
    } else if (sectionWidth.value == "wide") {
      editorComponent.style.width = "80%";
    } else if (sectionWidth.value == "mid-wide") {
      editorComponent.style.width = "60%";
    } else if (sectionWidth.value == "small") {
      editorComponent.style.width = "50%";
    }
  });
}

// General and Advanced tab panel for Green Section
const greenGeneralTab = document.getElementById("green-general-tab");
const greenGeneralContent = document.getElementById("green-general-content");
const greenAdvancedTab = document.getElementById("green-advanced-tab");
const greenAdvancedContent = document.getElementById("green-advanced-content");
greenGeneralTab.addEventListener("click", function () {
  greenGeneralContent.classList.add("active");
  greenGeneralTab.classList.add("active");
  greenAdvancedContent.classList.remove("active");
  greenAdvancedTab.classList.remove("active");
});
greenAdvancedTab.addEventListener("click", function () {
  greenGeneralContent.classList.remove("active");
  greenGeneralTab.classList.remove("active");
  greenAdvancedContent.classList.add("active");
  greenAdvancedTab.classList.add("active");
});
// Settings for Blue Section Container
let selectedBlueSection = null;
function blueGearElement(id) {
  selectedBlueSection = id;
  if (setColumnPopup.style.right === "0px") {
    setColumnPopup.style.right = "-350px"; // Slide out the popup
  } else {
    setColumnPopup.style.right = "0px"; // Slide in the popup
  }
  loadPresetBlueSettings(id);
}
const blueSettingClose = document.getElementById("popup5-close");
blueSettingClose.addEventListener("click", function () {
  selectedBlueSection = null;
  setColumnPopup.style.right = "-350px"; // Slide out the popup
});

function loadPresetBlueSettings(id) {
  const blueComponent = document.getElementById(id);
  //get margin padding value
  let editorComponentStyles = getComputedStyle(blueComponent);
  setBlueMarginTop.innerText = editorComponentStyles.getPropertyValue('margin-top');
  setBlueMarginBottom.innerText = editorComponentStyles.getPropertyValue('margin-bottom');
  setBluePaddingTop.innerText = editorComponentStyles.getPropertyValue('padding-top');
  setBluePaddingLeft.innerText = editorComponentStyles.getPropertyValue('padding-left');
  setBluePaddingRight.innerText = editorComponentStyles.getPropertyValue('padding-right');
  setBluePaddingBottom.innerText = editorComponentStyles.getPropertyValue('padding-bottom');
  // Background color setting for Blue Section
  const blueBackColor = document.getElementById("blue-back-color");
  const blueBackColorIcon = document.getElementById("blue-back-color-icon");
  blueBackColor.style.color = blueComponent.style.backgroundColor;
  blueBackColorIcon.style.color = blueComponent.style.backgroundColor;
  blueBackColor.addEventListener("input", function () {
    blueBackColorIcon.style.color = blueBackColor.value;
    const blueComponent = document.getElementById(selectedBlueSection);
    blueComponent.style.backgroundColor = blueBackColor.value;
  });

  // Alginment for blue Section
  const alignSelect = document.getElementById("blue-align-select");
  if (blueComponent.style.margin === "auto") {
    alignSelect.value = "center";
  } else if (blueComponent.style.marginLeft === "auto") {
    alignSelect.value = "right";
  } else {
    alignSelect.value = "left";
  }
  alignSelect.addEventListener("change", function () {
    const selectedAlignment = alignSelect.value;
    const blueComponent = document.getElementById(selectedBlueSection);
    if (selectedAlignment === "center") {
      blueComponent.style.margin = "auto";
    } else if (selectedAlignment === "left") {
      blueComponent.style.margin = "0";
    } else if (selectedAlignment === "right") {
      blueComponent.style.margin = "0";
      blueComponent.style.marginLeft = "auto";
    }
  });

  // Width range change for blue Section
  const blueWidthSlider = document.getElementById("blue-width-slider");
  const blueWidthValue = document.getElementById("blue-width-value");
  if (blueComponent.style.width) {
    blueWidthSlider.value = parseInt(blueComponent.style.width);
    blueWidthValue.value = parseInt(blueComponent.style.width);
  } else {
    blueWidthSlider.value = 100;
    blueWidthValue.value = 100;
  }
  blueWidthSlider.addEventListener("input", function () {
    blueWidthValue.value = blueWidthSlider.value;
    const blueComponent = document.getElementById(selectedBlueSection);
    blueComponent.style.width = `${blueWidthSlider.value}%`;
  });
  blueWidthValue.addEventListener("change", function () {
    let parsedValue = parseInt(blueWidthValue.value);
    if (parsedValue >= 0 && parsedValue <= 100) {
      blueWidthSlider.value = parsedValue;
    }
    const blueComponent = document.getElementById(selectedBlueSection);
    blueComponent.style.width = `${parsedValue}%`;
  });
  //Box Shadow
  const setBoxShadow = document.getElementById("set-blue-box-shadow");
  setBoxShadow.addEventListener("change", function () {
    if (setBoxShadow.value == "No Shadow") {
      blueComponent.style.boxShadow = "none";
    } else if (setBoxShadow.value == "5% Drop Shadow") {
      blueComponent.style.boxShadow = "0 1px 3px #0000000d";
    } else if (setBoxShadow.value == "10% Drop Shadow") {
      blueComponent.style.boxShadow = "0 1px 5px #0000001a";
    } else if (setBoxShadow.value == "20% Drop Shadow") {
      blueComponent.style.boxShadow = "0 1px 5px #0003";
    } else if (setBoxShadow.value == "30% Drop Shadow") {
      blueComponent.style.boxShadow = "0 2px 5px 2px #0000004d";
    } else if (setBoxShadow.value == "40% Drop Shadow") {
      blueComponent.style.boxShadow = "0 2px 5px 2px #0006";
    } else if (setBoxShadow.value == "5% Inner Shadow") {
      blueComponent.style.boxShadow = "0 1px 3px #0000000d inset";
    } else if (setBoxShadow.value == "10% Inner Shadow") {
      blueComponent.style.boxShadow = "0 1px 5px #0000001a inset";
    } else if (setBoxShadow.value == "20% Inner Shadow") {
      blueComponent.style.boxShadow = "0 1px 5px #0003 inset";
    } else if (setBoxShadow.value == "30% Inner Shadow") {
      blueComponent.style.boxShadow = "0 2px 5px 2px #0000004d inset";
    } else if (setBoxShadow.value == "40% Inner Shadow") {
      blueComponent.style.boxShadow = "0 2px 5px 2px #0006 inset";
    }
  });
  //Setting Background Image
  const backgroundImage = document.getElementById("input-blue-image");
  backgroundImage.addEventListener("input", function () {
    blueComponent.style.backgroundImage =
      'url("' + backgroundImage.value + '")';
  });
  const imageRepeatOption = document.getElementById(
    "select-blue-image-repeat-options"
  );
  imageRepeatOption.addEventListener("change", function () {
    if (imageRepeatOption.value == "No Repeat") {
      blueComponent.style.backgroundRepeat = "no-repeat";
    } else if (imageRepeatOption.value == "Repeat") {
      blueComponent.style.backgroundRepeat = "repeat";
    } else if (imageRepeatOption.value == "Repeat Horizontally") {
      blueComponent.style.backgroundRepeat = "repeat-x";
    } else if (imageRepeatOption.value == "Repeat Vertically") {
      blueComponent.style.backgroundRepeat = "repeat-y";
    }
  });
  const imageSizeOption = document.getElementById(
    "select-blue-image-size-options"
  );
  imageSizeOption.addEventListener("change", function () {
    if (imageSizeOption.value == "Full Center") {
      blueComponent.style.backgroundSize = "auto";
    } else if (imageSizeOption.value == "Full 100% Width") {
      blueComponent.style.backgroundSize = "100% auto";
    } else if (imageSizeOption.value == "Full 100% Width & Height") {
      blueComponent.style.backgroundSize = "100% 100%";
    } else if (imageSizeOption.value == "Contain") {
      blueComponent.style.backgroundSize = "contain";
    }
  });
  function settingColumnBorderMouseLeave() {
    if (settedColumnBorderType == "No Border") {
      blueComponent.style.border = "none";
    } else if (settedColumnBorderType == "full") {
      blueComponent.style.border = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
      
    } else if (settedColumnBorderType == "bottom") {
      blueComponent.style.border = "none";
      blueComponent.style.borderBottom = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
    } else if (settedColumnBorderType == "top") {
      blueComponent.style.border = "none";
      blueComponent.style.borderTop = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
    } else if (settedColumnBorderType == "top&bototm") {
      blueComponent.style.border = "none";
      blueComponent.style.borderBottom = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
      blueComponent.style.borderTop = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
    }
    blueComponent.style.borderRadius = settedRadiusValue;
    blueComponent.addEventListener('mouseleave', function() {
      if (settedColumnBorderType == "No Border") {
        blueComponent.style.border = "none";
      } else if (settedColumnBorderType == "full") {
        blueComponent.style.border = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
      } else if (settedColumnBorderType == "bottom") {
        blueComponent.style.border = "none";
        blueComponent.style.borderBottom = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
      } else if (settedColumnBorderType == "top") {
        blueComponent.style.border = "none";
        blueComponent.style.borderTop = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
      } else if (settedColumnBorderType == "top&bototm") {
        blueComponent.style.border = "none";
        blueComponent.style.borderBottom = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
        blueComponent.style.borderTop = `${settedColumnBorderWidth} ${settedColumnBorderStyle} ${settedColumnBorderColor}`;
      }
    })
  }
  
  //Border select
  var settedColumnBorderType;
  const borderSelect = document.getElementById("setting-column-border-select");
  borderSelect.addEventListener("change", function () {
    settedColumnBorderType = borderSelect.value;
    settingColumnBorderMouseLeave();
    if (borderSelect.value != "No Border") {
      document.getElementById("blue-border-setting").style.display = "block";
    } else {
      document.getElementById("blue-border-setting").style.display = "none";
    }
  });
  //set border style
  var settedColumnBorderStyle = 'solid';
  const borderStyle = document.getElementById("setting-column-border-style");
  borderStyle.addEventListener("change", function () {
    settedColumnBorderStyle = borderStyle.value;
    settingColumnBorderMouseLeave();
  });
  //set border width
  var settedColumnBorderWidth = '3px';
  const borderWidth = document.getElementById("setting-column-border-width");
  borderWidth.addEventListener("change", function () {
    settedColumnBorderWidth = borderWidth.value;
    settingColumnBorderMouseLeave();
  });
  //set border color
  var settedColumnBorderColor = '#333';
  const borderColor = document.getElementById("column-border-color");
  const borderColorIcon = document.getElementById("column-border-color-icon");
  borderColor.style.color = blueComponent.style.borderColor;
  borderColorIcon.style.color = blueComponent.style.borderColor;
  borderColor.addEventListener("input", function () {
    borderColorIcon.style.color = borderColor.value;
    blueComponent.style.borderColor = borderColor.value;
    settedColumnBorderColor = borderColor.value;
    
  });
  //set border radius
  var settedRadiusValue = '0px';
  const borderRadius = document.getElementById("setting-column-border-radius");
  borderRadius.addEventListener("change", function () {
    settedRadiusValue = borderRadius.value;
    settingColumnBorderMouseLeave();
  });
  //set border edge
  const borderEdge = document.getElementById("setting-column-edge");
  borderEdge.addEventListener("change", function () {
    if (borderEdge.value == "All Edges") {
        blueComponent.style.borderRadius = settedRadiusValue;
    } else if (borderEdge.value == "Top Only Edges") {
        blueComponent.style.borderRadius = `${settedRadiusValue} ${settedRadiusValue} 0 0`;
    } else if (borderEdge.value == "Bottom Only Edges") {
        blueComponent.style.borderRadius = `0 0 ${settedRadiusValue} ${settedRadiusValue}`;
    }
  });
}

// General and Advanced tab panel for Blue Section
const blueGeneralTab = document.getElementById("blue-general-tab");
const blueGeneralContent = document.getElementById("blue-general-content");
const blueAdvancedTab = document.getElementById("blue-advanced-tab");
const blueAdvancedContent = document.getElementById("blue-advanced-content");
blueGeneralTab.addEventListener("click", function () {
  blueGeneralContent.classList.add("active");
  blueGeneralTab.classList.add("active");
  blueAdvancedContent.classList.remove("active");
  blueAdvancedTab.classList.remove("active");
});
blueAdvancedTab.addEventListener("click", function () {
  blueGeneralContent.classList.remove("active");
  blueGeneralTab.classList.remove("active");
  blueAdvancedContent.classList.add("active");
  blueAdvancedTab.classList.add("active");
});

// General and Advanced tab panel for Orange Section
const orangeGeneralTab = document.getElementById("orange-general-tab");
const orangeGeneralContent = document.getElementById("orange-general-content");
const orangeAdvancedTab = document.getElementById("orange-advanced-tab");
const orangeAdvancedContent = document.getElementById(
  "orange-advanced-content"
);
orangeGeneralTab.addEventListener("click", function () {
  orangeGeneralContent.classList.add("active");
  orangeGeneralTab.classList.add("active");
  orangeAdvancedContent.classList.remove("active");
  orangeAdvancedTab.classList.remove("active");
});
orangeAdvancedTab.addEventListener("click", function () {
  orangeGeneralContent.classList.remove("active");
  orangeGeneralTab.classList.remove("active");
  orangeAdvancedContent.classList.add("active");
  orangeAdvancedTab.classList.add("active");
});

// Settings for headline element
let selectedHeadlineElement = null;
let selectedHeadlineContainer = null;
function headlineGearElement(parentWrapper, parentType) {
  selectedHeadlineElement = parentWrapper.firstChild.id;
  selectedHeadlineContainer = parentWrapper.id;
  const titleComponent = document.getElementById("orange-title");
  titleComponent.textContent =
    parentType.charAt(0).toUpperCase() + parentType.slice(1);
  if (setHeadlinePopup.style.right === "0px") {
    setHeadlinePopup.style.right = "-350px"; // Slide out the popup
  } else {
    setHeadlinePopup.style.right = "0px"; // Slide in the popup
  }
  loadPresetHeadlineSettings(parentWrapper);
}
const headlineSettingClose = document.getElementById("headline-close");
headlineSettingClose.addEventListener("click", function () {
  selectedHeadlineElement = null;
  selectedHeadlineContainer = null;
  setHeadlinePopup.style.right = "-350px"; // Slide out the popup
});
function loadPresetHeadlineSettings(parentWrapper) {
  const headlineContainer = document.getElementById(parentWrapper.id);
  const headlineComponent = document.getElementById(
    parentWrapper.firstChild.id
  );
  const headlineOpacitySelect = document.getElementById(
    "headline-opacity-select"
  );
    //get margin padding value
    let editorComponentStyles = getComputedStyle(headlineContainer);
    setOrangeMarginTop.innerText = editorComponentStyles.getPropertyValue('margin-top');
    setOrangeMarginBottom.innerText = editorComponentStyles.getPropertyValue('margin-bottom');
    setOrangePaddingTop.innerText = editorComponentStyles.getPropertyValue('padding-top');
    setOrangePaddingLeft.innerText = editorComponentStyles.getPropertyValue('padding-left');
    setOrangePaddingRight.innerText = editorComponentStyles.getPropertyValue('padding-right');
    setOrangePaddingBottom.innerText = editorComponentStyles.getPropertyValue('padding-bottom');
  // Background color setting for Headline Element
  const headlineBackColor = document.getElementById("headline-back-color");
  const headlineBackColorIcon = document.getElementById(
    "headline-back-color-icon"
  );
  headlineBackColor.style.color = headlineContainer.style.backgroundColor;
  headlineBackColorIcon.style.color = headlineContainer.style.backgroundColor;
  headlineBackColor.addEventListener("input", function () {
    headlineBackColorIcon.style.color = headlineBackColor.value;
    const headlineContainer = document.getElementById(
      selectedHeadlineContainer
    );
    headlineContainer.style.backgroundColor = headlineBackColor.value;
    headlineOpacitySelect.value = "1.0";
  });

  // Background color opacity for Headline Element
  headlineOpacitySelect.addEventListener("change", function () {
    const headlineContainer = document.getElementById(parentWrapper.id);
    let rgbColor = headlineContainer.style.backgroundColor;
    if (headlineContainer.style.backgroundColor.includes("rgba")) {
      rgbColor =
        headlineContainer.style.backgroundColor.replace(/, [\d\.]+\)$/, "") +
        ")";
    }
    let convertedRGBA = rgbColor.replace(
      ")",
      `, ${headlineOpacitySelect.value})`
    );
    headlineContainer.style.backgroundColor = convertedRGBA;
  });

  // Text Alignment for Headline Element
  const headlineAlignButtons = document.querySelectorAll(".align-button");
  headlineAlignButtons.forEach(function (button) {
    button.addEventListener("click", function () {
      const headlineComponent = document.getElementById(
        selectedHeadlineElement
      );

      headlineComponent.style.textAlign = "";
      headlineAlignButtons.forEach(function (btn) {
        btn.classList.remove("selected-button");
      });
      if (this.querySelector("i").classList.contains("bi-text-left")) {
        headlineComponent.style.textAlign = "left";
        this.classList.add("selected-button");
      } else if (this.querySelector("i").classList.contains("bi-text-center")) {
        headlineComponent.style.textAlign = "center";
        this.classList.add("selected-button");
      } else if (this.querySelector("i").classList.contains("bi-text-right")) {
        headlineComponent.style.textAlign = "right";
        this.classList.add("selected-button");
      } else if (this.querySelector("i").classList.contains("bi-justify")) {
        headlineComponent.style.textAlign = "justify";
        this.classList.add("selected-button");
      }
    });
  });

  // Font size setting for Headline Element
  const headlineFontSlider = document.getElementById("headline-font-slider");
  const headlineFontValue = document.getElementById("headline-font-value");
  headlineFontSlider.value = parseInt(headlineComponent.style.fontSize);
  headlineFontValue.value = parseInt(headlineComponent.style.fontSize);
  headlineFontSlider.addEventListener("input", function () {
    headlineFontValue.value = headlineFontSlider.value;
    headlineComponent.style.fontSize = `${headlineFontSlider.value}px`;
    headlineComponent.querySelectorAll("*").forEach(child => {
      child.style.fontSize = `${headlineFontSlider.value}px`;
  });
  });
  // var allContainers = headlineComponent.querySelectorAll("*");
  headlineFontValue.addEventListener("change", function () {
    let parsedValue = parseInt(headlineFontValue.value);
    if (parsedValue >= 0 && parsedValue <= 100) {
      headlineFontSlider.value = parsedValue;
      headlineComponent.style.fontSize = `${parsedValue}px`;
      headlineComponent.querySelectorAll("*").forEach(child => {
          child.style.fontSize = `${parsedValue}px`;
      });
    }
  });
  

  // Text color setting for Headline Element
  const headlineColor = document.getElementById("headline-color");
  const headlineColorIcon = document.getElementById("headline-color-icon");
  headlineColor.style.color = headlineComponent.style.color;
  headlineColorIcon.style.color = headlineComponent.style.color;
  headlineColor.addEventListener("input", function () {
    headlineColorIcon.style.color = headlineColor.value;
    const headlineComponent = document.getElementById(selectedHeadlineElement);
    headlineComponent.style.color = headlineColor.value;
  });
  // Text Shadow
  const headlineTextShadow = document.getElementById("set-headline-text-shadow");
  headlineTextShadow.addEventListener('change', function() {
    if(headlineTextShadow.value == 'No Shadow') {
      headlineComponent.style.textShadow = 'none';
    } else if(headlineTextShadow.value == 'Light Fade') {
      headlineComponent.style.textShadow = '1px 1px 1px rgba(0,0,0,0.2)';
    } else if(headlineTextShadow.value == 'Mid Shadow') {
      headlineComponent.style.textShadow = '1px 1px 2px rgba(0,0,0,0.4)';
    } else if(headlineTextShadow.value == 'Strong Shadow') {
      headlineComponent.style.textShadow = '1px 1px 3px rgba(0,0,0,0.5)';
    }
  })
  // Letter Spacing
  const headlineLetterSpacing = document.getElementById("set-headline-letter-spacing");
  headlineLetterSpacing.addEventListener('change', function() {
    if(headlineLetterSpacing.value == 'Normal') {
      headlineComponent.style.letterSpacing = '0';
    } else if(headlineLetterSpacing.value == '1px') {
      headlineComponent.style.letterSpacing = '1px';
    } else if(headlineLetterSpacing.value == '2px') {
      headlineComponent.style.letterSpacing = '2px';
    } else if(headlineLetterSpacing.value == '3px') {
      headlineComponent.style.letterSpacing = '3px';
    } else if(headlineLetterSpacing.value == '-1px') {
      headlineComponent.style.letterSpacing = '-1px';
    }
  })
  //Box Shadow
  const setBoxShadow = document.getElementById("set-headline-box-shadow");
  setBoxShadow.addEventListener("change", function () {
    if (setBoxShadow.value == "No Shadow") {
      headlineContainer.style.boxShadow = "none";
    } else if (setBoxShadow.value == "5% Drop Shadow") {
      headlineContainer.style.boxShadow = "0 1px 3px #0000000d";
    } else if (setBoxShadow.value == "10% Drop Shadow") {
      headlineContainer.style.boxShadow = "0 1px 5px #0000001a";
    } else if (setBoxShadow.value == "20% Drop Shadow") {
      headlineContainer.style.boxShadow = "0 1px 5px #0003";
    } else if (setBoxShadow.value == "30% Drop Shadow") {
      headlineContainer.style.boxShadow = "0 2px 5px 2px #0000004d";
    } else if (setBoxShadow.value == "40% Drop Shadow") {
      headlineContainer.style.boxShadow = "0 2px 5px 2px #0006";
    } else if (setBoxShadow.value == "5% Inner Shadow") {
      headlineContainer.style.boxShadow = "0 1px 3px #0000000d inset";
    } else if (setBoxShadow.value == "10% Inner Shadow") {
      headlineContainer.style.boxShadow = "0 1px 5px #0000001a inset";
    } else if (setBoxShadow.value == "20% Inner Shadow") {
      headlineContainer.style.boxShadow = "0 1px 5px #0003 inset";
    } else if (setBoxShadow.value == "30% Inner Shadow") {
      headlineContainer.style.boxShadow = "0 2px 5px 2px #0000004d inset";
    } else if (setBoxShadow.value == "40% Inner Shadow") {
      headlineContainer.style.boxShadow = "0 2px 5px 2px #0006 inset";
    }
  });
  // Typography Type
  const headlineTypography = document.getElementById("set-headline-typography-type");
  headlineTypography.addEventListener('change', function() {
    if(headlineTypography.value == 'Headline Font') {
      headlineComponent.style.fontFamily = 'Inter, sans-serif';
    } else if(headlineTypography.value == 'Content Font') {
      headlineComponent.style.fontFamily = 'eufont';
    }
  })
  // Bold Text Color
  const headlineBoldColor = document.getElementById("headline-bold-color");
  const headlineBoldColorIcon = document.getElementById("headline-bold-color-icon");
  var boldTags = headlineComponent.querySelectorAll('b');
  headlineBoldColor.addEventListener("input", function () {
    headlineBoldColorIcon.style.color = headlineBoldColor.value;
    boldTags.forEach(function(tag) {
      tag.style.color = headlineBoldColor.value;
    });
  });
  // Italic Text Color
  const headlineItalicColor = document.getElementById("headline-italic-color");
  const headlineItalicColorIcon = document.getElementById("headline-italic-color-icon");
  var IatalicTags = headlineComponent.querySelectorAll('i');
  headlineItalicColor.addEventListener("input", function () {
    headlineItalicColorIcon.style.color = headlineItalicColor.value;
    IatalicTags.forEach(function(tag) {
      tag.style.color = headlineItalicColor.value;
    });
  });
  // Underline Text Color
  const headlineUnderlineColor = document.getElementById("headline-underline-color");
  const headlineUnderlineColorIcon = document.getElementById("headline-underline-color-icon");
  var UnderlineTags = headlineComponent.querySelectorAll('u');
  headlineUnderlineColor.addEventListener("input", function () {
    headlineUnderlineColorIcon.style.color = headlineUnderlineColor.value;
    UnderlineTags.forEach(function(tag) {
      tag.style.color = headlineUnderlineColor.value;
    });
  });
  // Link Text Color
  const headlineLinkColor = document.getElementById("headline-link-color");
  const headlineLinkColorIcon = document.getElementById("headline-link-color-icon");
  var LinkTags = headlineComponent.querySelectorAll('a');
  headlineLinkColor.addEventListener("input", function () {
    headlineLinkColorIcon.style.color = headlineLinkColor.value;
    LinkTags.forEach(function(tag) {
      tag.style.color = headlineLinkColor.value;
    });
  });
  function settingHeadlineBorderMouseLeave() {
    if (settedHeadlineBorderType == "No Border") {
      headlineContainer.style.border = "none";
    } else if (settedHeadlineBorderType == "full") {
      headlineContainer.style.border = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
      
    } else if (settedHeadlineBorderType == "bottom") {
      headlineContainer.style.border = "none";
      headlineContainer.style.borderBottom = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
    } else if (settedHeadlineBorderType == "top") {
      headlineContainer.style.border = "none";
      headlineContainer.style.borderTop = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
    } else if (settedHeadlineBorderType == "top&bototm") {
      headlineContainer.style.border = "none";
      headlineContainer.style.borderBottom = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
      headlineContainer.style.borderTop = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
    }
    headlineContainer.style.borderRadius = settedRadiusValue;
    headlineContainer.addEventListener('mouseleave', function() {
      if (settedHeadlineBorderType == "No Border") {
        headlineContainer.style.border = "none";
      } else if (settedHeadlineBorderType == "full") {
        headlineContainer.style.border = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
      } else if (settedHeadlineBorderType == "bottom") {
        headlineContainer.style.border = "none";
        headlineContainer.style.borderBottom = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
      } else if (settedHeadlineBorderType == "top") {
        headlineContainer.style.border = "none";
        headlineContainer.style.borderTop = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
      } else if (settedHeadlineBorderType == "top&bototm") {
        headlineContainer.style.border = "none";
        headlineContainer.style.borderBottom = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
        headlineContainer.style.borderTop = `${settedHeadlineBorderWidth} ${settedHeadlineBorderStyle} ${settedHeadlineBorderColor}`;
      }
    })
  }
  //Border select
  var settedHeadlineBorderType;
  const borderSelect = document.getElementById("setting-headline-border-select");
  borderSelect.addEventListener("change", function () {
    settedHeadlineBorderType = borderSelect.value;
    settingHeadlineBorderMouseLeave();
    if (borderSelect.value != "No Border") {
      document.getElementById("headline-border-setting").style.display = "block";
    } else {
      document.getElementById("headline-border-setting").style.display = "none";
    }
  });
  //set border style
  var settedHeadlineBorderStyle = 'solid';
  const borderStyle = document.getElementById("setting-headline-border-style");
  borderStyle.addEventListener("change", function () {
    settedHeadlineBorderStyle = borderStyle.value;
    settingHeadlineBorderMouseLeave();
  });
  //set border width
  var settedHeadlineBorderWidth = '3px';
  const borderWidth = document.getElementById("setting-headline-border-width");
  borderWidth.addEventListener("change", function () {
    settedHeadlineBorderWidth = borderWidth.value;
    settingHeadlineBorderMouseLeave();
  });
  //set border color
  var settedHeadlineBorderColor = '#333';
  const borderColor = document.getElementById("headline-border-color");
  const borderColorIcon = document.getElementById("headline-border-color-icon");
  borderColor.style.color = headlineContainer.style.borderColor;
  borderColorIcon.style.color = headlineContainer.style.borderColor;
  borderColor.addEventListener("input", function () {
    borderColorIcon.style.color = borderColor.value;
    headlineContainer.style.borderColor = borderColor.value;
    settedHeadlineBorderColor = borderColor.value;
    
  });
  //set border radius
  var settedRadiusValue = '0px';
  const borderRadius = document.getElementById("setting-headline-border-radius");
  borderRadius.addEventListener("change", function () {
    settedRadiusValue = borderRadius.value;
    settingHeadlineBorderMouseLeave();
  });
  //set border edge
  const borderEdge = document.getElementById("setting-headline-edge");
  borderEdge.addEventListener("change", function () {
    if (borderEdge.value == "All Edges") {
        headlineContainer.style.borderRadius = settedRadiusValue;
    } else if (borderEdge.value == "Top Only Edges") {
        headlineContainer.style.borderRadius = `${settedRadiusValue} ${settedRadiusValue} 0 0`;
    } else if (borderEdge.value == "Bottom Only Edges") {
        headlineContainer.style.borderRadius = `0 0 ${settedRadiusValue} ${settedRadiusValue}`;
    }
  });
}

// Settings for 2 Step Combo Element
let selectedComboElement = null;
function twoStepGearElement(parentWrapper) {
  selectedComboElement = parentWrapper.id;
  if (setTwoStepOrderPopup.style.right === "0px") {
    setTwoStepOrderPopup.style.right = "-350px"; // Slide out the popup
  } else {
    setTwoStepOrderPopup.style.right = "0px"; // Slide in the popup
  }
  loadPresetComboSettings(parentWrapper.firstChild.firstChild);
}
const comboSettingClose = document.getElementById("combo-close");
comboSettingClose.addEventListener("click", function () {
  selectedComboElement = null;
  setTwoStepOrderPopup.style.right = "-350px"; // Slide out the popup
});

function loadPresetComboSettings(parentContainer) {
  const firstForm = parentContainer.firstChild.childNodes[2];
  const secondForm = parentContainer.firstChild.childNodes[3];
  const combContainer = document.getElementById(selectedComboElement);

  //get margin padding value
  var editorComponentStyles = getComputedStyle(combContainer);
  setCombMarginTop.innerText = editorComponentStyles.getPropertyValue('margin-top');
  setCombMarginBottom.innerText = editorComponentStyles.getPropertyValue('margin-bottom');
  setCombPaddingTop.innerText = editorComponentStyles.getPropertyValue('padding-top');
  setCombPaddingLeft.innerText = editorComponentStyles.getPropertyValue('padding-left');
  setCombPaddingRight.innerText = editorComponentStyles.getPropertyValue('padding-right');
  setCombPaddingBottom.innerText = editorComponentStyles.getPropertyValue('padding-bottom');
  
  // Add event listener for 2-step advanced setting tabs
  const step1Tab = document.getElementById("step1-tab");
  const step2Tab = document.getElementById("step2-tab");
  const eyeIcon1 = document.getElementById("eye-icon1");
  const eyeIcon2 = document.getElementById("eye-icon2");
  step1Content = document.getElementById('step1-content');
  step2Content = document.getElementById('step2-content');
  if (firstForm.classList.contains("hidden")) {
    step1Tab.classList.remove("step-active");
    step2Tab.classList.add("step-active");
    eyeIcon1.classList.remove("bi-eye");
    eyeIcon1.classList.add("bi-eye-slash");
    eyeIcon2.classList.remove("bi-eye-slash");
    eyeIcon2.classList.add("bi-eye");
  } else if (secondForm.classList.contains("hidden")) {
    step1Tab.classList.add("step-active");
    step2Tab.classList.remove("step-active");
    eyeIcon1.classList.remove("bi-eye-slash");
    eyeIcon1.classList.add("bi-eye");
    eyeIcon2.classList.remove("bi-eye");
    eyeIcon2.classList.add("bi-eye-slash");
  }

  step1Tab.addEventListener("click", function () {
    step1Tab.classList.add("step-active");
    step2Tab.classList.remove("step-active");
    eyeIcon1.classList.remove("bi-eye-slash");
    eyeIcon1.classList.add("bi-eye");
    eyeIcon2.classList.remove("bi-eye");
    eyeIcon2.classList.add("bi-eye-slash");
    showForm(parentContainer.firstChild, firstForm.id);
    step1Content.classList.add("active");
    step2Content.classList.remove("active");
  });
  step2Tab.addEventListener("click", function () {
    step1Tab.classList.remove("step-active");
    step2Tab.classList.add("step-active");
    eyeIcon1.classList.remove("bi-eye");
    eyeIcon1.classList.add("bi-eye-slash");
    eyeIcon2.classList.remove("bi-eye-slash");
    eyeIcon2.classList.add("bi-eye");
    showForm(parentContainer.firstChild, secondForm.id);
    step1Content.classList.remove("active");
    step2Content.classList.add("active");
  });
  // set step1 container text
  const step1headline = document.getElementById("step1-headline");
  const step1subheadline = document.getElementById("step1-subheadline");
  const step1Company = document.getElementById("step1-company-name");
  const step1Name = document.getElementById("step1-fullname");
  const step1Email = document.getElementById("step1-email");
  const step1Phone = document.getElementById("step1-phone");
  const step1Address = document.getElementById("step1-address");
  const step1City = document.getElementById("step1-city");
  const step1State = document.getElementById("step1-state");
  const step1Zip = document.getElementById("step1-zip");
  const step1Button = document.getElementById("step1-button");

  const combstep1headline = document.getElementsByClassName("form-heading")[0];
  const combstep1Subheadline = document.getElementsByClassName("form-sub-heading")[0];
  const combCompany = document.getElementsByName("companyname..")[0];
  const combName = document.getElementsByName("fullname...")[0];
  const combEmail = document.getElementsByName("emailaddress...")[0];
  const combPhone = document.getElementsByName("phonenumber...")[0];
  const combAddress = document.getElementsByName("fulladdress...")[0];
  const combCity = document.getElementsByName("cityname...")[0];
  const combState = document.getElementsByName("state/province...")[0];
  const combZip = document.getElementsByName("zipcode...")[0];
  const combButton = document.getElementsByClassName("main-text")[0];

  step1headline.value = combstep1headline.innerText;
  step1headline.addEventListener('input', function() {
    combstep1headline.innerText = step1headline.value;
  })
  step1subheadline.value = combstep1Subheadline.innerText;
  step1subheadline.addEventListener('input', function() {
    combstep1Subheadline.innerText = step1subheadline.value;
  })
  step1Company.value = combCompany.value;
  step1Company.addEventListener('input', function() {
    combCompany.value = step1Company.value;
  })
  step1Name.value = combName.value;
  step1Name.addEventListener('input', function() {
    combName.value = step1Name.value;
  })
  step1Email.value = combEmail.value;
  step1Email.addEventListener('input', function() {
    combEmail.value = step1Email.value;
  })
  step1Phone.value = combPhone.value;
  step1Phone.addEventListener('input', function() {
    combPhone.value = step1Phone.value;
  })
  step1Address.value = combAddress.value;
  step1Address.addEventListener('input', function() {
    combAddress.value = step1Address.value;
  })
  step1City.value = combCity.value;
  step1City.addEventListener('input', function() {
    combCity.value = step1City.value;
  })
  step1State.value = combState.value;
  step1State.addEventListener('input', function() {
    combState.value = step1State.value;
  })
  step1Zip.value = combZip.value;
  step1Zip.addEventListener('input', function() {
    combZip.value = step1Zip.value;
  })
  step1Button.value = combButton.innerText;
  step1Button.addEventListener('input', function() {
    combButton.innerText = step1Button.value;
  })

  // set step2 container text
  const step2headline = document.getElementById("step2-headline");
  const step2subheadline = document.getElementById("step2-subheadline");
  const step2SelectItem = document.getElementById("step2-select-item");
  const step2SelectPrice = document.getElementById("step2-select-price");
  const step2SummaryItem = document.getElementById("step2-summary-item");
  const step2SummaryPrice = document.getElementById("step2-summary-price");
  const step2Button = document.getElementById("step2-button");

  const combstep2headline = document.getElementsByClassName("form-heading")[1];
  const combstep2Subheadline = document.getElementsByClassName("form-sub-heading")[1];
  const combselectItem = document.getElementsByClassName("product-detail")[0].childNodes[0].firstElementChild;
  const combselectPrice = combselectItem.nextElementSibling.nextElementSibling;
  
  const combsummaryItem = document.getElementsByClassName("product-cost-total")[0].firstElementChild.firstElementChild;
  const combsummarytPrice = combsummaryItem.nextElementSibling.nextElementSibling;
  const combstep2Button = document.getElementsByClassName("main-text")[1];

  step2headline.value = combstep2headline.innerText;
  step2headline.addEventListener('input', function() {
    combstep2headline.innerText = step2headline.value;
  })
  step2subheadline.value = combstep2Subheadline.innerText;
  step2subheadline.addEventListener('input', function() {
    combstep2Subheadline.innerText = step2subheadline.value;
  })
  step2SelectItem.value = combselectItem.innerText;
  step2SelectItem.addEventListener('input', function() {
    combselectItem.innerText = step2SelectItem.value;
  })
  step2SelectPrice.value = combselectPrice.innerText;
  step2SelectPrice.addEventListener('input', function() {
    combselectPrice.innerText = step2SelectPrice.value;
  })
  step2SummaryItem.value = combsummaryItem.innerText;
  step2SummaryItem.addEventListener('input', function() {
    combsummaryItem.innerText = step2SummaryItem.value;
  })
  step2SummaryPrice.value = combsummarytPrice.innerText;
  step2SummaryPrice.addEventListener('input', function() {
    combsummarytPrice.innerText = step2SummaryPrice.value;
  })
  step2Button.value = combstep2Button.innerText;
  step2Button.addEventListener('input', function() {
    combstep2Button.innerText = step2Button.value;
  })

  // Button & Button Text & Input Background color pickers
  const btnBackColor = document.getElementById("comb-btn-back-color");
  const btnBackColorIcon = document.getElementById("comb-btn-back-color-icon");
  const combButtonForBack = document.getElementsByClassName("main-text")[0].parentNode;
  btnBackColor.addEventListener("input", function () {
    btnBackColorIcon.style.color = btnBackColor.value;
    combButtonForBack.style.backgroundColor = btnBackColor.value;
  });

  const btnTxtColor = document.getElementById("comb-btn-txt-color");
  const btnTxtColorIcon = document.getElementById("comb-btn-txt-color-icon");
  btnTxtColor.addEventListener("input", function () {
    btnTxtColorIcon.style.color = btnTxtColor.value;
    combButtonForBack.style.color = btnTxtColor.value;
  });

  //background color
  const combBackColor = document.getElementById("comb-back-color");
  const combBackColorIcon = document.getElementById("comb-back-color-icon");
  const formElement = document.getElementById("two-step-order-form").parentNode.parentNode;
  combBackColor.addEventListener("input", function () {
    combBackColorIcon.style.color = combBackColor.value;
    formElement.style.backgroundColor = combBackColor.value;
  });


  function settingCombBorderMouseLeave() {
    if (settedCombeBorderType == "No Border") {
      combContainer.style.border = "none";
    } else if (settedCombeBorderType == "full") {
      combContainer.style.border = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
      
    } else if (settedCombeBorderType == "bottom") {
      combContainer.style.border = "none";
      combContainer.style.borderBottom = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
    } else if (settedCombeBorderType == "top") {
      combContainer.style.border = "none";
      combContainer.style.borderTop = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
    } else if (settedCombeBorderType == "top&bototm") {
      combContainer.style.border = "none";
      combContainer.style.borderBottom = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
      combContainer.style.borderTop = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
    }
    combContainer.style.borderRadius = settedRadiusValue;
    combContainer.addEventListener('mouseleave', function() {
      if (settedCombeBorderType == "No Border") {
        combContainer.style.border = "none";
      } else if (settedCombeBorderType == "full") {
        combContainer.style.border = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
      } else if (settedCombeBorderType == "bottom") {
        combContainer.style.border = "none";
        combContainer.style.borderBottom = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
      } else if (settedCombeBorderType == "top") {
        combContainer.style.border = "none";
        combContainer.style.borderTop = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
      } else if (settedCombeBorderType == "top&bototm") {
        combContainer.style.border = "none";
        combContainer.style.borderBottom = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
        combContainer.style.borderTop = `${settedCombeBorderWidth} ${settedCombeBorderStyle} ${settedCombeBorderColor}`;
      }
    })
  }
  //Border select
  var settedCombeBorderType;
  const borderSelect = document.getElementById("setting-comb-border-select");
  borderSelect.addEventListener("change", function () {
    settedCombeBorderType = borderSelect.value;
    settingCombBorderMouseLeave();
    if (borderSelect.value != "No Border") {
      document.getElementById("comb-border-setting").style.display = "block";
    } else {
      document.getElementById("comb-border-setting").style.display = "none";
    }
  });
  //set border style
  var settedCombeBorderStyle = 'solid';
  const borderStyle = document.getElementById("setting-comb-border-style");
  borderStyle.addEventListener("change", function () {
    settedCombeBorderStyle = borderStyle.value;
    settingCombBorderMouseLeave();
  });
  //set border width
  var settedCombeBorderWidth = '3px';
  const borderWidth = document.getElementById("setting-comb-border-width");
  borderWidth.addEventListener("change", function () {
    settedCombeBorderWidth = borderWidth.value;
    settingCombBorderMouseLeave();
  });
  //set border color
  var settedCombeBorderColor = '#333';
  const borderColor = document.getElementById("comb-border-color");
  const borderColorIcon = document.getElementById("comb-border-color-icon");
  borderColor.style.color = combContainer.style.borderColor;
  borderColorIcon.style.color = combContainer.style.borderColor;
  borderColor.addEventListener("input", function () {
    borderColorIcon.style.color = borderColor.value;
    combContainer.style.borderColor = borderColor.value;
    settedCombeBorderColor = borderColor.value;
    
  });
  //set border radius
  var settedRadiusValue = '0px';
  const borderRadius = document.getElementById("setting-comb-border-radius");
  borderRadius.addEventListener("change", function () {
    settedRadiusValue = borderRadius.value;
    settingCombBorderMouseLeave();
  });
  //set border edge
  const borderEdge = document.getElementById("setting-comb-edge");
  borderEdge.addEventListener("change", function () {
    if (borderEdge.value == "All Edges") {
        combContainer.style.borderRadius = settedRadiusValue;
    } else if (borderEdge.value == "Top Only Edges") {
        combContainer.style.borderRadius = `${settedRadiusValue} ${settedRadiusValue} 0 0`;
    } else if (borderEdge.value == "Bottom Only Edges") {
        combContainer.style.borderRadius = `0 0 ${settedRadiusValue} ${settedRadiusValue}`;
    }
  });
}

// Settings for Image Element
let selectedImageElement = null;
function imageGearElement(parentWrapper) {
  selectedImageElement = parentWrapper.id;
  if (setImagePopup.style.right === "0px") {
    setImagePopup.style.right = "-350px"; // Slide out the popup
  } else {
    setImagePopup.style.right = "0px"; // Slide in the popup
  }
  loadPresetImageSettings();
}
const imageSettingClose = document.getElementById("image-setting-close");
imageSettingClose.addEventListener("click", function () {
  selectedImageElement = null;
  setImagePopup.style.right = "-350px"; // Slide out the popup
});
function loadPresetImageSettings() {
  const imageContainer = document.getElementById(selectedImageElement);
  const imageGeneralTab = document.getElementById("image-general-tab");
  const imageGeneralContent = document.getElementById("image-general-content");
  const imageAdvancedTab = document.getElementById("image-advanced-tab");
  const imageAdvancedContent = document.getElementById("image-advanced-content");
  const imageOpacitySelect = document.getElementById("image-opacity-select");
  imageGeneralTab.addEventListener("click", function () {
    imageGeneralContent.classList.add("active");
    imageGeneralTab.classList.add("active");
    imageAdvancedContent.classList.remove("active");
    imageAdvancedTab.classList.remove("active");
  });
  imageAdvancedTab.addEventListener("click", function () {
    imageGeneralContent.classList.remove("active");
    imageGeneralTab.classList.remove("active");
    imageAdvancedContent.classList.add("active");
    imageAdvancedTab.classList.add("active");
  });
  //get margin padding value
  var editorComponentStyles = getComputedStyle(imageContainer);
  setImageMarginTop.innerText = editorComponentStyles.getPropertyValue('margin-top');
  setImageMarginBottom.innerText = editorComponentStyles.getPropertyValue('margin-bottom');
  setImagePaddingTop.innerText = editorComponentStyles.getPropertyValue('padding-top');
  setImagePaddingLeft.innerText = editorComponentStyles.getPropertyValue('padding-left');
  setImagePaddingRight.innerText = editorComponentStyles.getPropertyValue('padding-right');
  setImagePaddingBottom.innerText = editorComponentStyles.getPropertyValue('padding-bottom');
  // Background color setting for Image Element
  const imageBackColor = document.getElementById("image-back-color");
  const imageBackColorIcon = document.getElementById(
    "image-back-color-icon"
  );
  imageBackColor.style.color = imageContainer.style.backgroundColor;
  imageBackColorIcon.style.color = imageContainer.style.backgroundColor;
  imageBackColor.addEventListener("input", function () {
    imageBackColorIcon.style.color = imageBackColor.value;
    imageContainer.style.backgroundColor = imageBackColor.value;
    imageOpacitySelect.value = "1.0";
  });
  // Background color opacity for Image Element
  imageOpacitySelect.addEventListener("change", function () {
    let rgbColor = imageContainer.style.backgroundColor;
    if (imageContainer.style.backgroundColor.includes("rgba")) {
      rgbColor =
        imageContainer.style.backgroundColor.replace(/, [\d\.]+\)$/, "") +
        ")";
    }
    let convertedRGBA = rgbColor.replace(
      ")",
      `, ${imageOpacitySelect.value})`
    );
    imageContainer.style.backgroundColor = convertedRGBA;
  });
  // Text Alignment for Headline Element
  const imageAlignLeft = document.getElementById("image-align-left");
  const imageAlignCenter = document.getElementById("image-align-center");
  const imageAlignRigth = document.getElementById("image-align-right");
  const imageAlignFull = document.getElementById("image-align-full");
  imageAlignLeft.addEventListener('click', function() {
    imageContainer.style.textAlign = "left";
    imageAlignLeft.classList.add("selected-button");
    imageAlignCenter.classList.remove("selected-button");
    imageAlignRigth.classList.remove("selected-button");
    imageAlignFull.classList.remove("selected-button");
  })
  imageAlignCenter.addEventListener('click', function() {
    imageContainer.style.textAlign = "center";
    imageAlignLeft.classList.remove("selected-button");
    imageAlignCenter.classList.add("selected-button");
    imageAlignRigth.classList.remove("selected-button");
    imageAlignFull.classList.remove("selected-button");
  })
  imageAlignRigth.addEventListener('click', function() {
    imageContainer.style.textAlign = "right";
    imageAlignLeft.classList.remove("selected-button");
    imageAlignCenter.classList.remove("selected-button");
    imageAlignRigth.classList.add("selected-button");
    imageAlignFull.classList.remove("selected-button");
  })
  imageAlignFull.addEventListener('click', function() {
    imageContainer.style.textAlign = "justify";
    imageAlignLeft.classList.remove("selected-button");
    imageAlignCenter.classList.remove("selected-button");
    imageAlignRigth.classList.remove("selected-button");
    imageAlignFull.classList.add("selected-button");
  })
  //Setting import Image
  const imagePath = document.getElementById("input-image-path");
  imagePath.addEventListener("input", function () {
    imageContainer.childNodes[0].setAttribute('src', imagePath.value);
  });
  // setting image width
  const imageWidth = document.getElementById("set-image-width");
  imageWidth.addEventListener('input', function() {
    imageContainer.childNodes[0].style.width = imageWidth.value + 'px';
  })
  // setting image height
  const imageHeight = document.getElementById("set-image-height");
  imageHeight.addEventListener('input', function() {
    imageContainer.childNodes[0].style.height = imageHeight.value + 'px';
  })
  //get image width and height
  var imageStyle = getComputedStyle(imageContainer.childNodes[0]);
  var getImageWidth = imageStyle.getPropertyValue('width');
  var getImageHeight = imageStyle.getPropertyValue('height');
  imageWidth.value = parseInt(getImageWidth.match(/\d+/)[0]);
  imageHeight.value = parseInt(getImageHeight.match(/\d+/)[0]);
  // setting image alt
  const imageAlt = document.getElementById("set-image-alt");
  imageAlt.addEventListener('input', function() {
    imageContainer.childNodes[0].setAttribute('alt', imageAlt.value);
  })
  //setting image radius
  const imageRadius = document.getElementById("set-image-radius");
  imageRadius.addEventListener("change", function() {
    if(imageRadius.value == "None") {
      imageContainer.childNodes[0].style.borderRadius = '0px'
    } else if(imageRadius.value == "Circle") {
      imageContainer.childNodes[0].style.borderRadius = '50%'
    } else if(imageRadius.value == "Round Corners") {
      imageContainer.childNodes[0].style.borderRadius = '5px'
    } 
  })
  //setting image border
  const imageBorder = document.getElementById("set-image-border");
  imageBorder.addEventListener("change", function() {
    if(imageBorder.value == "None") {
      imageContainer.childNodes[0].style.border = 'none';
    } else if(imageBorder.value == "White Thumbnail Border") {
      imageContainer.childNodes[0].style.border = '3px solid #fff';
    } else if(imageBorder.value == "Dark Thumbnail Border") {
      imageContainer.childNodes[0].style.border = '3px solid rgba(0,0,0,.7)';
    } else if(imageBorder.value == "2px Dark Thumbnail Border") {
      imageContainer.childNodes[0].style.border = '2px solid rgba(0,0,0,.55)';
    } else if(imageBorder.value == "5px Transparent Thumbnail Border") {
      imageContainer.childNodes[0].style.border = '1px solid rgba(0,0,0,.15)';
      imageContainer.childNodes[0].style.borderBottom = '2px solid rgba(0,0,0,.15)';
      imageContainer.childNodes[0].style.padding = '5px';
    } else if(imageBorder.value == "2px Bottom Thumbnail Border") {
      imageContainer.childNodes[0].style.border = '1px solid rgba(0,0,0,.35)';
      imageContainer.childNodes[0].style.borderBottom = '2px solid rgba(0,0,0,.35)';
      imageContainer.childNodes[0].style.padding = '1px';
    } 
  })
  //setting image shadow
  const setImageShadow = document.getElementById("set-image-shadow");
  setImageShadow.addEventListener("change", function() {
    if(setImageShadow.value == "None") {
      imageContainer.childNodes[0].style.boxShadow = '0px'
    } else if(setImageShadow.value == "Light Shadow") {
      imageContainer.childNodes[0].style.boxShadow = '0 1px 5px #0003'
    } else if(setImageShadow.value == "Full Shadow") {
      imageContainer.childNodes[0].style.boxShadow = '0 2px 5px 2px #0000004d'
    } else if(setImageShadow.value == "Dark Shadow") {
      imageContainer.childNodes[0].style.boxShadow = '0 2px 5px 2px #0006'
    } else if(setImageShadow.value == "Buttom Medium Dark Shadow") {
      imageContainer.childNodes[0].style.boxShadow = '0 4px 3px #00000026, 0 0 2px #00000026'
    } else if(setImageShadow.value == "Bottom Light Shadow") {
      imageContainer.childNodes[0].style.boxShadow = '0 10px 6px -6px #00000026'
    } else if(setImageShadow.value == "Bottom Right Dark Shadow") {
      imageContainer.childNodes[0].style.boxShadow = '3px 3px 15px #212121a8'
    } else if(setImageShadow.value == "Bottom Dark Shadow") {
      imageContainer.childNodes[0].style.boxShadow = '0px 3px 15px #212121a8'
    } 
  })
}

// Settings for Video Element
let selectedVideoElement = null;
function videoGearElement(parentWrapper) {
  selectedVideoElement = parentWrapper.id;
  if (setVideoPopup.style.right === "0px") {
    setVideoPopup.style.right = "-350px"; // Slide out the popup
  } else {
    setVideoPopup.style.right = "0px"; // Slide in the popup
  }
  loadPresetVideoSettings();
}
const videoSettingClose = document.getElementById("video-setting-close");
videoSettingClose.addEventListener("click", function () {
  selectedVideoElement = null;
  setVideoPopup.style.right = "-350px"; // Slide out the popup
});

function loadPresetVideoSettings() {
  const videoContainer = document.getElementById(selectedVideoElement);
  const videoGeneralTab = document.getElementById("video-general-tab");
  const videoGeneralContent = document.getElementById("video-general-content");
  const videoAdvancedTab = document.getElementById("video-advanced-tab");
  const videoAdvancedContent = document.getElementById("video-advanced-content");
  videoGeneralTab.addEventListener("click", function () {
    videoGeneralContent.classList.add("active");
    videoGeneralTab.classList.add("active");
    videoAdvancedContent.classList.remove("active");
    videoAdvancedTab.classList.remove("active");
  });
  videoAdvancedTab.addEventListener("click", function () {
    videoGeneralContent.classList.remove("active");
    videoGeneralTab.classList.remove("active");
    videoAdvancedContent.classList.add("active");
    videoAdvancedTab.classList.add("active");
  });
  //get margin padding value
  var editorComponentStyles = getComputedStyle(videoContainer);
  setVideoMarginTop.innerText = editorComponentStyles.getPropertyValue('margin-top');
  setVideoMarginBottom.innerText = editorComponentStyles.getPropertyValue('margin-bottom');
  setVideoPaddingTop.innerText = editorComponentStyles.getPropertyValue('padding-top');
  setVideoPaddingLeft.innerText = editorComponentStyles.getPropertyValue('padding-left');
  setVideoPaddingRight.innerText = editorComponentStyles.getPropertyValue('padding-right');
  setVideoPaddingBottom.innerText = editorComponentStyles.getPropertyValue('padding-bottom');
  // Background color setting for Image Element
  const videoBackColor = document.getElementById("video-back-color");
  const videoBackColorIcon = document.getElementById(
    "video-back-color-icon"
  );
  videoBackColor.style.color = videoContainer.style.backgroundColor;
  videoBackColorIcon.style.color = videoContainer.style.backgroundColor;
  videoBackColor.addEventListener("input", function () {
    videoBackColorIcon.style.color = videoBackColor.value;
    videoContainer.style.backgroundColor = videoBackColor.value;
  });
  //Setting import Image
  const videoPath = document.getElementById("input-video-path");
  videoPath.addEventListener("input", function () {
    videoContainer.childNodes[0].setAttribute('src', videoPath.value);
  });
  //Box Shadow
  const setBoxShadow = document.getElementById("set-video-box-shadow");
  setBoxShadow.addEventListener("change", function () {
    if (setBoxShadow.value == "No Shadow") {
      videoContainer.style.boxShadow = "none";
    } else if (setBoxShadow.value == "5% Drop Shadow") {
      videoContainer.style.boxShadow = "0 1px 3px #0000000d";
    } else if (setBoxShadow.value == "10% Drop Shadow") {
      videoContainer.style.boxShadow = "0 1px 5px #0000001a";
    } else if (setBoxShadow.value == "20% Drop Shadow") {
      videoContainer.style.boxShadow = "0 1px 5px #0003";
    } else if (setBoxShadow.value == "30% Drop Shadow") {
      videoContainer.style.boxShadow = "0 2px 5px 2px #0000004d";
    } else if (setBoxShadow.value == "40% Drop Shadow") {
      videoContainer.style.boxShadow = "0 2px 5px 2px #0006";
    } else if (setBoxShadow.value == "5% Inner Shadow") {
      videoContainer.style.boxShadow = "0 1px 3px #0000000d inset";
    } else if (setBoxShadow.value == "10% Inner Shadow") {
      videoContainer.style.boxShadow = "0 1px 5px #0000001a inset";
    } else if (setBoxShadow.value == "20% Inner Shadow") {
      videoContainer.style.boxShadow = "0 1px 5px #0003 inset";
    } else if (setBoxShadow.value == "30% Inner Shadow") {
      videoContainer.style.boxShadow = "0 2px 5px 2px #0000004d inset";
    } else if (setBoxShadow.value == "40% Inner Shadow") {
      videoContainer.style.boxShadow = "0 2px 5px 2px #0006 inset";
    }
  });
  // set video url
  const setVideoPath = document.getElementById("input-video-path");
  setVideoPath.addEventListener('input', function() {
    const cresateSourceTag = document.createElement("source");
    cresateSourceTag.setAttribute('src', setVideoPath.value);
    videoContainer.childNodes[0].append(cresateSourceTag);
  })
  //setting video width
  const setVideoWidth = document.getElementById("set-video-width");
  setVideoWidth.addEventListener("change", function() {
    if(setVideoWidth.value == "Full Width") {
      videoContainer.style.width = '100%'
    } else if(setVideoWidth.value == "3/4 Width") {
      videoContainer.style.width = '75%'
    } else if(setVideoWidth.value == "Half Width") {
      videoContainer.style.width = '50%'
    } 
  })
  //Border select
  function settingVideoBorderMouseLeave() {
    if (settedVideoBorderType == "No Border") {
      videoContainer.style.border = "none";
    } else if (settedVideoBorderType == "full") {
      videoContainer.style.border = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
      
    } else if (settedVideoBorderType == "bottom") {
      videoContainer.style.border = "none";
      videoContainer.style.borderBottom = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
    } else if (settedVideoBorderType == "top") {
      videoContainer.style.border = "none";
      videoContainer.style.borderTop = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
    } else if (settedVideoBorderType == "top&bototm") {
      videoContainer.style.border = "none";
      videoContainer.style.borderBottom = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
      videoContainer.style.borderTop = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
    }
    videoContainer.style.borderRadius = settedRadiusValue;
    videoContainer.addEventListener('mouseleave', function() {
      if (settedVideoBorderType == "No Border") {
        videoContainer.style.border = "none";
      } else if (settedVideoBorderType == "full") {
        videoContainer.style.border = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
      } else if (settedVideoBorderType == "bottom") {
        videoContainer.style.border = "none";
        videoContainer.style.borderBottom = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
      } else if (settedVideoBorderType == "top") {
        videoContainer.style.border = "none";
        videoContainer.style.borderTop = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
      } else if (settedVideoBorderType == "top&bototm") {
        videoContainer.style.border = "none";
        videoContainer.style.borderBottom = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
        videoContainer.style.borderTop = `${settedVideoBorderWidth} ${settedVideoBorderStyle} ${settedVideoBorderColor}`;
      }
    })
  }
  var settedVideoBorderType;
  const borderSelect = document.getElementById("setting-video-border-select");
  borderSelect.addEventListener("change", function () {
    settedVideoBorderType = borderSelect.value;
    settingVideoBorderMouseLeave();
    if (borderSelect.value != "No Border") {
      document.getElementById("video-border-setting").style.display = "block";
    } else {
      document.getElementById("video-border-setting").style.display = "none";
    }
  });
  //set border style
  var settedVideoBorderStyle = 'solid';
  const borderStyle = document.getElementById("setting-video-border-style");
  borderStyle.addEventListener("change", function () {
    settedVideoBorderStyle = borderStyle.value;
    settingVideoBorderMouseLeave();
  });
  //set border width
  var settedVideoBorderWidth = '3px';
  const borderWidth = document.getElementById("setting-video-border-width");
  borderWidth.addEventListener("change", function () {
    settedVideoBorderWidth = borderWidth.value;
    settingVideoBorderMouseLeave();
  });
  //set border color
  var settedVideoBorderColor = '#333';
  const borderColor = document.getElementById("video-border-color");
  const borderColorIcon = document.getElementById("video-border-color-icon");
  borderColor.style.color = videoContainer.style.borderColor;
  borderColorIcon.style.color = videoContainer.style.borderColor;
  borderColor.addEventListener("input", function () {
    borderColorIcon.style.color = borderColor.value;
    videoContainer.style.borderColor = borderColor.value;
    settedVideoBorderColor = borderColor.value;
    
  });
  //set border radius
  var settedRadiusValue = '0px';
  const borderRadius = document.getElementById("setting-video-border-radius");
  borderRadius.addEventListener("change", function () {
    settedRadiusValue = borderRadius.value;
    settingVideoBorderMouseLeave();
  });
  //set border edge
  const borderEdge = document.getElementById("setting-video-edge");
  borderEdge.addEventListener("change", function () {
    if (borderEdge.value == "All Edges") {
        videoContainer.style.borderRadius = settedRadiusValue;
    } else if (borderEdge.value == "Top Only Edges") {
        videoContainer.style.borderRadius = `${settedRadiusValue} ${settedRadiusValue} 0 0`;
    } else if (borderEdge.value == "Bottom Only Edges") {
        videoContainer.style.borderRadius = `0 0 ${settedRadiusValue} ${settedRadiusValue}`;
    }
  });
}



// Add event listener for 2-step combo setting tabs
const generalTab = document.getElementById("general-tab");
const generalContent = document.getElementById("general-content");
const advancedTab = document.getElementById("advanced-tab");
const advancedContent = document.getElementById("advanced-content");
generalTab.addEventListener("click", function () {
  generalContent.classList.add("active");
  generalTab.classList.add("active");
  advancedContent.classList.remove("active");
  advancedTab.classList.remove("active");
});
advancedTab.addEventListener("click", function () {
  generalContent.classList.remove("active");
  generalTab.classList.remove("active");
  advancedContent.classList.add("active");
  advancedTab.classList.add("active");
});
// Close popups when click close button
const sectionClose = document.getElementById("add-section-close");
sectionClose.addEventListener("click", function () {
  setSectionWidthPopup.style.right = "-350px"; // Slide out the popup
});
const rowClose = document.getElementById("add-row-close");
rowClose.addEventListener("click", function () {
  setColumnNumberPopup.style.right = "-350px"; // Slide out the popup
});
// Close Popups when click outside
document.addEventListener("click", function (event) {
  const greenGearButtons = document.querySelectorAll("[id*='green_advanced']");
  const isOutsidePopup4 = event.target !== setSectionPopup && !setSectionPopup.contains(event.target);
  const isMarginPaddingPopup = event.target !== marginPaddingPopup && !marginPaddingPopup.contains(event.target);
  const isGreenGearButton = Array.from(greenGearButtons).some((button) =>
    button.contains(event.target)
  );
  const isAddSectionPopup = event.target !== setSectionWidthPopup && !setSectionWidthPopup.contains(event.target);
  const isAddRownPopup = event.target !== setColumnNumberPopup && !setColumnNumberPopup.contains(event.target);
  const addSectionlink = document.getElementById("add-section-button");
  const isAddSectionlink = event.target !== addSectionlink && !addSectionlink.contains(event.target);
  const plusCircleButtons = document.querySelectorAll(".de-rollover-plus-circle");
  const isPlusCircleButton = Array.from(plusCircleButtons).some((button) =>
    button.contains(event.target)
  );
  const plusSquareButtons = document.querySelectorAll(".add-row-de-rollover-tools");
  const isPlusSquareButton = Array.from(plusSquareButtons).some((button) =>
    button.contains(event.target)
  );
  if (isAddSectionPopup && !isPlusCircleButton && isAddSectionlink) {
    setSectionWidthPopup.style.right = "-350px"; // Slide out the popup
  }
  if (isAddRownPopup && !isPlusCircleButton && !isPlusSquareButton) {
    setColumnNumberPopup.style.right = "-350px"; // Slide out the popup
  }

  if (isOutsidePopup4 && !isGreenGearButton && isMarginPaddingPopup) {
    if (selectedGreenSection) {
      selectedGreenSection = null;
      setSectionPopup.style.right = "-350px"; // Slide out the popup
    }
  }

  const blueGearButtons = document.querySelectorAll("[id*='blue_gear']");
  const isOutsidePopup5 =
    event.target !== setColumnPopup && !setColumnPopup.contains(event.target);
  const isBlueGearButton = Array.from(blueGearButtons).some((button) =>
    button.contains(event.target)
  );
  if (isOutsidePopup5 && !isBlueGearButton && isMarginPaddingPopup) {
    if (selectedBlueSection) {
      selectedBlueSection = null;
      setColumnPopup.style.right = "-350px"; // Slide out the popup
    }
  }

  const orangeGearButtons = document.querySelectorAll("[id*='orange_gear']");
  const isOutsideHeadlinePopup =
    event.target !== setHeadlinePopup &&
    !setHeadlinePopup.contains(event.target);
  const isOrangeGearButton = Array.from(orangeGearButtons).some((button) =>
    button.contains(event.target)
  );
  if (isOutsideHeadlinePopup && !isOrangeGearButton && isMarginPaddingPopup) {
    if (selectedHeadlineElement) {
      selectedHeadlineElement = null;
      selectedHeadlineContainer = null;
      setHeadlinePopup.style.right = "-350px"; // Slide out the popup
    }
  }

  const isOutsideComboPopup =
    event.target !== setTwoStepOrderPopup && !setTwoStepOrderPopup.contains(event.target);
  if (isOutsideComboPopup && !isOrangeGearButton && isMarginPaddingPopup) {
    if (selectedComboElement) {
      selectedComboElement = null;
      setTwoStepOrderPopup.style.right = "-350px"; // Slide out the popup
    }
  }
  const isOutsideImagePopup =
  event.target !== setImagePopup && !setImagePopup.contains(event.target);
  if (isOutsideImagePopup && !isOrangeGearButton && isMarginPaddingPopup) {
    if (selectedImageElement) {
      selectedImageElement = null;
      setImagePopup.style.right = "-350px"; // Slide out the popup
    }
  }
  const isOutsideVideoPopup =
  event.target !== setVideoPopup && !setVideoPopup.contains(event.target);
  if (isOutsideVideoPopup && !isOrangeGearButton && isMarginPaddingPopup) {
    if (selectedVideoElement) {
      selectedVideoElement = null;
      setVideoPopup.style.right = "-350px"; // Slide out the popup
    }
  }

  const buttonElements = document.querySelectorAll("[id*='the_button']");
  const isButtonElement = Array.from(buttonElements).some((button) =>
    button.contains(event.target)
  );
  const isOutsideButtonPopup =
    event.target !== settingsSidebar && !settingsSidebar.contains(event.target);
  if (
    isOutsideButtonPopup &&
    !isOrangeGearButton &&
    !isButtonElement &&
    isMarginPaddingPopup
  ) {
    if (selectedElSettings) {
      closeSidebar();
    }
  }

  const blueAddButtons = document.querySelectorAll("[id*='blue_add']");
  const isBlueAddButton = Array.from(blueAddButtons).some((button) =>
    button.contains(event.target)
  );
  const orangeAddButtons = document.querySelectorAll("[id*='orange_add']");
  const isOrangeAddButton = Array.from(orangeAddButtons).some((button) =>
    button.contains(event.target)
  );
  const addElementButton = document.getElementById("add-element-button");

  const isAddElementButton = addElementButton.contains(event.target);
  const isOutsideElementsPopup =
    event.target !== leftSlidingPopup &&
    !leftSlidingPopup.contains(event.target);
  if (
    isOutsideElementsPopup &&
    !isAddElementButton &&
    !isBlueAddButton &&
    !isOrangeAddButton
  ) {
    if (!leftSlidingPopup.classList.contains("hidden")) closeElementsPanel();
  }

  const isSettingGreenMarginPaddingValue =
    event.target !== settingGreenMarginPaddingValue &&
    !settingGreenMarginPaddingValue.contains(event.target);
  const isSettingBlueMarginPaddingValue =
    event.target !== settingBlueMarginPaddingValue &&
    !settingBlueMarginPaddingValue.contains(event.target);
  const isSettingOrangeMarginPaddingValue =
    event.target !== settingOrangeMarginPaddingValue &&
    !settingOrangeMarginPaddingValue.contains(event.target);
  const isSettingCombMarginPaddingValue =
    event.target !== settingCombMarginPaddingValue &&
    !settingCombMarginPaddingValue.contains(event.target);
  const isSettingButtonMarginPaddingValue =
    event.target !== settingButtonMarginPaddingValue &&
    !settingButtonMarginPaddingValue.contains(event.target);
  const isSettingImageMarginPaddingValue =
  event.target !== settingImageMarginPaddingValue &&
  !settingImageMarginPaddingValue.contains(event.target);
  const isSettingVideoMarginPaddingValue =
  event.target !== settingVideoMarginPaddingValue &&
  !settingVideoMarginPaddingValue.contains(event.target);
  if (
    isMarginPaddingPopup &&
    isSettingGreenMarginPaddingValue &&
    isSettingBlueMarginPaddingValue &&
    isSettingOrangeMarginPaddingValue &&
    isSettingCombMarginPaddingValue &&
    isSettingButtonMarginPaddingValue && isSettingImageMarginPaddingValue && isSettingVideoMarginPaddingValue
  ) {
    marginPaddingPopup.style.display = "none";
  }
});

function openMarginPaddingPopup(button) {
  marginPaddingPopup.style.display = "block";
  const regex = /-?\d*\.?\d+/g;
  setValueWithNumber.value = button.innerText.match(regex);
  setValueWithRange.value = button.innerText.match(regex);
  settingMarginPadding = button;
}

function updateNumber() {
  setValueWithNumber.value = setValueWithRange.value;
  settingMarginPadding.innerText = setValueWithNumber.value + setUnit.value;
  setMarginPaddingWithInput()
  // Event listener for handling further changes
  setUnit.addEventListener("change", function () {
    settingMarginPadding.innerText = setValueWithNumber.value + setUnit.value;
    setMarginPaddingWithInput()
  });
}

function setValue(div) {
  // Function execution when the page loads
  setValueWithNumber.value = div.innerText;
  setValueWithRange.value = div.innerText;

  // Logic for ensuring the code block works even when no change event is triggered
  if (div.innerText == "AUTO") {
    settingMarginPadding.innerText = div.innerText;
  } else {
    settingMarginPadding.innerText = div.innerText + setUnit.value;
  }
  setMarginPaddingWithInput()
  // Event listener for handling further changes
  setUnit.addEventListener("change", function () {
    setValueWithNumber.value = div.innerText;
    setValueWithRange.value = div.innerText;

    if (div.innerText == "AUTO") {
      settingMarginPadding.innerText = div.innerText;
    } else {
      settingMarginPadding.innerText = div.innerText + setUnit.value;
    }
    setMarginPaddingWithInput()
  });
}
function setMarginPaddingWithInput() {
  const setSectionMarginPadding = document.getElementById(selectedGreenSection);
  const setRowColumnnMarginPadding =
    document.getElementById(selectedBlueSection);
  const setElementMarginPadding = document.getElementById(
    selectedHeadlineContainer
  );
  const setCombMarginPadding = document.getElementById(selectedComboElement);
  const setButtonMarginPadding = document.getElementById(buttonContainerId);
  const imageContainer = document.getElementById(selectedImageElement);
  const videoContainer = document.getElementById(selectedVideoElement);

  // Apply styles based on the initial values
  if (settingMarginPadding.getAttribute("id") == "setGreenMarginTop") {
    setSectionMarginPadding.style.marginTop =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setGreenPaddingTop") {
    setSectionMarginPadding.style.paddingTop =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setGreenPaddingLeft") {
    setSectionMarginPadding.style.paddingLeft =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setGreenPaddingRight"
  ) {
    setSectionMarginPadding.style.paddingRight =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setGreenPaddingBottom"
  ) {
    setSectionMarginPadding.style.paddingBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setGreenMarginBottom"
  ) {
    setSectionMarginPadding.style.marginBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setBlueMarginTop") {
    setRowColumnnMarginPadding.style.marginTop =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setBluePaddingTop") {
    setRowColumnnMarginPadding.style.paddingTop =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setBluePaddingLeft") {
    setRowColumnnMarginPadding.style.paddingLeft =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setBluePaddingRight") {
    setRowColumnnMarginPadding.style.paddingRight =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setBluePaddingBottom"
  ) {
    setRowColumnnMarginPadding.style.paddingBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setBlueMarginBottom") {
    setRowColumnnMarginPadding.style.marginBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setOrangeMarginTop") {
    setElementMarginPadding.style.marginTop =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setOrangePaddingTop") {
    setElementMarginPadding.style.paddingTop =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setOrangePaddingLeft"
  ) {
    setElementMarginPadding.style.paddingLeft =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setOrangePaddingRight"
  ) {
    setElementMarginPadding.style.paddingRight =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setOrangePaddingBottom"
  ) {
    setElementMarginPadding.style.paddingBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setOrangeMarginBottom"
  ) {
    setElementMarginPadding.style.marginBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setCombMarginTop") {
    setCombMarginPadding.style.marginTop =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setCombPaddingTop") {
    setCombMarginPadding.style.paddingTop =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setCombPaddingLeft") {
    setCombMarginPadding.style.paddingLeft =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setCombPaddingRight") {
    setCombMarginPadding.style.paddingRight =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setCombPaddingBottom"
  ) {
    setCombMarginPadding.style.paddingBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setCombMarginBottom") {
    setCombMarginPadding.style.marginBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setButtonMarginTop") {
    setButtonMarginPadding.style.marginTop =
      setValueWithNumber.value + setUnit.value;
  } else if (settingMarginPadding.getAttribute("id") == "setButtonPaddingTop") {
    setButtonMarginPadding.childNodes[0].style.paddingTop =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setButtonPaddingLeft"
  ) {
    setButtonMarginPadding.childNodes[0].style.paddingLeft =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setButtonPaddingRight"
  ) {
    setButtonMarginPadding.childNodes[0].style.paddingRight =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setButtonPaddingBottom"
  ) {
    setButtonMarginPadding.childNodes[0].style.paddingBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setButtonMarginBottom"
  ) {
    setButtonMarginPadding.style.marginBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setImageMarginTop"
  ) {
    imageContainer.style.marginTop =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setImagePaddingTop"
  ) {
    imageContainer.style.paddingTop =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setImagePaddingLeft"
  ) {
    imageContainer.style.paddingLeft =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setImagePaddingRight"
  ) {
    imageContainer.style.paddingRight =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setImagePaddingBottom"
  ) {
    imageContainer.style.paddingBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setImageMarginBottom"
  ) {
    imageContainer.style.marginBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setVideoMarginTop"
  ) {
    videoContainer.style.marginTop =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setVideoPaddingTop"
  ) {
    videoContainer.style.paddingTop =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setVideoPaddingLeft"
  ) {
    videoContainer.style.paddingLeft =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setVideoPaddingRight"
  ) {
    videoContainer.style.paddingRight =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setVideoPaddingBottom"
  ) {
    videoContainer.style.paddingBottom =
      setValueWithNumber.value + setUnit.value;
  } else if (
    settingMarginPadding.getAttribute("id") == "setVideoMarginBottom"
  ) {
    videoContainer.style.marginBottom =
      setValueWithNumber.value + setUnit.value;
  } 
}
function setValueReset() {
  setValueWithNumber.value = "0";
  setValueWithRange.value = 0;
}

function getButtonContainerId(div) {
  buttonContainerId = div.id;
}
